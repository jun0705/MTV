<?php
/**
 * 瓜子影视 - 影视仓 PHP 完美最终版
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    protected $name = '瓜子';
    protected $api_ua = 'okhttp/3.12.0';
    protected $media_ua = 'Lavf/57.83.100';
    protected $media_referer = 'http://WJiZxLXA2.com/';
    
    protected $phone_model = 'xiaomi-25031';
    protected $sign_salt = '*&zvdvdvddbfikkkumtmdwqppp?|4Y!s!2br';
    protected $device_old_key = 'aLFBMWpxBrIDAD1Si/KVvm41';

    protected $default_hosts = [
        'https://api.anctjd.com', 'https://apinew.uozvr.com', 'https://api.w32z7vtd.com',
        'https://api.6a7nnf7.com', 'https://api.umygrx3.com', 'https://api.rmedphk.com'
    ];

    protected $control_urls = ['https://api.rqqakqyn.com'];

    protected $aes_key = 'OITxa5OqAYjhswxx';
    protected $aes_iv = 'rCMNwZASNBKZ8mXV';
    
    protected $rsa_public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDUM5+/y8sPsWkd1/RQS64X259EUwxFXFE5HlA65MqrxnPs0JqoSRojSDy5QhwvROlaD6TwRQHKMY2OAZ6SnQeUJsChTEFIR9qUkwrs3/MVUMxjsv6JS6Oe/juclyJGTgVmDhB55EafXsD0SQYVj/QXXsxR6ewR5E2kL52yAAD4yQIDAQAB";
    
    protected $rsa_private_key = "-----BEGIN RSA PRIVATE KEY-----\nMIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGAe6hKrWLi1zQmjTT1\nozbE4QdFeJGNxubxld6GrFGximxfMsMB6BpJhpcTouAqywAFppiKetUBBbXwYsYU\n1wNr648XVmPmCMCy4rY8vdliFnbMUj086DU6Z+/oXBdWU3/b1G0DN3E9wULRSwcK\nZT3wj/cCI1vsCm3gj2R5SqkA9Y0CAwEAAQKBgAJH+4CxV0/zBVcLiBCHvSANm0l7\nHetybTh/j2p0Y1sTXro4ALwAaCTUeqdBjWiLSo9lNwDHFyq8zX90+gNxa7c5EqcW\nV9FmlVXr8VhfBzcZo1nXeNdXFT7tQ2yah/odtdcx+vRMSGJd1t/5k5bDd9wAvYdI\nDblMAg+wiKKZ5KcdAkEA1cCakEN4NexkF5tHPRrR6XOY/XHfkqXxEhMqmNbB9U34\nsaTJnLWIHC8IXys6Qmzz30TtzCjuOqKRRy+FMM4TdwJBAJQZFPjsGC+RqcG5UvVM\niMPhnwe/bXEehShK86yJK/g/UiKrO87h3aEu5gcJqBygTq3BBBoH2md3pr/W+hUM\nWBsCQQChfhTIrdDinKi6lRxrdBnn0Ohjg2cwuqK5zzU9p/N+S9x7Ck8wUI53DKm8\njUJE8WAG7WLj/oCOWEh+ic6NIwTdAkEAj0X8nhx6AXsgCYRql1klbqtVmL8+95KZ\nK7PnLWG/IfjQUy3pPGoSaZ7fdquG8bq8oyf5+dzjE/oTXcByS+6XRQJAP/5ciy1b\nL3NhUhsaOVy55MHXnPjdcTX0FaLi+ybXZIfIQ2P4rb19mVq1feMbCXhz+L1rG8oa\nt5lYKfpe8k83ZA==\n-----END RSA PRIVATE KEY-----";

    protected $cacheFile;

    public function init($extend = '') {
        $this->cacheFile = __DIR__ . '/guazi_cache.json';
    }

    protected function getHtml($url, $postData = null, $headers = []) {
        $ch = curl_init();
        $reqHeaders = array_merge([
            'User-Agent: ' . $this->api_ua,
            'Accept: */*',
            'Connection: Keep-Alive',
        ], $headers);

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => $reqHeaders,
            CURLOPT_COOKIEFILE => '',
            CURLOPT_COOKIEJAR => ''
        ]);

        if ($postData !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        }

        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function fetchLatestHosts() {
        foreach ($this->control_urls as $control) {
            $url = "{$control}/gz/initialize/getApiUrlList?parameter=key";
            $resp = $this->getHtml($url);
            if (!$resp) continue;
            
            $json = json_decode($resp, true);
            if (!$json || $json['code'] != 200 || empty($json['data'])) continue;
            
            $plain = base64_decode($json['data']);
            $hostsData = json_decode($plain, true);
            
            if (is_array($hostsData)) {
                if (isset($hostsData['list']) && is_array($hostsData['list'])) {
                    return $hostsData['list'];
                }
                if (is_array($hostsData) && count($hostsData) > 0 && is_string($hostsData[0])) {
                    return $hostsData;
                }
            }
        }
        return null;
    }

    protected function getDevice() {
        if (file_exists($this->cacheFile)) {
            $data = json_decode(file_get_contents($this->cacheFile), true);
            if ($data && !empty($data['deviceId'])) return $data;
        }
        $newDevice = [
            'deviceId' => $this->randomNumeric(15),
            'deviceKey' => $this->randomHex(40),
            'token' => '',
            'token_id' => '',
            'hosts' => $this->default_hosts,
            'host' => $this->default_hosts[0],
            'registered' => false
        ];
        file_put_contents($this->cacheFile, json_encode($newDevice));
        return $newDevice;
    }

    protected function saveDevice($dev) {
        file_put_contents($this->cacheFile, json_encode($dev));
    }

    protected function randomNumeric($len) {
        $s = '';
        for ($i = 0; $i < $len; $i++) $s .= rand(0, 9);
        return $s;
    }

    protected function randomHex($len) {
        $s = '';
        for ($i = 0; $i < $len; $i++) $s .= dechex(rand(0, 15));
        return strtoupper($s);
    }

    protected function aesEncrypt($text) {
        $encrypted = openssl_encrypt($text, 'AES-128-CBC', $this->aes_key, OPENSSL_RAW_DATA, $this->aes_iv);
        return strtoupper(bin2hex($encrypted));
    }

    protected function aesDecrypt($hexText, $key, $iv) {
        $binary = hex2bin($hexText);
        if (!$binary) return '';
        $decrypted = openssl_decrypt($binary, 'AES-128-CBC', $key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv);
        if ($decrypted === false) return false;
        
        $pad = ord($decrypted[strlen($decrypted) - 1]);
        if ($pad > 0 && $pad <= 16) {
            return substr($decrypted, 0, -$pad);
        }
        return $decrypted;
    }

    protected function rsaEncrypt($text) {
        $pubKey = "-----BEGIN PUBLIC KEY-----\n" . chunk_split($this->rsa_public_key, 64, "\n") . "-----END PUBLIC KEY-----";
        openssl_public_encrypt($text, $encrypted, $pubKey, OPENSSL_PKCS1_PADDING);
        return base64_encode($encrypted);
    }

    protected function rsaDecrypt($encryptedData) {
        $decoded = base64_decode($encryptedData);
        $keyRes = openssl_pkey_get_private($this->rsa_private_key);
        if (!$keyRes) return '';
        $details = openssl_pkey_get_details($keyRes);
        $keysize = ceil($details['bits'] / 8);
        $result = '';
        
        $chunks = str_split($decoded, $keysize);
        foreach ($chunks as $chunk) {
            if (openssl_private_decrypt($chunk, $decrypted, $this->rsa_private_key, OPENSSL_PKCS1_PADDING)) {
                $result .= $decrypted;
            }
        }
        return $result;
    }

    protected function sendRequest($data, $path, $isAuth = false) {
        $dev = $this->getDevice();
        
        if (!$isAuth && empty($dev['token'])) {
            $this->initToken();
            $dev = $this->getDevice();
        }

        $requestKey = $this->aesEncrypt(json_encode($data, JSON_UNESCAPED_UNICODE));
        $keys = $this->rsaEncrypt(json_encode(['iv' => $this->aes_iv, 'key' => $this->aes_key], JSON_UNESCAPED_UNICODE));
        
        if (!$requestKey || !$keys) return null;

        $t = (string)time();
        $signStr = "token_id={$dev['token_id']},token={$dev['token']},phone_type=1,request_key={$requestKey},app_id=1,time={$t},keys={$keys}{$this->sign_salt}";
        $signature = strtoupper(md5($signStr));

        $body = [
            'token' => $dev['token'],
            'token_id' => $dev['token_id'],
            'phone_type' => '1',
            'time' => $t,
            'phone_model' => $this->phone_model,
            'keys' => $keys,
            'request_key' => $requestKey,
            'signature' => $signature,
            'app_id' => '1',
            'ad_version' => '1'
        ];

        $headers = [
            'code: GZ0055',
            'deviceId: ' . $dev['deviceId'],
            'lang: zh_cn',
            'Version: 2608011',
            'PackageName: com.xf4a1daee2.g3520dce0d.f8a8ed889d20260813',
            'Ver: 3.0.5.2',
            'api-ver: 3.0.5.2',
            'Referer: ' . $dev['host']
        ];

        $respText = $this->getHtml($dev['host'] . $path, $body, $headers);
        $respJson = json_decode($respText ?: '{}', true);
        
        if (!$respJson || empty($respJson['data'])) return null;

        $dataSection = $respJson['data'];
        $encResponse = $dataSection['response_key'] ?? '';
        $encKeys = $dataSection['keys'] ?? '';

        if (!$encResponse) {
            if (isset($dataSection['list']) || isset($dataSection['vodInfo'])) return $dataSection;
            return null;
        }

        $respKey = $this->aes_key;
        $respIv = $this->aes_iv;

        if (!empty($encKeys)) {
            $keysJson = $this->rsaDecrypt($encKeys);
            if ($keysJson) {
                $keyInfo = json_decode($keysJson, true);
                if ($keyInfo) {
                    $respKey = $keyInfo['key'] ?? $respKey;
                    $respIv = $keyInfo['iv'] ?? $respIv;
                }
            }
        }

        $plain = $this->aesDecrypt($encResponse, $respKey, $respIv);
        if ($plain === false) return null;

        return json_decode($plain ?: '{}', true) ?: null;
    }

    protected function initToken() {
        $dev = $this->getDevice();
        
        $newHosts = $this->fetchLatestHosts();
        if ($newHosts) {
            $dev['hosts'] = $newHosts;
            $dev['host'] = $newHosts[0];
            $this->saveDevice($dev);
        }

        $params = [
            'new_key' => $dev['deviceKey'],
            'old_key' => $this->device_old_key,
            'phone_type' => 1,
            'code' => ''
        ];
        $result = $this->sendRequest($params, '/App/Authentication/Device/signUp', true);
        
        if ($result && !empty($result['token'])) {
            $dev['token'] = $result['token'];
            $dev['token_id'] = $result['app_user_id'] ?? '';
            $dev['registered'] = true;
            $this->saveDevice($dev);
        }
    }

    protected function request($data, $path) {
        $dev = $this->getDevice();
        foreach ($dev['hosts'] as $h) {
            $dev['host'] = $h;
            $this->saveDevice($dev);
            $res = $this->sendRequest($data, $path);
            if ($res !== null) return $res;
        }
        return null;
    }

    // ============================================================
    // 接口
    // ============================================================
    public function homeContent($filter) {
        $categories = [
            ['type_id' => 'hot', 'type_name' => '热门'],
            ['type_id' => '1', 'type_name' => '电影'],
            ['type_id' => '2', 'type_name' => '电视剧'],
            ['type_id' => '4', 'type_name' => '动漫'],
            ['type_id' => '3', 'type_name' => '综艺'],
            ['type_id' => '64', 'type_name' => '短剧'],
            ['type_id' => '74', 'type_name' => '漫剧'],
            ['type_id' => '33', 'type_name' => '儿童'],
        ];

        $filters = [];
        if ($filter) {
            $area = [['n'=>'全部','v'=>'0'],['n'=>'大陆','v'=>'大陆'],['n'=>'香港','v'=>'香港'],['n'=>'台湾','v'=>'台湾'],['n'=>'美国','v'=>'美国'],['n'=>'韩国','v'=>'韩国'],['n'=>'日本','v'=>'日本'],['n'=>'英国','v'=>'英国'],['n'=>'法国','v'=>'法国'],['n'=>'泰国','v'=>'泰国'],['n'=>'印度','v'=>'印度'],['n'=>'其他','v'=>'其他']];
            $year = [['n'=>'全部','v'=>'0']];
            for ($y = 2025; $y >= 2005; $y--) $year[] = ['n'=>(string)$y, 'v'=>(string)$y];
            $year[] = ['n'=>'更早', 'v'=>'2004'];
            $sort = [['n'=>'最新','v'=>'d_id'],['n'=>'最热','v'=>'d_hits'],['n'=>'推荐','v'=>'d_score']];

            foreach ($categories as $c) {
                $filters[$c['type_id']] = [
                    ['key'=>'area', 'name'=>'地区', 'value'=>$area],
                    ['key'=>'year', 'name'=>'年份', 'value'=>$year],
                    ['key'=>'sort', 'name'=>'排序', 'value'=>$sort]
                ];
            }
        }
        return ['class' => $categories, 'filters' => $filter ? $filters : (object)[]];
    }

    public function homeVideoContent() {
        $body = ['area'=>'0', 'year'=>'0', 'pageSize'=>'30', 'sort'=>'d_hits', 'page'=>'1', 'tid'=>'0'];
        $data = $this->request($body, '/App/IndexList/indexList');
        if (!$data || empty($data['list'])) return ['list' => []];

        $list = [];
        foreach ($data['list'] as $v) {
            $continu = $v['vod_continu'] ?? 0;
            $list[] = [
                'vod_id' => "{$v['vod_id']}/{$continu}",
                'vod_name' => $v['vod_name'] ?? '',
                'vod_pic' => $v['vod_pic'] ?? '',
                'vod_remarks' => $continu == 0 ? '电影' : "更新至{$continu}集"
            ];
        }
        return ['list' => $list];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        $hot = ($tid === 'hot');
        $reqTid = $hot ? '0' : strval($tid);
        $sort = $hot ? 'd_hits' : ($extend['sort'] ?? 'd_id');
        $area = $extend['area'] ?? '0';
        $year = $extend['year'] ?? '0';

        $body = ['area'=>$area, 'year'=>$year, 'pageSize'=>'30', 'sort'=>$sort, 'page'=>(string)$page, 'tid'=>$reqTid];
        $data = $this->request($body, '/App/IndexList/indexList');
        if (!$data || empty($data['list'])) return ['list' => []];

        $videos = [];
        foreach ($data['list'] as $v) {
            $continu = $v['vod_continu'] ?? 0;
            $videos[] = [
                'vod_id' => "{$v['vod_id']}/{$continu}",
                'vod_name' => $v['vod_name'] ?? '',
                'vod_pic' => $v['vod_pic'] ?? '',
                'vod_remarks' => $continu == 0 ? '电影' : "更新至{$continu}集"
            ];
        }
        return $this->pageResult($videos, $page, 9999, 30);
    }

    public function detailContent($ids) {
        $vodId = explode('/', $ids[0])[0];
        $t = (string)time();
        $dev = $this->getDevice();

        $body1 = ['token_id'=>$dev['token_id'], 'vod_id'=>$vodId, 'mobile_time'=>$t, 'token'=>$dev['token']];
        $playInfo = $this->request($body1, '/App/IndexPlay/playInfo');
        $body2 = ['vurl_cloud_id'=>'2', 'vod_d_id'=>$vodId];
        $show = $this->request($body2, '/App/Resource/Vurl/show');

        if (!$playInfo || empty($playInfo['vodInfo'])) return ['list' => []];
        
        $info = $playInfo['vodInfo'];
        $lines = [];
        if ($show && !empty($show['list'])) {
            foreach ($show['list'] as $index => $item) {
                if (empty($item['play'])) continue;
                $lastParam = ''; $lastName = '';
                foreach ($item['play'] as $k => $v) {
                    if (!empty($v['param'])) { $lastParam = $v['param']; $lastName = $k; }
                }
                if ($lastParam) {
                    $lineName = count($show['list']) === 1 ? $info['vod_name'] : strval($index + 1);
                    $lines[] = $lineName . '$' . $lastParam . '||' . $lastName;
                }
            }
        }

        $detail = [
            'vod_id' => $vodId, 'vod_name' => $info['vod_name'] ?? '', 'vod_pic' => $info['vod_pic'] ?? '',
            'vod_year' => $info['vod_year'] ?? '', 'vod_area' => $info['vod_area'] ?? '', 'vod_actor' => $info['vod_actor'] ?? '',
            'vod_director' => $info['vod_director'] ?? '', 'vod_content' => trim($info['vod_use_content'] ?? ''),
            'vod_play_from' => '天龙瓜子', 'vod_play_url' => implode('#', $lines)
        ];
        return ['list' => [$detail]];
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $body = ['keywords'=>$key, 'order_val'=>'1', 'page'=>(string)$page];
        $data = $this->request($body, '/App/Index/findMoreVod');
        if (!$data || empty($data['list'])) return ['list' => []];

        $videos = [];
        foreach ($data['list'] as $v) {
            $continu = $v['vod_continu'] ?? 0;
            $videos[] = [
                'vod_id' => "{$v['vod_id']}/{$continu}", 'vod_name' => $v['vod_name'] ?? '',
                'vod_pic' => $v['vod_pic'] ?? '', 'vod_remarks' => $continu == 0 ? '电影' : "更新至{$continu}集"
            ];
        }
        return $this->pageResult($videos, $page, 9999, 30);
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        $parts = explode('||', $id);
        if (count($parts) < 2) return ['parse' => 0, 'url' => ''];

        $params = [];
        foreach (explode('&', $parts[0]) as $pair) {
            $kv = explode('=', $pair, 2);
            if (count($kv) === 2) $params[$kv[0]] = $kv[1];
        }

        $resolutions = explode('@', $parts[1]);
        if (empty($resolutions[0])) return ['parse' => 0, 'url' => ''];

        $params['resolution'] = $resolutions[0];
        $data = $this->request($params, '/App/Resource/VurlDetail/showOne');
        $url = $data['url'] ?? '';
        if (!$url) return ['parse' => 0, 'url' => ''];

        return [
            'parse' => 0, 'playUrl' => '', 'url' => $url,
            'header' => (object)[ 'User-Agent' => $this->media_ua, 'Referer' => $this->media_referer ]
        ];
    }

    public function localProxy($param) { return null; }
}

(new Spider())->run();