<?php
/**
 * 豆瓣榜单 —— drpy 规则转 PHP 源
 * 基于「道长 PHP 写源」BaseSpider 框架
 *
 * 原规则要点：
 *   - 数据来自豆瓣小程序网关 api.douban.com/api/v2（Host: frodo.douban.com + apikey）
 *   - 推荐：subject_real_time_hotest
 *   - 分类：hot_gaia / tv_hot / show_hot / movie / tv / rank_list_movie / rank_list_tv（另保留 interests 片单分支）
 *   - 原规则 play_parse:false、无二级/搜索，本源是「榜单浏览 + 聚合搜索」源，不提供真实播放。
 *   - 自动跳其它源（重要）：列表项 vod_id 用 "msearch:片名" 触发 FongMi/TVBox 的 autoFallback：
 *     点击影片→本源详情返回空→客户端用片名对所有 changeable=1 的源做「片名完全相等」搜索，
 *     命中即跳到该源的同名影片详情页（与原 drpy 规则 vod_id:"msearch:"+TYPE 一致）。
 *     前置条件（在 config.php 里）：本源 changeable=0（作起点、避免搜回自己），其它 PHP 源 changeable=1。
 *     只有片名完全一致的影片才会被跳转，这正是 autoFallback 的原生规则。
 *   - 图片防盗链：FongMi/TVBox 约定为「真实URL@Referer=值@User-Agent=值」（参数在末尾），
 *     并已将 webp 改为 jpg 兼容老播放器。
 *
 * 筛选传参：框架 run() 未解析 filter，本源自行从 $_GET['filter'] / $_GET['fl'] 读取，
 *   支持 JSON、base64(JSON)、k=v,k2=v2 三种格式，例如：
 *   ?ac=videolist&t=movie&filter={"sort":"S","类型":"喜剧"}
 * 片单分类 interests 需要 douban 用户 id，经 $extend 或 $_GET['douban'] 传入。
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider
{
    private const API_BASE = 'http://api.douban.com/api/v2';
    private const APIKEY  = '0ac44ae016490db2204ce0a042db2916';
    private const COUNT   = 30;

    /**
     * 图片防盗链后缀：FongMi/TVBox 的 ImgUtil.getUrl() 约定为「真实URL@Referer=值@User-Agent=值」，
     * 客户端 split("@")[0] 取真实 URL、其余解析为请求头。
     * 注意：值中不能含 @；Referer 用 api.douban.com（实测 img*.doubanio.com 带此 Referer 返回 200）。
     */
    private const PIC_HEADER = '@Referer=https://api.douban.com/@User-Agent=Mozilla/5.0%20(Windows%20NT%2010.0;%20Win64;%20x64)%20AppleWebKit/537.36%20(KHTML,%20like%20Gecko)%20Chrome/113.0.0.0%20Safari/537.36';

    public function init($extend = '')
    {
        // 无需初始化
    }

    /** 小程序网关请求头（Host 指向 frodo，与 drpy 原规则一致） */
    private function doubanHeaders(): array
    {
        return [
            'Host'       => 'frodo.douban.com',
            'Connection' => 'Keep-Alive',
            'Referer'    => 'https://servicewechat.com/wx2f9b06c1de1ccfca/84/page-frame.html',
            'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36 MicroMessenger/7.0.9.501 NetType/WIFI MiniProgramEnv/Windows WindowsWechat',
        ];
    }

    /** 统一请求豆瓣小程序 API */
    private function api(string $path, array $params = []): array
    {
        $params['apikey'] = self::APIKEY;
        $url = self::API_BASE . $path . '?' . http_build_query($params);
        $html = $this->fetch($url, [], $this->doubanHeaders());
        $json = json_decode($html ?: '{}', true);
        return is_array($json) ? $json : [];
    }

    /** 把 [['n'=>名,'v'=>值], ...] 压成下拉筛选 */
    private function fv(array $pairs): array
    {
        $out = [];
        foreach ($pairs as $n => $v) {
            $out[] = ['n' => (string)$n, 'v' => (string)$v];
        }
        return $out;
    }

    /** 原 drpy 规则的完整筛选定义 */
    private function getFilters(): array
    {
        $years = ['全部' => '', '2023' => '2023', '2022' => '2022', '2021' => '2021', '2020' => '2020', '2019' => '2019',
            '2010年代' => '2010年代', '2000年代' => '2000年代', '90年代' => '90年代', '80年代' => '80年代',
            '70年代' => '70年代', '60年代' => '60年代', '更早' => '更早'];
        $movieAreas = ['全部地区' => '', '华语' => '华语', '欧美' => '欧美', '韩国' => '韩国', '日本' => '日本',
            '中国大陆' => '中国大陆', '美国' => '美国', '中国香港' => '中国香港', '中国台湾' => '中国台湾',
            '英国' => '英国', '法国' => '法国', '德国' => '德国', '意大利' => '意大利', '西班牙' => '西班牙',
            '印度' => '印度', '泰国' => '泰国', '俄罗斯' => '俄罗斯', '加拿大' => '加拿大', '澳大利亚' => '澳大利亚',
            '爱尔兰' => '爱尔兰', '瑞典' => '瑞典', '巴西' => '巴西', '丹麦' => '丹麦'];
        $sortTSR = ['近期热度' => 'T', '首映时间' => 'R', '高分优先' => 'S'];

        return [
            'interests' => [
                ['key' => 'status',      'name' => '状态', 'value' => $this->fv(['想看' => 'mark', '在看' => 'doing', '看过' => 'done'])],
                ['key' => 'subtype_tag', 'name' => '形式', 'value' => $this->fv(['全部' => '', '电影' => 'movie', '电视' => 'tv'])],
                ['key' => 'year_tag',    'name' => '年代', 'value' => $this->fv(array_merge(['全部' => '全部'], array_slice($years, 1)))],
            ],
            'hot_gaia' => [
                ['key' => 'sort', 'name' => '排序', 'value' => $this->fv(['热度' => 'recommend', '最新' => 'time', '评分' => 'rank'])],
                ['key' => 'area', 'name' => '地区', 'value' => $this->fv(['全部' => '全部', '华语' => '华语', '欧美' => '欧美', '韩国' => '韩国', '日本' => '日本'])],
            ],
            'tv_hot' => [
                ['key' => 'type', 'name' => '分类', 'value' => $this->fv(['综合' => 'tv_hot', '国产剧' => 'tv_domestic', '欧美剧' => 'tv_american', '日剧' => 'tv_japanese', '韩剧' => 'tv_korean', '动画' => 'tv_animation'])],
            ],
            'show_hot' => [
                ['key' => 'type', 'name' => '分类', 'value' => $this->fv(['综合' => 'show_hot', '国内' => 'show_domestic', '国外' => 'show_foreign'])],
            ],
            'movie' => [
                ['key' => '类型', 'name' => '类型', 'value' => $this->fv(['全部类型' => '', '喜剧' => '喜剧', '爱情' => '爱情', '动作' => '动作', '科幻' => '科幻', '动画' => '动画', '悬疑' => '悬疑', '犯罪' => '犯罪', '惊悚' => '惊悚', '冒险' => '冒险', '音乐' => '音乐', '历史' => '历史', '奇幻' => '奇幻', '恐怖' => '恐怖', '战争' => '战争', '传记' => '传记', '歌舞' => '歌舞', '武侠' => '武侠', '情色' => '情色', '灾难' => '灾难', '西部' => '西部', '纪录片' => '纪录片', '短片' => '短片'])],
                ['key' => '地区', 'name' => '地区', 'value' => $this->fv($movieAreas)],
                ['key' => 'sort', 'name' => '排序', 'value' => $this->fv($sortTSR)],
                ['key' => '年代', 'name' => '年代', 'value' => $this->fv(array_merge(['全部年代' => ''], array_slice($years, 1)))],
            ],
            'tv' => [
                ['key' => '类型', 'name' => '类型', 'value' => $this->fv(['不限' => '', '电视剧' => '电视剧', '综艺' => '综艺'])],
                ['key' => '电视剧形式', 'name' => '电视剧形式', 'value' => $this->fv(['不限' => '', '喜剧' => '喜剧', '爱情' => '爱情', '悬疑' => '悬疑', '动画' => '动画', '武侠' => '武侠', '古装' => '古装', '家庭' => '家庭', '犯罪' => '犯罪', '科幻' => '科幻', '恐怖' => '恐怖', '历史' => '历史', '战争' => '战争', '动作' => '动作', '冒险' => '冒险', '传记' => '传记', '剧情' => '剧情', '奇幻' => '奇幻', '惊悚' => '惊悚', '灾难' => '灾难', '歌舞' => '歌舞', '音乐' => '音乐'])],
                ['key' => '综艺形式', 'name' => '综艺形式', 'value' => $this->fv(['不限' => '', '真人秀' => '真人秀', '脱口秀' => '脱口秀', '音乐' => '音乐', '歌舞' => '歌舞'])],
                ['key' => '地区', 'name' => '地区', 'value' => $this->fv(['全部地区' => '', '华语' => '华语', '欧美' => '欧美', '国外' => '国外', '韩国' => '韩国', '日本' => '日本', '中国大陆' => '中国大陆', '中国香港' => '中国香港', '美国' => '美国', '英国' => '英国', '泰国' => '泰国', '中国台湾' => '中国台湾', '意大利' => '意大利', '法国' => '法国', '德国' => '德国', '西班牙' => '西班牙', '俄罗斯' => '俄罗斯', '瑞典' => '瑞典', '巴西' => '巴西', '丹麦' => '丹麦', '印度' => '印度', '加拿大' => '加拿大', '爱尔兰' => '爱尔兰', '澳大利亚' => '澳大利亚'])],
                ['key' => 'sort', 'name' => '排序', 'value' => $this->fv(['近期热度' => 'T', '首播时间' => 'R', '高分优先' => 'S'])],
                ['key' => '年代', 'name' => '年代', 'value' => $this->fv(array_merge(['全部' => ''], array_slice($years, 1)))],
                ['key' => '平台', 'name' => '平台', 'value' => $this->fv(['全部' => '', '腾讯视频' => '腾讯视频', '爱奇艺' => '爱奇艺', '优酷' => '优酷', '湖南卫视' => '湖南卫视', 'Netflix' => 'Netflix', 'HBO' => 'HBO', 'BBC' => 'BBC', 'NHK' => 'NHK', 'CBS' => 'CBS', 'NBC' => 'NBC', 'tvN' => 'tvN'])],
            ],
            'rank_list_movie' => [
                ['key' => '榜单', 'name' => '榜单', 'value' => $this->fv(['实时热门电影' => 'movie_real_time_hotest', '一周口碑电影榜' => 'movie_weekly_best', '豆瓣电影Top250' => 'movie_top250'])],
            ],
            'rank_list_tv' => [
                ['key' => '榜单', 'name' => '榜单', 'value' => $this->fv(['实时热门电视' => 'tv_real_time_hotest', '华语口碑剧集榜' => 'tv_chinese_best_weekly', '全球口碑剧集榜' => 'tv_global_best_weekly', '国内口碑综艺榜' => 'show_chinese_best_weekly', '国外口碑综艺榜' => 'show_global_best_weekly'])],
            ],
        ];
    }

    /** 首页：分类 + 筛选 */
    public function homeContent($filter)
    {
        $names = explode('&', '热门电影&热播剧集&热播综艺&电影筛选&电视筛选&电影榜单&电视榜单');
        $urls  = explode('&', 'hot_gaia&tv_hot&show_hot&movie&tv&rank_list_movie&rank_list_tv');
        $class = [];
        foreach ($urls as $i => $tid) {
            $class[] = ['type_id' => $tid, 'type_name' => $names[$i] ?? $tid];
        }
        return ['class' => $class, 'filters' => $this->getFilters()];
    }

    /** 首页推荐：实时热门 */
    public function homeVideoContent()
    {
        $res = $this->api('/subject_collection/subject_real_time_hotest/items', ['start' => 0, 'count' => self::COUNT]);
        $list = [];
        foreach (($res['subject_collection_items'] ?? []) as $item) {
            $vod = $this->parseVod($item);
            if ($vod) $list[] = $vod;
        }
        return ['list' => $list];
    }

    /** 处理豆瓣图片：webp 改 jpg（兼容老播放器）+ 追加防盗链 header 前缀 */
    private function picUrl(string $url): string
    {
        if ($url === '') return '';
        // 豆瓣现返回 .webp，改成 .jpg 服务端同样返回标准 JPEG
        $url = preg_replace('/\.webp(\?.*)?$/i', '.jpg$1', $url);
        // FongMi/TVBox：参数须拼在 URL 末尾（@Referer=..@User-Agent=..）
        return $url . self::PIC_HEADER;
    }

    /** 单个条目 -> vod（过滤掉 ad / playlist 等非影视条目，与原规则一致） */
    private function parseVod(array $item): ?array
    {
        $type = $item['type'] ?? '';
        if ($type !== 'movie' && $type !== 'tv') return null;
        $title = $item['title'] ?? '';
        if ($title === '' || $title === '未知电影') $title = '暂不支持展示';
        $rating = $item['rating']['value'] ?? '';
        $ratStr = ($rating !== '' && $rating !== null) ? (string)$rating : '暂无评分';
        $honors = [];
        foreach (($item['honor_infos'] ?? []) as $h) {
            if (!empty($h['title'])) $honors[] = $h['title'];
        }
        return [
            // msearch: 前缀触发客户端 autoFallback：用片名精确匹配跳配置里其它源详情页
            'vod_id'     => 'msearch:' . $title,
            'vod_name'   => $title,
            'vod_pic'    => $this->picUrl($item['pic']['normal'] ?? ''),
            'vod_remarks' => trim($ratStr . ' ' . implode('|', $honors)),
        ];
    }

    /** 解析筛选参数：兼容数组 / JSON / base64(JSON) / k=v,k2=v2 */
    private function normalizeFilter($filter): array
    {
        if (is_array($filter) && count($filter)) return $filter;
        $raw = '';
        foreach (['filter', 'fl'] as $k) {
            if (isset($_GET[$k]) && is_string($_GET[$k])) { $raw = $_GET[$k]; break; }
        }
        if ($raw === '') return [];
        $json = json_decode($raw, true);
        if (is_array($json)) return $json;
        $decoded = base64_decode($raw, true);
        if ($decoded !== false && $decoded !== '') {
            $json = json_decode($decoded, true);
            if (is_array($json)) return $json;
        }
        $arr = [];
        foreach (explode(',', $raw) as $pair) {
            if (strpos($pair, '=') !== false) {
                [$k, $v] = explode('=', $pair, 2);
                $arr[trim(urldecode($k))] = trim(urldecode($v));
            }
        }
        return $arr;
    }

    /** 解析 douban 用户 id（用于 interests 片单） */
    private function getDouban($extend): string
    {
        if (is_array($extend) && !empty($extend['douban'])) return (string)$extend['douban'];
        if (!empty($_GET['douban'])) return (string)$_GET['douban'];
        if (!empty($_GET['ext'])) {
            $d = json_decode(base64_decode($_GET['ext'], true) ?: '', true);
            if (is_array($d) && !empty($d['douban'])) return (string)$d['douban'];
        }
        return '';
    }

    /** 分类列表（含全部筛选逻辑，对齐原 drpy 一级 JS） */
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = [])
    {
        $pg = max(1, (int)$pg);
        $start = ($pg - 1) * self::COUNT;
        $fl = $this->normalizeFilter($filter);
        $douban = $this->getDouban($extend);

        $res = [];
        $items = [];
        $total = 0;

        switch (true) {
            case $tid === 'interests':
                if ($douban === '') break;
                $res = $this->api("/user/{$douban}/interests", [
                    'type' => 'movie',
                    'status' => $fl['status'] ?? 'mark',
                    'subtype_tag' => $fl['subtype_tag'] ?? '',
                    'year_tag' => $fl['year_tag'] ?? '全部',
                    'start' => $start, 'count' => self::COUNT,
                ]);
                foreach (($res['interests'] ?? []) as $it) {
                    if (!empty($it['subject'])) $items[] = $it['subject'];
                }
                $total = $res['total'] ?? 0;
                break;

            case $tid === 'hot_gaia':
                $res = $this->api('/movie/hot_gaia', [
                    'area' => $fl['area'] ?? '全部',
                    'sort' => $fl['sort'] ?? 'recommend',
                    'start' => $start, 'count' => self::COUNT,
                ]);
                $items = $res['items'] ?? [];
                $total = $res['total'] ?? 0;
                break;

            case $tid === 'tv_hot':
            case $tid === 'show_hot':
                $stype = $fl['type'] ?? $tid;
                $res = $this->api("/subject_collection/{$stype}/items", ['start' => $start, 'count' => self::COUNT]);
                $items = $res['subject_collection_items'] ?? [];
                $total = $res['total'] ?? 0;
                break;

            case strpos($tid, 'rank_list') === 0:
                $id = $tid === 'rank_list_movie' ? 'movie_real_time_hotest' : 'tv_real_time_hotest';
                $id = $fl['榜单'] ?? $id;
                $res = $this->api("/subject_collection/{$id}/items", ['start' => $start, 'count' => self::COUNT]);
                $items = $res['subject_collection_items'] ?? [];
                $total = $res['total'] ?? 0;
                break;

            case $tid === 'movie':
            case $tid === 'tv':
                $sort = $fl['sort'] ?? 'T';
                // tags 只拼接筛选维度的值；sort 单独作为排序参数。
                // （原 drpy 规则把 sort 也拼进 tags，会产出 "S,喜剧" 等无效标签导致 0 条，此处修正。）
                $tagValues = $fl;
                unset($tagValues['sort']);
                $tags = $tagValues ? implode(',', array_values($tagValues)) : '';
                if ($tid === 'movie') {
                    $selected = ['类型' => $fl['类型'] ?? '', '地区' => $fl['地区'] ?? ''];
                } else {
                    // 与原规则一致：形式字段由「类型」派生
                    $selected = [
                        '类型' => $fl['类型'] ?? '',
                        '形式' => !empty($fl['类型']) ? ($fl['类型'] . '地区') : '',
                        '地区' => $fl['地区'] ?? '',
                    ];
                }
                $res = $this->api("/{$tid}/recommend", [
                    'tags' => $tags,
                    'sort' => $sort,
                    'refresh' => 0,
                    'selected_categories' => json_encode($selected, JSON_UNESCAPED_UNICODE),
                    'start' => $start, 'count' => self::COUNT,
                ]);
                $items = $res['items'] ?? [];
                $total = $res['total'] ?? 0;
                break;
        }

        $list = [];
        foreach ($items as $item) {
            $vod = $this->parseVod($item);
            if ($vod) $list[] = $vod;
        }
        return $this->pageResult($list, $pg, $total, self::COUNT);
    }

    /** 详情：补全原规则缺失的二级，走 /subject/{id}（电影、电视通用） */
    public function detailContent($ids)
    {
        $id = $ids[0] ?? '';
        // msearch: 开头由客户端 autoFallback 接管（用片名跳其它源），本接口返回空即可
        if (strpos($id, 'msearch:') === 0) return ['list' => []];
        $parts = explode('$', $id, 2);
        $type = $parts[0] ?? 'movie';
        $sid  = $parts[1] ?? '';
        if ($sid === '' || !in_array($type, ['movie', 'tv'], true)) {
            return ['list' => []];
        }
        $d = $this->api('/subject/' . $sid);
        if (empty($d['title'])) return ['list' => []];

        $title = $d['title'];
        $names = function ($key) use ($d) {
            $out = [];
            foreach (($d[$key] ?? []) as $one) {
                if (!empty($one['name'])) $out[] = $one['name'];
            }
            return implode(' ', $out);
        };
        $rating = $d['rating']['value'] ?? '';
        return ['list' => [[
            'vod_id'       => $id,
            'vod_name'     => $title,
            'vod_pic'      => $this->picUrl($d['pic']['normal'] ?? ''),
            'vod_year'     => $d['year'] ?? '',
            'vod_area'     => implode(' ', $d['countries'] ?? []),
            'vod_type'     => implode(' ', $d['genres'] ?? []),
            'vod_actor'    => $names('actors'),
            'vod_director' => $names('directors'),
            'vod_lang'     => implode(' ', $d['languages'] ?? []),
            'vod_duration' => implode(' ', $d['durations'] ?? []),
            'vod_content'  => $d['intro'] ?? '',
            'vod_remarks'  => $rating !== '' ? (string)$rating : '暂无评分',
            // 兜底：若未配 indexs 而进入了详情，播放线路指向豆瓣影片页（可看可跳转）
            'vod_play_from' => '豆瓣',
            'vod_play_url'  => $title . '$' . $sid,
        ]]];
    }

    /** 搜索：补全原规则缺失的搜索（小程序 /search/weixin） */
    public function searchContent($key, $quick = false, $pg = 1)
    {
        $pg = max(1, (int)$pg);
        $start = ($pg - 1) * self::COUNT;
        $res = $this->api('/search/weixin', ['q' => $key, 'start' => $start, 'count' => self::COUNT]);
        $list = [];
        foreach (($res['items'] ?? []) as $it) {
            if (($it['layout'] ?? '') !== 'subject') continue;
            $t = $it['target'] ?? [];
            if (empty($t['id']) || empty($t['title'])) continue;
            $type = (strpos(($t['uri'] ?? ''), '/movie/') !== false) ? 'movie' : 'tv';
            $rating = $t['rating']['value'] ?? '';
            $list[] = [
                'vod_id'      => 'msearch:' . $t['title'],
                'vod_name'    => $t['title'],
                'vod_pic'     => $this->picUrl($t['cover_url'] ?? ''),
                'vod_year'    => $t['year'] ?? '',
                'vod_remarks' => ($rating !== '' && $rating !== null) ? (string)$rating : '暂无评分',
            ];
        }
        return $this->pageResult($list, $pg, $res['total'] ?? 0, self::COUNT);
    }

    /**
     * 播放：本源不提供真实播放（原规则 play_parse:false）。
     * 正常路径靠站点 indexs=1 跳聚合搜索页，根本不会走到这里；
     * 此处仅作详情兜底——指向豆瓣影片页。
     */
    public function playerContent($flag, $id, $vipFlags = [])
    {
        $sid = trim((string)$id);
        $url = 'https://movie.douban.com/subject/' . rawurlencode($sid) . '/';
        return [
            'parse'  => 0,
            'play'   => 1,
            'url'    => $url,
            'header' => ['User-Agent' => $this->doubanHeaders()['User-Agent'], 'Referer' => 'https://www.douban.com/'],
        ];
    }
}

(new Spider())->run();
