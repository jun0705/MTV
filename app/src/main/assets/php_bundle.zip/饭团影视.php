<?php
/**
 * 饭团影院 - 影视仓 PHP 最终完美版
 * 已修复：首页/分类图片抓取、筛选参数拼接、多线路精准绑定
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    
    protected $HOST = 'http://www.gxykl.com';
    protected $UA = 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36';

    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    protected function fetchHtml($url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => [
                'User-Agent: ' . $this->UA,
                'Referer: ' . $this->HOST
            ]
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function cleanText($text) {
        if (!$text) return '';
        $text = str_replace(['&nbsp;', "\n", "\r"], ' ', $text);
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    protected function fixUrl($url) {
        if (!$url) return '';
        if (strpos($url, 'http') === 0) return $url;
        if (strpos($url, '//') === 0) return 'http:' . $url;
        if (strpos($url, '/') === 0) return rtrim($this->HOST, '/') . $url;
        return rtrim($this->HOST, '/') . '/' . $url;
    }

    // ============================================================
    // 列表解析 (强制优先抓取 data-original 真实图片)
    // ============================================================
    protected function getList($html) {
        $vlist = [];
        if (!$html) return $vlist;

        // 匹配整个卡片外层 div
        $pattern = '/<div[^>]*class="[^"]*col-md-2[^"]*element[^"]*"[^>]*>(.*?)<\/div>\s*<\/div>\s*<\/div>/is';
        if (preg_match_all($pattern, $html, $matches)) {
            foreach ($matches[1] as $item) {
                // 1. 提取名称
                $name = '';
                if (preg_match('/<a[^>]*title="([^"]*)"/is', $item, $m)) {
                    $name = $m[1];
                }

                // 2. 提取图片 (强制优先 data-original，拦截 nopic 空白图)
                $pic = '';
                if (preg_match('/<img[^>]*data-original="([^"]*)"/is', $item, $m)) {
                    $pic = $this->fixUrl($m[1]);
                } elseif (preg_match('/<img[^>]*src="([^"]*)"/is', $item, $m)) {
                    if (strpos($m[1], 'nopic') === false) {
                        $pic = $this->fixUrl($m[1]);
                    }
                }

                // 3. 提取备注 (更新至XX集)
                $remark = '';
                if (preg_match('/<div[^>]*class="[^"]*notes[^"]*"[^>]*>(.*?)<\/div>/is', $item, $m)) {
                    $remark = $this->cleanText(strip_tags($m[1]));
                }

                // 4. 提取链接
                $href = '';
                if (preg_match('/<a[^>]*href="([^"]*)"/is', $item, $m)) {
                    $href = $this->fixUrl($m[1]);
                }

                if ($name && $href) {
                    $vlist[] = [
                        'vod_id' => $href,
                        'vod_name' => $this->cleanText($name),
                        'vod_pic' => $pic,
                        'vod_remarks' => $remark
                    ];
                }
            }
        }
        return $vlist;
    }

    // ============================================================
    // 壳子标准接口
    // ============================================================

    public function init($extend = '') {}

    public function homeContent($filter) {
        $classes = [
            ['type_name' => '电影', 'type_id' => 'dianying'],
            ['type_name' => '电视剧', 'type_id' => 'lianxuju'],
            ['type_name' => '综艺', 'type_id' => 'zongyi'],
            ['type_name' => '动漫', 'type_id' => 'dongman']
        ];

        $filters = [
            "dianying" => [
                ["key" => "class", "name" => "类型", "value" => $this->getClassList()],
                ["key" => "area", "name" => "地区", "value" => $this->getAreaList(true)],
                ["key" => "year", "name" => "年份", "value" => $this->getYearList()]
            ],
            "lianxuju" => [
                ["key" => "area", "name" => "地区", "value" => $this->getAreaList(true)],
                ["key" => "year", "name" => "年份", "value" => $this->getYearList()]
            ],
            "zongyi" => [
                ["key" => "area", "name" => "地区", "value" => $this->getAreaList(false)],
                ["key" => "year", "name" => "年份", "value" => $this->getYearList()]
            ],
            "dongman" => [
                ["key" => "area", "name" => "地区", "value" => $this->getAreaList(false)],
                ["key" => "year", "name" => "年份", "value" => $this->getYearList()]
            ]
        ];

        $list = $this->getList($this->fetchHtml($this->HOST));
        $this->outputJson(['class' => $classes, 'filters' => $filters, 'list' => $list]);
    }

    protected function getClassList() {
        $arr = [["n" => "全部", "v" => ""]];
        $types = ["动作", "喜剧", "爱情", "恐怖", "科幻", "剧情", "战争", "犯罪", "动画", "奇幻", "武侠", "冒险", "悬疑", "惊悚", "古装", "历史", "灾难"];
        foreach ($types as $t) $arr[] = ["n" => $t, "v" => $t];
        return $arr;
    }

    protected function getAreaList($full = true) {
        $arr = [["n" => "全部", "v" => ""]];
        $areas = ["大陆", "香港", "台湾", "美国", "法国", "英国", "日本", "韩国", "德国", "泰国", "印度", "其它"];
        if (!$full) {
            $areas = ["大陆", "香港", "台湾", "美国", "日本", "韩国", "其它"];
        }
        foreach ($areas as $a) $arr[] = ["n" => $a, "v" => $a];
        return $arr;
    }

    protected function getYearList() {
        $arr = [["n" => "全部", "v" => ""]];
        for ($i = 2026; $i >= 2016; $i--) {
            $arr[] = ["n" => (string)$i, "v" => (string)$i];
        }
        $arr[] = ["n" => "更早", "v" => "2015"];
        return $arr;
    }

    public function homeVideoContent() {
        $list = $this->getList($this->fetchHtml($this->HOST));
        $this->outputJson(['list' => $list]);
    }

    // ============================================================
    // 分类页 (支持筛选、翻页)
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));

        $area = !empty($extend['area']) ? $extend['area'] : '';
        $year = !empty($extend['year']) ? $extend['year'] : '';
        $class_filter = !empty($extend['class']) ? $extend['class'] : '';

        $base_url = "{$this->HOST}/t/{$tid}";
        
        $filter_parts = [];
        if ($class_filter) $filter_parts[] = "class/" . urlencode($class_filter);
        if ($area) $filter_parts[] = "area/" . urlencode($area);
        if ($year) $filter_parts[] = "year/" . urlencode($year);

        if (!empty($filter_parts)) {
            $filter_path = implode('/', $filter_parts);
            $url = ($page == 1) ? "{$base_url}/{$filter_path}.html" : "{$base_url}/{$filter_path}/page/{$page}.html";
        } else {
            $url = ($page == 1) ? "{$base_url}.html" : "{$base_url}/page/{$page}.html";
        }

        $html = $this->fetchHtml($url);
        $list = $this->getList($html);

        $this->outputJson([
            'list' => $list,
            'page' => $page,
            'pagecount' => 9999,
            'limit' => 90,
            'total' => 999999
        ]);
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $this->outputJson(['list' => [], 'page' => 1]);
    }

    // ============================================================
    // 详情页 (按 ID 精准绑定多条线路)
    // ============================================================
    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $url = $this->fixUrl($id);
        $html = $this->fetchHtml($url);
        if (!$html) $this->outputJson(['list' => []]);

        $info = ['vod_id' => $id];

        // 基础信息
        if (preg_match('/<h4[^>]*class="[^"]*line-height-40[^"]*"[^>]*>(.*?)<\/h4>/is', $html, $m)) {
            $info['vod_name'] = $this->cleanText(strip_tags($m[1]));
        }
        if (preg_match('/<img[^>]*class="[^"]*lazy[^"]*"[^>]*data-original="([^"]+)"/is', $html, $m)) {
            $info['vod_pic'] = $this->fixUrl($m[1]);
        }
        if (preg_match('/<div[^>]*class="[^"]*notes[^"]*"[^>]*>(.*?)<\/div>/is', $html, $m)) {
            $info['vod_remarks'] = $this->cleanText(strip_tags($m[1]));
        }

        // 详细信息提取
        if (preg_match('/类型[：:]\s*([^\s<]+)/u', $html, $m)) $info['type_name'] = trim($m[1]);
        if (preg_match('/地区[：:]<\/span>([^<]+)/u', $html, $m)) $info['vod_area'] = trim($m[1]);
        if (preg_match('/年份[：:]<\/span>([^<]+)/u', $html, $m)) $info['vod_year'] = trim($m[1]);
        if (preg_match('/主演：<\/span>([\s\S]*?)<\/div>/u', $html, $m)) $info['vod_actor'] = $this->cleanText(strip_tags($m[1]));
        if (preg_match('/导演：<\/span>([\s\S]*?)<\/div>/u', $html, $m)) $info['vod_director'] = $this->cleanText(strip_tags($m[1]));

        // 简介
        if (preg_match('/<div[^>]*class="[^"]*media-item[^"]*"[^>]*>.*?简介：<p>([\s\S]*?)<\/p>/is', $html, $m)) {
            $info['vod_content'] = $this->cleanText(strip_tags($m[1]));
        } elseif (preg_match('/<meta[^>]*name="description"[^>]*content="([^"]*)"/is', $html, $m)) {
            $info['vod_content'] = $m[1];
        }

        // 🎯 解析播放列表 (精准匹配 lines-X 的 tab 和 剧集)
        $tabs = [];
        $play_lists = [];

        if (preg_match_all('/<button[^>]*id="lines-(\d+)-tab"[^>]*>(.*?)<\/button>/is', $html, $btnMatches, PREG_SET_ORDER)) {
            foreach ($btnMatches as $btn) {
                $lid = $btn[1];
                $line_name = $this->cleanText(strip_tags($btn[2]));

                $div_pattern = '/<div[^>]*id="lines-' . $lid . '"[^>]*>([\s\S]*?)<\/div>/is';
                
                if (preg_match($div_pattern, $html, $divMatch)) {
                    $divContent = $divMatch[1];
                    $items = [];

                    if (preg_match_all('/<a[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/is', $divContent, $aMatches, PREG_SET_ORDER)) {
                        foreach ($aMatches as $a) {
                            $epName = $this->cleanText(strip_tags($a[2]));
                            $epHref = $this->fixUrl($a[1]);
                            if ($epName && $epHref) {
                                $items[] = "{$epName}\${$epHref}";
                            }
                        }
                    }

                    if (!empty($items)) {
                        $tabs[] = $line_name;
                        $play_lists[] = implode('#', $items);
                    }
                }
            }
        }

        // 兜底
        if (empty($tabs)) {
            if (preg_match_all('/<ul[^>]*class="[^"]*playlist[^"]*"[^>]*>(.*?)<\/ul>/is', $html, $ulMatches)) {
                $idx = 1;
                foreach ($ulMatches[1] as $ulHtml) {
                    $items = [];
                    if (preg_match_all('/<a[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/is', $ulHtml, $aMatches, PREG_SET_ORDER)) {
                        foreach ($aMatches as $a) {
                            $epName = $this->cleanText(strip_tags($a[2]));
                            $epHref = $this->fixUrl($a[1]);
                            if ($epName && $epHref) {
                                $items[] = "{$epName}\${$epHref}";
                            }
                        }
                    }
                    if (!empty($items)) {
                        $tabs[] = "线路" . $idx;
                        $play_lists[] = implode('#', $items);
                        $idx++;
                    }
                }
            }
        }

        $info['vod_play_from'] = !empty($tabs) ? implode('$$$', $tabs) : '饭团线路';
        $info['vod_play_url'] = !empty($play_lists) ? implode('$$$', $play_lists) : '';

        $this->outputJson(['list' => [$info]]);
    }

    // ============================================================
    // 播放解析
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $playUrl = $this->fixUrl($id);
        $html = $this->fetchHtml($playUrl);

        // 1. 尝试 player_aaaa 解析
        if (preg_match('/var\s+player_aaaa\s*=\s*(\{[^;]+?\})\s*(?:;|<\/script>)/is', $html, $m)) {
            $jsonStr = str_replace('\\/', '/', $m[1]);
            $jsonStr = preg_replace('/([{,])\s*([a-zA-Z0-9_]+)\s*:/', '$1"$2":', $jsonStr);
            $jsonStr = preg_replace("/:\s*'([^']*)'/", ':"$1"', $jsonStr);
            $jsonStr = preg_replace('/,\s*}/', '}', $jsonStr);
            
            $data = json_decode($jsonStr, true);
            if ($data && isset($data['encrypt']) && $data['encrypt'] == 0 && !empty($data['url'])) {
                $this->outputJson(['parse' => 0, 'url' => $data['url'], 'header' => ['User-Agent' => $this->UA]]);
            }
        }

        // 2. 尝试 iframe 提取
        if (preg_match('/<iframe[^>]*src="([^"]+)"/is', $html, $m)) {
            $iframeSrc = $m[1];
            if (strpos($iframeSrc, 'dplayerno/index.php') !== false && preg_match('/url=([^&]+)/', $iframeSrc, $um)) {
                $realUrl = urldecode($um[1]);
                if ($realUrl) $this->outputJson(['parse' => 0, 'url' => $realUrl, 'header' => ['User-Agent' => $this->UA]]);
            }
        }

        // 3. 直接匹配 m3u8
        if (preg_match('/["\'](https?:\/\/[^"\']+\.m3u8[^"\']*)["\']/i', $html, $m)) {
            $this->outputJson(['parse' => 0, 'url' => $m[1], 'header' => ['User-Agent' => $this->UA]]);
        }

        // 4. 兜底
        $this->outputJson(['parse' => 1, 'url' => $playUrl, 'header' => ['User-Agent' => $this->UA]]);
    }
}

(new Spider())->run();