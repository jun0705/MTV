<?php
/**
 * 多多影视 - 影视仓 PHP 最终完美版 (绝对与 Python 一致)
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    protected $host = 'https://dduotv.com';
    
    protected $CLIENT_ID = '8f3d2a1c7b6e5d4c9a0b1f2e3d4c5b6a';
    protected $WEB_SIGN  = 'ddtvf65f3a83d6d9ad6f';
    protected $SIGN_FINGER = 'WF-2c064bc5b3400788f31b848849bc3a60f835423ba2dfe69d7ea93974c216e4f2';
    protected $SIGN_SK = 'WEB-50a8e9c84a1dc05669a692ded99a2dac46527229e607a7be15db88dbc59059d1';
    protected $SIGN_ID = 'com.web.player';
    
    protected $UA = 'Mozilla/5.0 (Linux; Android 13; SM-G9910) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

    protected $TYPE_MAP = [
        ['type_id' => '1', 'type_name' => '电影'],
        ['type_id' => '2', 'type_name' => '剧集'],
        ['type_id' => '3', 'type_name' => '动漫'],
        ['type_id' => '4', 'type_name' => '综艺'],
    ];

    protected $OFFICIAL_SITES = ['v.qq.com', 'v.youku.com', 'iqiyi.com', 'mgtv.com', 'bilibili.com', 'b23.tv', 'tv.sohu.com', 'le.com'];

    public function init($extend = '') {}

    protected function getHeaders($extra = []) {
        $h = [
            'User-Agent' => $this->UA,
            'Accept' => 'application/json',
            'X-Client' => $this->CLIENT_ID,
            'web-sign' => $this->WEB_SIGN,
            'Referer' => $this->host . '/'
        ];
        return array_merge($h, $extra);
    }

    protected function getJson($url) {
        $res = $this->fetch($url, [], $this->getHeaders());
        return json_decode($res ?: '{}', true) ?: [];
    }

    protected function cleanHtml($text) {
        if (!$text) return '';
        return trim(preg_replace('/\s+/', ' ', strip_tags($text)));
    }

    protected function joinVal($v) {
        if (!$v) return '';
        if (is_array($v)) return implode(',', $v);
        return str_replace(',', ',', (string)$v);
    }

    // ============================================================
    // Protobuf 打包 (确保二进制绝对一致，去掉会导致乱码的 utf8_encode)
    // ============================================================
    protected function pbVarint($n) {
        $out = '';
        while ($n > 127) {
            $out .= chr(($n & 0x7f) | 0x80);
            $n >>= 7;
        }
        $out .= chr($n & 0x7f);
        return $out;
    }

    protected function pbString($field, $s) {
        $b = (string)$s; // 不要 utf8_encode，Python 里直接 s.encode('utf-8')
        return $this->pbVarint(($field << 3) | 2) . $this->pbVarint(strlen($b)) . $b;
    }

    protected function pbFieldVar($field, $val) {
        return $this->pbVarint($field << 3) . $this->pbVarint($val);
    }

    // ============================================================
    // 解密站内 Token (百分百复刻)
    // ============================================================
    protected function decodePlayUrl($token, $fromName) {
        $ts = (string)round(microtime(true) * 1000);
        $nonce = bin2hex(random_bytes(16));
        $raw = "finger={$this->SIGN_FINGER}&id={$this->SIGN_ID}&nonce={$nonce}&sk={$this->SIGN_SK}&time={$ts}&v=1";
        $sign = strtoupper(hash('sha256', $raw));

        $body = '';
        $body .= $this->pbString(1, $token);
        $body .= $this->pbString(2, $fromName);
        $body .= $this->pbFieldVar(3, intval($ts));
        $body .= $this->pbString(4, $nonce);
        $body .= $this->pbString(5, $sign);
        $body .= $this->pbString(6, $this->SIGN_ID);
        $body .= $this->pbFieldVar(7, 1);

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->host . '/api.php/web/decode/url',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_HTTPHEADER => [
                'User-Agent: ' . $this->UA,
                'Content-Type: application/x-protobuf; charset=ISO-8859-1',
                'Accept: application/x-protobuf',
                'X-Client: ' . $this->CLIENT_ID,
                'web-sign: ' . $this->WEB_SIGN,
                'Referer: ' . $this->host . '/'
            ]
        ]);
        $rawRes = curl_exec($ch);
        curl_close($ch);

        if (!$rawRes) return null;

        // 正则提取 (完美应对 "解码成功Qhttp://..." )
        if (preg_match('/https?:\/\/[\x21-\x7e]+/', $rawRes, $m)) {
            return trim($m[0]);
        }
        return null;
    }

    // ============================================================
    // 首页
    // ============================================================
    public function homeContent($filter) {
        $classes = $this->TYPE_MAP;
        $filters = [];
        if ($filter) {
            foreach ($this->TYPE_MAP as $t) {
                $tid = $t['type_id']; $name = $t['type_name'];
                $years = [["v"=>"", "n"=>"全部"]];
                $baseYear = 2011;
                if ($name == '电影') $baseYear = 2016;
                if ($name == '剧集') $baseYear = 2021;
                $now = intval(date('Y'));
                for ($y = $now; $y >= $baseYear; $y--) $years[] = ["v"=>(string)$y, "n"=>(string)$y];
                $years[] = ["v"=>"更早", "n"=>"更早"];

                $classList = $this->FILTER_CLASS_MAP()[$name] ?? [];
                $areaList = $this->FILTER_AREA_MAP()[$name] ?? [];
                $filters[$tid] = [
                    ["key"=>"sort", "name"=>"排序", "value"=>[["v"=>"hits","n"=>"人气"],["v"=>"time","n"=>"最新"],["v"=>"score","n"=>"评分"],["v"=>"year","n"=>"年份"]]],
                    ["key"=>"class", "name"=>"类型", "value"=>array_merge([["v"=>"","n"=>"全部"]], array_map(function($v){return ["v"=>$v,"n"=>$v];}, $classList))],
                    ["key"=>"area", "name"=>"地区", "value"=>array_merge([["v"=>"","n"=>"全部"]], array_map(function($v){return ["v"=>$v,"n"=>$v];}, $areaList))],
                    ["key"=>"year", "name"=>"年份", "value"=>$years]
                ];
            }
        }
        $json = $this->getJson($this->host . '/api.php/web/index/home');
        $list = [];
        if ($json && $json['code'] == 200 && !empty($json['data'])) {
            $data = $json['data']; $seen = [];
            $allVids = array_merge($data['recommend'] ?? [], $data['categories'] ? array_reduce($data['categories'], function($carry, $item){ return array_merge($carry, $item['videos'] ?? []); }, []) : []);
            foreach ($allVids as $v) {
                if (empty($v['vod_id']) || isset($seen[$v['vod_id']])) continue;
                $seen[$v['vod_id']] = true;
                $list[] = ['vod_id' => (string)$v['vod_id'], 'vod_name' => $v['vod_name'] ?? '', 'vod_pic' => $v['vod_pic'] ?? '', 'vod_remarks' => $v['vod_remarks'] ?? ''];
            }
        }
        return ['class' => $classes, 'filters' => $filter ? (object)$filters : (object)[], 'list' => array_slice($list, 0, 30)];
    }

    public function homeVideoContent() { return ['list' => []]; }

    protected function FILTER_CLASS_MAP() {
        return [
            '电影' => ['动作','喜剧','爱情','科幻','恐怖','悬疑','犯罪','战争','动画','冒险','历史','灾难','纪录','剧情'],
            '剧集' => ['爱情','古装','武侠','历史','家庭','喜剧','悬疑','犯罪','战争','奇幻','科幻','恐怖'],
            '综艺' => ['真人秀','音乐','脱口秀','歌舞','爱情'],
            '动漫' => ['冒险','奇幻','科幻','武侠','悬疑'],
        ];
    }

    protected function FILTER_AREA_MAP() {
        return [
            '电影' => ['大陆','香港','台湾','美国','日本','韩国','泰国','印度','英国','法国','德国','加拿大','西班牙','意大利','澳大利亚'],
            '剧集' => ['大陆','香港','台湾','美国','日本','韩国','泰国','英国'],
            '综艺' => ['大陆','香港','台湾','美国','日本','韩国'],
            '动漫' => ['大陆','日本','欧美'],
        ];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        if (is_string($extend)) $extend = json_decode($extend, true) ?: [];
        $typeName = '电影';
        foreach ($this->TYPE_MAP as $t) if ($t['type_id'] == $tid) $typeName = $t['type_name'];
        $sort = $extend['sort'] ?? 'hits'; $cls = $extend['class'] ?? ''; $area = $extend['area'] ?? ''; $year = $extend['year'] ?? '';
        $params = ['type_name'=>$typeName, 'page'=>$page, 'sort'=>$sort];
        if ($cls) $params['class'] = $cls;
        if ($area) $params['area'] = $area;
        if ($year) $params['year'] = $year;
        $url = $this->host . '/api.php/web/filter/vod?' . http_build_query($params);
        $json = $this->getJson($url);
        $videos = [];
        if ($json && $json['code'] == 200 && is_array($json['data'])) {
            foreach ($json['data'] as $v) {
                if (empty($v['vod_id'])) continue;
                $videos[] = ['vod_id' => (string)$v['vod_id'], 'vod_name' => $v['vod_name'] ?? '', 'vod_pic' => $v['vod_pic'] ?? '', 'vod_remarks' => $v['vod_remarks'] ?? ''];
            }
        }
        $hasMore = count($json['data'] ?? []) >= 18;
        return $this->pageResult($videos, $page, $hasMore ? $page + 1 : $page, 24);
    }

    public function detailContent($ids) {
        $vid = strval(explode('@', is_array($ids) ? $ids[0] : $ids)[0]);
        $url = $this->host . '/api.php/web/vod/get_detail?vod_id=' . urlencode($vid);
        $json = $this->getJson($url);
        if (!$json || $json['code'] != 200 || empty($json['data'][0])) return ['list' => []];
        $v = $json['data'][0];
        $info = [
            'vod_id' => (string)$v['vod_id'], 'vod_name' => $v['vod_name'] ?? '', 'vod_pic' => $v['vod_pic'] ?? '',
            'type_name' => $this->joinVal($v['vod_class'] ?? ''), 'vod_area' => $this->joinVal($v['vod_area'] ?? ''),
            'vod_year' => (string)($v['vod_year'] ?? ''), 'vod_actor' => $this->joinVal($v['vod_actor'] ?? ''),
            'vod_director' => $this->joinVal($v['vod_director'] ?? ''), 'vod_content' => $this->cleanHtml($v['vod_content'] ?? ''),
            'vod_remarks' => $v['vod_remarks'] ?? ''
        ];
        $sources = [];
        $playerMap = [];
        foreach ($json['vodplayer'] ?? [] as $p) { if (!empty($p['from'])) $playerMap[$p['from']] = $p; }
        $froms = explode('$$$', $v['vod_play_from'] ?? '');
        $urls = explode('$$$', $v['vod_play_url'] ?? '');
        $count = min(count($froms), count($urls));
        for ($i = 0; $i < $count; $i++) {
            $frm = trim($froms[$i]); $meta = $playerMap[$frm] ?? [];
            if (strval($meta['decode_status'] ?? '1') === '2') continue;
            $showName = $meta['show'] ?? $frm; $sortKey = floatval($meta['sort'] ?? 9999);
            $eps = [];
            foreach (explode('#', $urls[$i]) as $epi => $ep) {
                $idx = strpos($ep, '$'); if ($idx === false || $idx < 1) continue;
                $epName = trim(substr($ep, 0, $idx)); $token = trim(substr($ep, $idx + 1));
                if (!$epName || !$token) continue;
                $eps[] = $epName . '$IN@' . $frm . '@' . ($epi + 1) . '@' . $token;
            }
            if ($eps) $sources[] = ['name' => $showName, 'sort' => $sortKey, 'eps' => $eps];
        }
        $vodClass = $v['vod_class'] ?? '';
        $classStr = is_array($vodClass) ? ($vodClass[0] ?? '') : explode(',', $vodClass)[0];
        $extParams = ['name' => $v['vod_name'] ?? ''];
        if (!empty($v['vod_year'])) $extParams['year'] = $v['vod_year'];
        if (!empty($classStr)) $extParams['type'] = $classStr;
        $extJson = $this->getJson($this->host . '/api.php/web/internal/search_aggregate?' . http_build_query($extParams));
        if ($extJson && $extJson['code'] == 200 && is_array($extJson['data'])) {
            foreach ($extJson['data'] as $item) {
                if (empty($item['site_key']) || empty($item['site_name'])) continue;
                if (strval($item['decode_status'] ?? '1') === '2') continue;
                $eps = [];
                foreach (explode('#', $item['vod_play_url'] ?? '') as $epi => $ep) {
                    $idx = strpos($ep, '$'); if ($idx === false || $idx < 1) continue;
                    $epName = trim(substr($ep, 0, $idx)); $epUrl = trim(substr($ep, $idx + 1));
                    $isOfficial = false;
                    foreach ($this->OFFICIAL_SITES as $site) { if (stripos($epUrl, $site) !== false) { $isOfficial = true; break; } }
                    if ($isOfficial) continue;
                    if (!preg_match('/\.(m3u8|mp4)(\?|$|&)/i', $epUrl)) continue;
                    $eps[] = $epName . '$EXT@' . $item['site_key'] . '@' . ($epi + 1) . '@' . $epUrl;
                }
                if ($eps) $sources[] = ['name' => $item['site_name'], 'sort' => floatval($item['sort'] ?? 9999), 'eps' => $eps];
            }
        }
        usort($sources, function($a, $b) { return $a['sort'] <=> $b['sort']; });
        $info['vod_play_from'] = implode('$$$', array_column($sources, 'name'));
        $info['vod_play_url']  = implode('$$$', array_map(function($s) { return implode('#', $s['eps']); }, $sources));
        return ['list' => [$info]];
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $url = $this->host . '/api.php/web/search/index?' . http_build_query(['wd' => $key, 'page' => $page, 'limit' => 15]);
        $json = $this->getJson($url);
        $videos = [];
        if ($json && $json['code'] == 200 && is_array($json['data'])) {
            foreach ($json['data'] as $v) {
                if (empty($v['vod_id'])) continue;
                $videos[] = ['vod_id' => (string)$v['vod_id'], 'vod_name' => $v['vod_name'] ?? '', 'vod_pic' => $v['vod_pic'] ?? '', 'vod_remarks' => $v['vod_remarks'] ?? ''];
            }
        }
        $hasMore = count($json['data'] ?? []) >= 15;
        return $this->pageResult($videos, $page, $hasMore ? $page + 1 : $page, 15);
    }

    // ============================================================
    // 播放
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $header = (object)['User-Agent' => $this->UA];

        if ($id && preg_match('/^https?:\/\/.*\.(m3u8|mp4)(\?|$)/i', $id)) {
            return ['parse' => 0, 'url' => $id, 'header' => $header];
        }

        $parts = $id === null ? [] : explode('@', $id);
        $kind = $parts[0] ?? '';

        // 站外线路
        if ($kind === 'EXT' && count($parts) >= 4) {
            $extUrl = implode('@', array_slice($parts, 3));
            if (strpos($extUrl, 'http') === 0) {
                if (preg_match('/\.(m3u8|mp4)(\?|$|&)/i', $extUrl)) {
                    return ['parse' => 0, 'url' => $extUrl, 'header' => $header];
                }
                return ['parse' => 1, 'url' => $extUrl, 'header' => $header];
            }
        }

        // 站内线路 (绝对带上 Referer)
        if ($kind === 'IN' && count($parts) >= 4) {
            $fromName = $parts[1];
            $token = implode('@', array_slice($parts, 3));
            $playUrl = $this->decodePlayUrl($token, $fromName);
            
            if ($playUrl && strpos($playUrl, 'http') === 0) {
                // 🎯 给视频请求带上齐全的 Header
                $playHeader = (object)[
                    'User-Agent' => $this->UA,
                    'Referer' => $this->host . '/'
                ];
                return ['parse' => 0, 'url' => $playUrl, 'header' => $playHeader];
            }
            
            $vodId = $parts[0] ?? '';
            $epIndex = $parts[2] ?? '1';
            if ($vodId) {
                $sniff = $this->host . '/play/' . $vodId . '#sid=' . urlencode($fromName) . '&nid=' . urlencode($epIndex);
                return ['parse' => 1, 'url' => $sniff, 'header' => $header];
            }
        }

        return ['parse' => 0, 'url' => '', 'header' => $header];
    }

    public function localProxy($param) {
        return null;
    }
}

(new Spider())->run();