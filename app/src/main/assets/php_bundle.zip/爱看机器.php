<?php
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    private $SITE = 'https://www1.ikanbot.com';
    private $UA   = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

    private $cateManual = [
        '电影' => 'movie',
        '剧集' => 'tv',
        '动漫' => '18',
        '综艺' => '19',
    ];

    public function __construct() {
        parent::__construct();
    }

    // ============================================================
    // 工具
    // ============================================================
    private function reqHeaders() {
        return [
            'User-Agent' => $this->UA,
            'Referer'    => $this->SITE . '/',
            'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language' => 'zh-CN,zh;q=0.9',
        ];
    }

    private function fetchHtml($url, $headers = null) {
        try {
            $res = $this->fetch($url, [], $headers ?: $this->reqHeaders());
            return $res ?: '';
        } catch (Exception $e) {
            return '';
        }
    }

    private function getVid($url) {
        if (!$url) return '';
        if (preg_match('#/play/(\d+)#', $url, $m)) return $m[1];
        return '';
    }

    /**
     * 逆向 get_tks：从 e_token 和 videoId 末4位生成 token
     */
    private function getTks($currentId, $eToken) {
        try {
            $substr    = substr($currentId, -4);
            $token     = '';
            $remaining = $eToken;
            $len       = strlen($substr);
            for ($i = 0; $i < $len; $i++) {
                $ch = $substr[$i];
                if (!ctype_digit($ch)) return '';
                $pos = (intval($ch) % 3) + 1;
                if ($pos + 8 > strlen($remaining)) break;
                $token    .= substr($remaining, $pos, 8);
                $remaining = substr($remaining, $pos + 8);
            }
            return $token;
        } catch (Exception $e) {
            return '';
        }
    }

    // ============================================================
    // 列表解析（兼容分类页 / 搜索页 / 首页）
    // ============================================================
    private function extractVodList($html) {
        $result = [];
        $seen   = [];
        if (!$html) return $result;

        // 方式1：<a class="item" href="/play/xxx"><img ... /><p>标题</p></a>
        preg_match_all(
            '/<a[^>]*class="item"[^>]*href="(\/play\/\d+)"[^>]*>([\s\S]*?)<\/a>/',
            $html, $matches, PREG_SET_ORDER
        );
        foreach ($matches as $m) {
            $vid = $this->getVid($m[1]);
            if (!$vid || isset($seen[$vid])) continue;
            $seen[$vid] = true;
            $title = '';
            if (preg_match('/<p[^>]*>([^<]+)<\/p>/', $m[2], $tm)) $title = trim($tm[1]);
            $pic = '';
            if (preg_match('/<img[^>]*data-(?:src|original)="([^"]*)"/', $m[2], $pm)) $pic = $pm[1];
            if (strpos($pic, 'data:image/svg') !== false) $pic = '';
            if ($title) $result[] = ['vid' => $vid, 'title' => $title, 'pic' => $pic];
        }

        // 方式2：搜索页 .media 卡片
        if (empty($result)) {
            preg_match_all('/<div[^>]*class="media"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/', $html, $medias);
            foreach ($medias[1] as $card) {
                if (!preg_match('/href="(\/play\/\d+)"/', $card, $hm)) continue;
                $vid = $this->getVid($hm[1]);
                if (!$vid || isset($seen[$vid])) continue;
                $seen[$vid] = true;
                $title = '';
                if (preg_match('/class="media-body"[^>]*>[\s\S]*?<a[^>]*>([^<]+)<\/a>/', $card, $tm)) {
                    $title = trim($tm[1]);
                }
                $pic = '';
                if (preg_match('/data-original="([^"]*)"/', $card, $pm)) $pic = $pm[1];
                if (strpos($pic, 'data:image/svg') !== false) $pic = '';
                $result[] = ['vid' => $vid, 'title' => $title, 'pic' => $pic];
            }
        }

        // 方式3：首页简单链接
        if (empty($result)) {
            preg_match_all(
                '/<a[^>]*href="(\/play\/(\d+))"[^>]*>([^<]+)<\/a>/',
                $html, $matches, PREG_SET_ORDER
            );
            foreach ($matches as $m) {
                $vid   = $m[2];
                $title = trim($m[3]);
                if (isset($seen[$vid]) || !$title || mb_strlen($title) > 50) continue;
                $seen[$vid] = true;
                $result[] = ['vid' => $vid, 'title' => $title, 'pic' => ''];
            }
        }

        return $result;
    }

    private function toVod($items) {
        $list = [];
        foreach ($items as $it) {
            $list[] = [
                'vod_id'      => $it['vid'],
                'vod_name'    => $it['title'],
                'vod_pic'     => $it['pic'],
                'vod_remarks' => ''
            ];
        }
        return $list;
    }

    // ============================================================
    // 首页
    // ============================================================
    public function homeContent($filter) {
        $classes = [];
        foreach ($this->cateManual as $k => $v) {
            $classes[] = ['type_id' => (string)$v, 'type_name' => $k];
        }
        return ['class' => $classes];
    }

    public function homeVideoContent() {
        $html = $this->fetchHtml($this->SITE);
        return ['list' => $this->toVod($this->extractVodList($html))];
    }

    // ============================================================
    // 分类
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        $hot  = '%E7%83%AD%E9%97%A8'; // 热门

        if ($tid === 'movie' || $tid === 'tv') {
            $url = $page == 1
                ? "{$this->SITE}/hot/index-{$tid}-{$hot}.html"
                : "{$this->SITE}/hot/index-{$tid}-{$hot}-p-{$page}.html";
        } else {
            $url = $page == 1
                ? "{$this->SITE}/category/{$tid}"
                : "{$this->SITE}/category/{$tid}?p={$page}";
        }

        $list = $this->toVod($this->extractVodList($this->fetchHtml($url)));

        // 有数据则估算还有下一页（total 传大值以触发 9999 页数估算）
        $total = !empty($list) ? ($page * 20 + 1) : (($page - 1) * 20);
        return $this->pageResult($list, $page, $total, 20);
    }

    // ============================================================
    // 详情
    // ============================================================
    public function detailContent($ids) {
        $vid = is_array($ids) ? ($ids[0] ?? '') : $ids;
        if (!$vid) return ['list' => []];

        $html = $this->fetchHtml("{$this->SITE}/play/{$vid}");
        if (!$html) return ['list' => []];

        // 标题
        $title = '';
        if (preg_match('/<title>([^<]+)</', $html, $m)) {
            $title = trim($m[1]);
            $title = preg_replace('/\s*[-–—].*$/u', '', $title);
            $title = trim($title);
        }

        // 封面
        $pic = '';
        if (preg_match('/<img[^>]*src="(https?:\/\/[^"]*(?:akamai|doubanio|aka\.|cdn)[^"]*)"/', $html, $m)) {
            $pic = $m[1];
        }
        if (!$pic && preg_match('/data-original="(https?:\/\/[^"]+)"/', $html, $m)) {
            $pic = $m[1];
        }

        // 简介
        $desc = '';
        if (preg_match_all('/(?:描述|简介|剧情)[^<]*<[^>]*>([^<]+)/u', $html, $dm)) {
            foreach ($dm[1] as $text) {
                $text = trim($text);
                if (mb_strlen($text) > 20) { $desc = $text; break; }
            }
        }

        // e_token
        $eToken = '';
        if (preg_match('/id="e_token"\s+value="([^"]+)"/', $html, $m)) {
            $eToken = $m[1];
        }

        $playFrom = [];
        $playUrl  = [];

        if ($eToken) {
            $token = $this->getTks((string)$vid, $eToken);
            if ($token) {
                $apiUrl = "{$this->SITE}/api/getResN?videoId=" . urlencode($vid)
                        . "&mtype=1&token=" . urlencode($token);
                $apiHeaders = [
                    'User-Agent' => $this->UA,
                    'Referer'    => $this->SITE . '/',
                    'Accept'     => 'application/json,*/*',
                ];
                $resp = $this->fetchHtml($apiUrl, $apiHeaders);
                if ($resp) {
                    $json = json_decode($resp, true);
                    if (isset($json['data']['list']) && is_array($json['data']['list'])) {
                        $lineIdx = 0;
                        foreach ($json['data']['list'] as $line) {
                            $lineName = !empty($line['name']) ? $line['name'] : ('线路' . ($lineIdx + 1));
                            $resData  = !empty($line['resData']) ? json_decode($line['resData'], true) : [];
                            if (!is_array($resData)) continue;

                            $episodes = [];
                            foreach ($resData as $idx => $ep) {
                                $epName = !empty($ep['newName']) ? $ep['newName'] : ('第' . ($idx + 1) . '集');
                                $epUrl  = $ep['url'] ?? '';
                                if ($epUrl) $episodes[] = $epName . '$' . $epUrl;
                            }
                            if (!empty($episodes)) {
                                $playFrom[] = $lineName;
                                $playUrl[]  = implode('#', $episodes);
                                $lineIdx++;
                            }
                        }
                    }
                }
            }
        }

        $vod = [
            'vod_id'        => $vid,
            'vod_name'      => $title,
            'vod_pic'       => $pic,
            'type_name'     => '',
            'vod_year'      => '',
            'vod_area'      => '',
            'vod_remarks'   => '',
            'vod_actor'     => '',
            'vod_director'  => '',
            'vod_content'   => $desc,
            'vod_play_from' => implode('$$$', $playFrom),
            'vod_play_url'  => implode('$$$', $playUrl)
        ];

        return ['list' => [$vod]];
    }

    // ============================================================
    // 搜索
    // ============================================================
    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $url  = "{$this->SITE}/search?q=" . urlencode($key);
        if ($page > 1) $url .= "&page={$page}";

        $list  = $this->toVod($this->extractVodList($this->fetchHtml($url)));
        $total = !empty($list) ? ($page * 20 + 1) : (($page - 1) * 20);
        return $this->pageResult($list, $page, $total, 20);
    }

    // ============================================================
    // 播放
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $playUrl = $id;
        // 基类路由 play 参数可能是 "集名$url"，取 url 部分
        if (strpos($playUrl, '$') !== false) {
            $parts   = explode('$', $playUrl);
            $playUrl = end($parts);
        }

        return [
            'parse'  => 0,
            'url'    => $playUrl,
            'jx'     => 0,
            'header' => [
                'User-Agent' => $this->UA,
                'Referer'    => $this->SITE . '/'
            ]
        ];
    }
}

(new Spider())->run();