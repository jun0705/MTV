<?php
/**
 * 体育直播聚合 - 影视仓 PHP 完美一比一复刻版
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    
    protected $UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';
    protected $OSS = 'https://img0.aiscore.com/';
    
    protected $SITES = [
        'jisu' => [
            'name' => '极速直播', 'host' => 'https://jszb11.app',
            'fallbackApi' => 'https://2nhz2p44gxpwf9sptxb12.k8v4dh4.app',
            'content' => '⚠️ 极速体育提醒您：注意防诈骗，禁止传播低俗消息。',
            'contentFromAd' => false, 'business' => false, 'rank' => false
        ],
        'lvying' => [
            'name' => '绿茵直播', 'host' => 'https://9939zb4.app',
            'fallbackApi' => 'https://lzfs5tah9amkatbu4tb07.k8v4dh4.app',
            'content' => '⚠️ 绿茵体育提醒您：注意防诈骗，禁止传播低俗消息。',
            'contentFromAd' => true, 'business' => false, 'rank' => false
        ],
        'b833' => [
            'name' => '833直播', 'host' => 'https://833tt79.app',
            'fallbackApi' => 'https://skv7dhg3fmlgg7cqpkb03.k8v4dh4.app',
            'content' => '⚠️ 833直播提醒您：注意防诈骗，禁止传播低俗消息。',
            'contentFromAd' => false, 'business' => false, 'rank' => false
        ],
        'zhizhu' => [
            'name' => '蜘蛛直播', 'host' => 'https://zzzbvip429.com',
            'fallbackApi' => 'https://uwnyqabbrnve9xkwrhb01.k8v4dh4.app',
            'content' => '蜘蛛直播实时体育直播',
            'contentFromAd' => true, 'business' => true, 'rank' => true
        ]
    ];

    protected $SUB_TYPES = [
        ['tid' => 'recommend', 'name' => '🔥 推荐'],
        ['tid' => 'football', 'name' => '⚽ 足球直播'],
        ['tid' => 'basketball', 'name' => '🏀 篮球直播'],
        ['tid' => 'official', 'name' => '🏆 官方直播'],
        ['tid' => 'schedule', 'name' => '📅 未开播']
    ];

    protected $RECOMMEND_IDS = [1, 2, 3, 4, 13];
    protected $runtimeApi = [];

    // ============================================================
    // 强制 JSON 输出（终极防弹机制）
    // ============================================================
    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    // 纯原生网络请求
    protected function fetchText($url, $siteKey = 'jisu') {
        $site = $this->SITES[$siteKey] ?? $this->SITES['jisu'];
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => [
                'User-Agent: ' . $this->UA,
                'Referer: ' . $site['host'] . '/',
                'Origin: ' . $site['host'],
                'Accept: application/json, text/plain, */*'
            ]
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function safeJson($text) {
        $text = trim($text);
        if (!$text) return [];
        if (strpos($text, '{') !== false && substr($text, 0, 1) !== '{') {
            $start = strpos($text, '{');
            $end = strrpos($text, '}');
            if ($start !== false && $end !== false) {
                $text = substr($text, $start, $end - $start + 1);
            }
        }
        $decoded = json_decode($text, true);
        return is_array($decoded) ? $decoded : [];
    }

    // 获取/刷新 API 域名
    protected function apiOf($key) {
        return $this->runtimeApi[$key] ?? $this->SITES[$key]['fallbackApi'];
    }

    protected function refreshApiHost($key) {
        $site = $this->SITES[$key];
        $res = $this->fetchText($site['host'] . '/config.json', $key);
        $cfg = $this->safeJson($res);
        $ep = $cfg['api-endpoint'] ?? ($cfg['apiEndpoint'] ?? ($cfg['api_host'] ?? ($cfg['api'] ?? null)));
        if ($ep) {
            $this->runtimeApi[$key] = rtrim($ep, '/');
            return true;
        }
        return false;
    }

    // ============================================================
    // 工具函数
    // ============================================================
    protected function formatHot($n) {
        $n = floatval($n);
        if ($n >= 1e8) return round($n / 1e8, 1) . '亿';
        if ($n >= 1e4) return round($n / 1e4, 1) . '万';
        return (string)$n;
    }

    protected function pickTime($obj) {
        if (!$obj) return 0;
        $keys = ['matchTime', 'startTime', 'beginTime', 'matchDate', 'liveTime', 'startAt', 'beginAt', 'time'];
        foreach ($keys as $k) {
            if (empty($obj[$k])) continue;
            $v = $obj[$k];
            if (is_numeric($v)) return (float)$v;
            $s = trim((string)$v);
            if (preg_match('/^\d+$/', $s)) return (float)$s;
            $ts = strtotime(str_replace('-', '/', $s));
            if ($ts !== false) return $ts * 1000;
        }
        return 0;
    }

    protected function timeText($obj) {
        $ts = $this->pickTime($obj);
        if (!$ts) return '';
        if ($ts < 1e10) $ts *= 1000;
        $d = date('Y-m-d H:i', (int)($ts / 1000));
        $today = date('Y-m-d');
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        $md = date('m-d H:i', (int)($ts / 1000));
        if ($d == date('Y-m-d H:i')) return '今天 ' . date('H:i', (int)($ts / 1000));
        if (strpos($d, $today) === 0) return '今天 ' . date('H:i', (int)($ts / 1000));
        if (strpos($d, $tomorrow) === 0) return '明天 ' . date('H:i', (int)($ts / 1000));
        return $md;
    }

    protected function isFinishedByTime($obj) {
        $ts = $this->pickTime($obj);
        if (!$ts) return false;
        if ($ts < 1e10) $ts *= 1000;
        return $ts < time() * 1000 - 2 * 3600 * 1000;
    }

    protected function normalize($key, $url) {
        $url = trim((string)$url);
        if (!$url) return '';
        if (preg_match('/^(webrtc|javascript|about|data|blob|#)/i', $url)) return '';
        if (strpos($url, '//') === 0) $url = 'https:' . $url;
        if (strpos($url, '/') === 0) $url = $this->apiOf($key) . $url;
        if (!preg_match('/^https?:\/\//i', $url) && strpos($url, 'm3u8') !== 0) return '';
        return $url;
    }

    protected function collectUrls($key, $obj) {
        if (!$obj) return [];
        $cands = [
            $obj['playStreamAddress2'] ?? '', $obj['playStreamAddress'] ?? '', $obj['playUrl'] ?? '',
            $obj['streamUrl'] ?? '', $obj['liveUrl'] ?? '', $obj['m3u8'] ?? '', $obj['m3u8Url'] ?? '',
            $obj['videoUrl'] ?? '', $obj['flvUrl'] ?? '', $obj['rtmpUrl'] ?? '', $obj['playStreamAddress3'] ?? ''
        ];
        $out = [];
        foreach ($cands as $u) {
            $n = $this->normalize($key, $u);
            if ($n && !in_array($n, $out)) $out[] = $n;
        }
        return $out;
    }

    protected function matchIdOf($obj) {
        if (!$obj) return '';
        return (string)($obj['matchId'] ?? ($obj['match_id'] ?? ($obj['id'] ?? '')));
    }

    protected function matchName($match) {
        $league = $match['competition']['name'] ?? ($match['competition']['competitionName'] ?? '');
        $home = $match['homeTeam']['name'] ?? ($match['homeTeam']['teamName'] ?? '');
        $away = $match['awayTeam']['name'] ?? ($match['awayTeam']['teamName'] ?? '');
        return trim("$league $home VS $away");
    }

    protected function matchPic($match) {
        $logo = $match['homeTeam']['logo'] ?? '';
        if (!$logo) return '';
        return strpos($logo, 'http') === 0 ? $logo : $this->OSS . $logo;
    }

    // ============================================================
    // 壳子标准接口
    // ============================================================

    public function init($extend = '') {
        if ($extend) {
            $parts = explode('|', $extend);
            foreach ($parts as $seg) {
                $kv = explode('=', $seg);
                if (count($kv) == 2 && isset($this->SITES[trim($kv[0])])) {
                    $this->runtimeApi[trim($kv[0])] = rtrim(trim($kv[1]), '/');
                }
            }
        }
        foreach (array_keys($this->SITES) as $key) {
            $this->refreshApiHost($key);
        }
    }

    public function homeContent($filter) {
        $classList = [];
        $filters = [];
        $subs = [];
        foreach ($this->SUB_TYPES as $t) {
            $subs[] = ['n' => $t['name'], 'v' => $t['tid']];
        }

        foreach ($this->SITES as $k => $site) {
            $classList[] = ['type_id' => $k, 'type_name' => $site['name']];
            $filters[$k] = [['key' => 'sub', 'name' => '分类', 'value' => $subs]];
        }

        $this->outputJson(['class' => $classList, 'filters' => $filters]);
    }

    public function homeVideoContent() {
        $res = json_decode($this->categoryContent('jisu', 1, [], ['sub' => 'recommend']), true);
        $this->outputJson(['list' => $res['list'] ?? []]);
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $siteKey = isset($this->SITES[$tid]) ? $tid : 'jisu';
        $site = $this->SITES[$siteKey];
        $sub = $extend['sub'] ?? 'recommend';
        $pg = max(1, intval($pg));
        $list = [];
        $seen = [];

        if ($sub === 'official' || $sub === 'schedule') {
            $url = $this->apiOf($siteKey) . '/api/c7/business/match/list?pageNum=' . $pg . '&pageSize=30';
            $json = $this->safeJson($this->fetchText($url, $siteKey));
            $data = $json['data'] ?? [];
            $pagecount = $data['pages'] ?? ($data['totalPage'] ?? 1);

            $anchorMatchIds = null;
            if ($sub === 'schedule' && !$site['business']) {
                $anchorMatchIds = [];
                $url2 = $this->apiOf($siteKey) . '/api/c5/business/livehouse/index';
                $d2 = $this->safeJson($this->fetchText($url2, $siteKey))['data'] ?? [];
                $anchors = array_merge($d2['ongoingLivestreams'] ?? [], $d2['anchorLivestreams'] ?? []);
                foreach ($anchors as $a) {
                    $mid = $this->matchIdOf($a);
                    if ($mid) $anchorMatchIds[$mid] = true;
                }
            }

            foreach ($data['records'] ?? [] as $it) {
                $match = $it['result']['match'] ?? $it;
                $mid = $this->matchIdOf($match);
                if (!$mid) continue;
                $sportId = (int)($match['sportId'] ?? 0);
                if (!in_array($sportId, $this->RECOMMEND_IDS)) continue;

                $videoUrl = $this->normalize($siteKey, $match['videoUrl'] ?? '');
                $title = $this->matchName($match) ?: ('赛事 ' . $mid);
                $time = $this->timeText($match);

                if ($sub === 'official') {
                    if (!$videoUrl) continue;
                    $vid = $siteKey . '$match$' . $mid . '$' . urlencode($videoUrl);
                    if (isset($seen[$vid])) continue;
                    $seen[$vid] = true;
                    $list[] = [
                        'vod_id' => $vid, 'vod_name' => $title, 'vod_pic' => $this->matchPic($match),
                        'vod_remarks' => ($time ? $time . ' · ' : '') . '🏆 直播中 · 官方'
                    ];
                } else {
                    if ($videoUrl) continue;
                    if ($site['business']) {
                        $appoints = $it['anchorAppointmentVoList'] ?? ($it['reservedAnchors'] ?? []);
                        if (!empty($appoints)) continue;
                    } elseif ($anchorMatchIds !== null && isset($anchorMatchIds[$mid])) {
                        continue;
                    }
                    $vid = $siteKey . '$match$' . $mid . '$';
                    if (isset($seen[$vid])) continue;
                    $seen[$vid] = true;
                    $list[] = [
                        'vod_id' => $vid, 'vod_name' => $title, 'vod_pic' => $this->matchPic($match),
                        'vod_remarks' => ($time ? $time . ' · ' : '') . ($this->isFinishedByTime($match) ? '✅ 已结束' : '⏰ 未开播')
                    ];
                }
            }
            $this->outputJson(['page' => $pg, 'pagecount' => $pagecount, 'limit' => 30, 'total' => count($list), 'list' => $list]);
        }

        // recommend / football / basketball
        $url = $this->apiOf($siteKey) . '/api/c5/business/livehouse/index';
        $json = $this->safeJson($this->fetchText($url, $siteKey));
        $data = $json['data'] ?? [];

        $anchors = array_merge($data['ongoingLivestreams'] ?? [], $data['anchorLivestreams'] ?? []);
        if ($site['rank'] && $sub === 'recommend') {
            $anchors = array_merge($anchors, $data['streamingAnchorRanking'] ?? []);
        }

        foreach ($anchors as $a) {
            $hid = trim((string)($a['houseId'] ?? ($a['appNumber'] ?? '')));
            if (!$hid) continue;
            if ((int)($a['liveStatus'] ?? 0) !== 2) continue;
            
            $urls = $this->collectUrls($siteKey, $a);
            if (empty($urls)) continue;

            $rt = (int)($a['raceTypeId'] ?? 0);
            if ($sub === 'football' && $rt !== 1) continue;
            if ($sub === 'basketball' && $rt !== 2) continue;
            if ($sub === 'recommend' && !in_array($rt, $this->RECOMMEND_IDS)) continue;

            $addr = $urls[0];
            $vid = $siteKey . '$a$' . $hid . '$' . urlencode($addr);
            if (isset($seen[$vid])) continue;
            $seen[$vid] = true;

            $name = $a['houseName'] ?? ($a['nickName'] ?? '直播间');
            $time = $this->timeText($a);
            $hot = $this->formatHot($a['visitHistory'] ?? 0);
            $list[] = [
                'vod_id' => $vid, 'vod_name' => $name, 'vod_pic' => $a['houseImage'] ?? ($a['loadingCover'] ?? ($a['userImage'] ?? '')),
                'vod_remarks' => ($time ? $time . ' · ' : '') . '🔴 直播中 · ' . ($a['nickName'] ?? '主播') . ' (' . $hot . ')'
            ];
        }

        $this->outputJson(['page' => $pg, 'pagecount' => 1, 'limit' => 30, 'total' => count($list), 'list' => $list]);
    }

    protected function fetchAnchorDetail($siteKey, $houseId) {
        $site = $this->SITES[$siteKey];
        $url = $site['business'] 
            ? $this->apiOf($siteKey) . '/business/anchor/detail?houseId=' . urlencode($houseId)
            : $this->apiOf($siteKey) . '/api/c3/business/livehouse/detail?houseId=' . urlencode($houseId);

        $json = $this->safeJson($this->fetchText($url, $siteKey));
        $ad = $site['business'] ? ($json['data'] ?? []) : ($json['data']['anchorDetail'] ?? []);

        $content = $site['content'];
        if ($site['contentFromAd']) {
            $content = strip_tags((string)($ad['anchorAnnouncement'] ?? ($ad['marquee'] ?? $site['content'])));
        }

        return [
            'ad' => $ad,
            'name' => $ad['houseName'] ?? ($ad['nickName'] ?? ('直播间 ' . $houseId)),
            'pic' => $ad['houseImage'] ?? ($ad['userImage'] ?? ''),
            'liveStatus' => (int)($ad['liveStatus'] ?? 0),
            'content' => $content,
            'urls' => $this->collectUrls($siteKey, $ad)
        ];
    }

    public function detailContent($ids) {
        $vid = trim((string)(is_array($ids) ? $ids[0] : $ids));
        $siteKey = 'jisu';
        $rest = $vid;
        $idx = strpos($vid, '$');
        if ($idx > 0) {
            $maybe = substr($vid, 0, $idx);
            if (isset($this->SITES[$maybe])) {
                $siteKey = $maybe;
                $rest = substr($vid, $idx + 1);
            }
        }
        $site = $this->SITES[$siteKey];

        // a$houseId$addr
        if (strpos($rest, 'a$') === 0) {
            $parts = explode('$', $rest);
            $houseId = $parts[1] ?? '';
            $addr = !empty($parts[2]) ? urldecode($parts[2]) : '';
            $fullId = $siteKey . '$a$' . $houseId . '$' . ($parts[2] ?? '');

            $d = $this->fetchAnchorDetail($siteKey, $houseId);
            $urls = $d['urls'];
            if ($addr && !in_array($addr, $urls)) array_unshift($urls, $addr);

            if (!empty($urls)) {
                $playUrls = [];
                foreach ($urls as $i => $u) {
                    $playUrls[] = ($i === 0 ? '高清线路$' : '备用线路$') . $u;
                }
                $this->outputJson(['list' => [[
                    'vod_id' => $fullId, 'vod_name' => $d['name'], 'vod_pic' => $d['pic'],
                    'vod_remarks' => $d['liveStatus'] === 2 ? '直播中' : '未开播',
                    'vod_content' => $d['content'], 'vod_play_from' => '主播解说', 'vod_play_url' => implode('#', $playUrls)
                ]]]);
            }
            if ($addr) {
                $this->outputJson(['list' => [[
                    'vod_id' => $fullId, 'vod_name' => $d['name'], 'vod_pic' => $d['pic'],
                    'vod_remarks' => '直播中', 'vod_content' => $d['content'],
                    'vod_play_from' => '主播解说', 'vod_play_url' => '高清线路$' . $addr
                ]]]);
            }
            $this->outputJson(['list' => []]);
        }

        // match$matchId$url
        if (strpos($rest, 'match$') === 0) {
            $parts = explode('$', $rest);
            $nUrl = $this->normalize($siteKey, !empty($parts[2]) ? urldecode($parts[2]) : '');
            if ($nUrl) {
                $this->outputJson(['list' => [[
                    'vod_id' => $vid, 'vod_name' => '官方赛事直播', 'vod_pic' => '',
                    'vod_content' => $site['content'], 'vod_play_from' => '官方线路', 'vod_play_url' => '高清线路$' . $nUrl
                ]]]);
            }
            $this->outputJson(['list' => [[
                'vod_id' => $vid, 'vod_name' => '赛事未开播/已结束', 'vod_pic' => '',
                'vod_content' => '该比赛尚未开始或已结束，暂无可用直播线路。', 
                'vod_play_from' => '官方线路', 'vod_play_url' => '暂无$javascript:void(0);'
            ]]]);
        }

        // 裸 houseId
        $d = $this->fetchAnchorDetail($siteKey, $rest);
        if (empty($d['urls'])) $this->outputJson(['list' => []]);

        $playUrls = [];
        foreach ($d['urls'] as $i => $u) {
            $playUrls[] = ($i === 0 ? '高清线路$' : '备用线路$') . $u;
        }
        $this->outputJson(['list' => [[
            'vod_id' => $vid, 'vod_name' => $d['name'], 'vod_pic' => $d['pic'],
            'vod_remarks' => $d['liveStatus'] === 2 ? '直播中' : '未开播',
            'vod_content' => $d['content'], 'vod_play_from' => '主播解说', 'vod_play_url' => implode('#', $playUrls)
        ]]]);
    }

    public function searchContent($wd, $quick = false, $pg = 1) {
        if (!$wd) $this->outputJson(['page' => 1, 'list' => []]);
        
        $all = [];
        $seen = [];
        foreach (array_keys($this->SITES) as $key) {
            $url = $this->apiOf($key) . '/api/c5/business/livehouse/index';
            $json = $this->safeJson($this->fetchText($url, $key));
            $data = $json['data'] ?? [];
            $items = array_merge($data['ongoingLivestreams'] ?? [], $data['anchorLivestreams'] ?? []);
            
            foreach ($items as $it) {
                $hid = trim((string)($it['houseId'] ?? ''));
                if (!$hid || (int)($it['liveStatus'] ?? 0) !== 2) continue;
                $urls = $this->collectUrls($key, $it);
                if (empty($urls)) continue;
                
                $n = (string)($it['houseName'] ?? ($it['nickName'] ?? ''));
                if (mb_strpos($n, $wd) === false) continue;
                
                $vid = $key . '$a$' . $hid . '$' . urlencode($urls[0]);
                if (isset($seen[$vid])) continue;
                $seen[$vid] = true;
                
                $all[] = [
                    'vod_id' => $vid, 'vod_name' => $n,
                    'vod_pic' => $it['houseImage'] ?? ($it['userImage'] ?? ''),
                    'vod_remarks' => '🔴 直播中 · ' . ($it['nickName'] ?? '主播')
                ];
            }
        }
        $this->outputJson(['page' => 1, 'list' => $all]);
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        $url = (string)$id;
        $lastDollar = strrpos($url, '$');
        if ($lastDollar !== false) {
            $url = substr($url, $lastDollar + 1);
        }

        $siteKey = 'jisu';
        $first = strpos((string)$id, '$');
        if ($first > 0) {
            $maybe = substr((string)$id, 0, $first);
            if (isset($this->SITES[$maybe])) $siteKey = $maybe;
        }
        $site = $this->SITES[$siteKey];

        $nUrl = $this->normalize($siteKey, $url);
        if (!$nUrl) {
            $this->outputJson(['parse' => 0, 'url' => '', 'header' => ['User-Agent' => $this->UA]]);
        }

        $this->outputJson([
            'parse' => 0,
            'url' => $nUrl,
            'header' => [
                'User-Agent' => $this->UA,
                'Referer' => $site['host'] . '/',
                'Origin' => $site['host'],
                'Accept' => 'application/json, text/plain, */*'
            ]
        ]);
    }
}

(new Spider())->run();