<?php
/**
 * 极速追剧 - 影视仓 PHP 版（由 极速影院.js 转换）
 * @header({
 *   searchable: 1,
 *   filterable: 1,
 *   quickSearch: 0,
 *   title: '极速追剧',
 *   lang: 'php'
 * })
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    private $host = 'https://jisuzhuiju.com';

    private $UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

    // ======================================================
    //  基础请求
    // ======================================================
    private function getHeaders($extra = []) {
        $h = [
            'User-Agent'      => $this->UA,
            'accept-language' => 'zh-CN,zh;q=0.9',
            'Referer'         => $this->host . '/',
        ];
        return array_merge($h, $extra);
    }

    private function request($url, $headers = []) {
        $res = $this->fetch($url, [], $this->getHeaders($headers));
        return $res ?: '';
    }

    public function init($extend = '') {
        if (is_string($extend) && trim($extend) !== '') {
            $this->host = trim($extend);
        }
        $this->request($this->host);
    }

    // ======================================================
    //  列表解析（字符串正则）
    // ======================================================
    private function parseListHtml($html) {
        $list = [];
        $seen = [];
        if (!$html) return $list;

        if (!preg_match_all('/<a\s+href="(\/detail\/\d+\.html)"[^>]*>([\s\S]*?)<\/a>/i', $html, $ms, PREG_SET_ORDER)) {
            return $list;
        }

        foreach ($ms as $m) {
            $href  = $m[1];
            $inner = $m[2];
            if (isset($seen[$href])) continue;
            $seen[$href] = true;

            $title = '';
            if (preg_match('/class="vod-title[^"]*"[^>]*>([\s\S]*?)<\/p>/i', $inner, $tm)) {
                $title = trim(strip_tags($tm[1]));
            }
            if ($title === '' && preg_match('/title="([^"]*)"/i', $m[0], $am)) {
                $title = trim($am[1]);
            }
            if ($title === '' && preg_match('/alt="([^"]*)"/i', $inner, $im)) {
                $title = trim(str_replace('封面图片', '', $im[1]));
            }
            if ($title === '') continue;

            $pic = '';
            if (preg_match('/<img[^>]+src="([^"]+)"/i', $inner, $pm)) {
                $pic = $pm[1];
            }
            if ($pic === '' && preg_match('/<img[^>]+data-src="([^"]+)"/i', $inner, $dm)) {
                $pic = $dm[1];
            }
            if ($pic !== '' && strpos($pic, 'http') !== 0) {
                $pic = $this->host . $pic;
            }
            if (strpos($pic, 'http://') === 0) {
                $pic = str_replace('http://', 'https://', $pic);
            }

            $remarks = '';
            if (preg_match('/class="vod-subtitle[^"]*"[^>]*>([\s\S]*?)<\/p>/i', $inner, $rm)) {
                $remarks = trim(strip_tags($rm[1]));
            }

            $list[] = [
                'vod_id'      => strpos($href, 'http') === 0 ? $href : ($this->host . $href),
                'vod_name'    => $title,
                'vod_pic'     => $pic,
                'vod_remarks' => $remarks,
            ];
        }
        return $list;
    }

    // ======================================================
    //  首页 / 分类
    // ======================================================
    public function homeContent($filter) {
        $classes = [
            ['type_id' => '1', 'type_name' => '电视剧'],
            ['type_id' => '2', 'type_name' => '电影'],
            ['type_id' => '3', 'type_name' => '动漫'],
            ['type_id' => '4', 'type_name' => '综艺'],
            ['type_id' => '5', 'type_name' => '短剧'],
        ];

        // 类型映射
        $typeMap = [
            '1' => [
                ['n'=>'全部','v'=>''],['n'=>'剧情','v'=>'7'],['n'=>'古装','v'=>'9'],
                ['n'=>'战争','v'=>'10'],['n'=>'谍战','v'=>'11'],['n'=>'爱情','v'=>'12'],
                ['n'=>'罪案','v'=>'13'],['n'=>'悬疑','v'=>'14'],['n'=>'家庭','v'=>'15'],
                ['n'=>'军旅','v'=>'16'],['n'=>'喜剧','v'=>'17'],['n'=>'都市','v'=>'18'],
                ['n'=>'武侠','v'=>'19'],['n'=>'言情','v'=>'20'],['n'=>'偶像','v'=>'21'],
                ['n'=>'青春','v'=>'22'],['n'=>'农村','v'=>'23'],['n'=>'穿越','v'=>'24'],
                ['n'=>'奇幻','v'=>'25'],['n'=>'历史','v'=>'26'],['n'=>'年代','v'=>'27'],
                ['n'=>'科幻','v'=>'28'],['n'=>'生活','v'=>'29'],['n'=>'励志','v'=>'31'],
                ['n'=>'婚姻','v'=>'32'],['n'=>'警匪','v'=>'33'],['n'=>'犯罪','v'=>'34'],
                ['n'=>'推理','v'=>'35'],['n'=>'商战','v'=>'36'],['n'=>'宫廷','v'=>'37'],
                ['n'=>'仙侠','v'=>'38'],['n'=>'神话','v'=>'39'],['n'=>'动作','v'=>'40'],
                ['n'=>'复仇','v'=>'41'],['n'=>'惊悚','v'=>'42'],
            ],
            '2' => [
                ['n'=>'全部','v'=>''],['n'=>'动作','v'=>'43'],['n'=>'喜剧','v'=>'44'],
                ['n'=>'爱情','v'=>'45'],['n'=>'科幻','v'=>'46'],['n'=>'恐怖','v'=>'47'],
                ['n'=>'剧情','v'=>'48'],['n'=>'战争','v'=>'49'],['n'=>'犯罪','v'=>'50'],
                ['n'=>'惊悚','v'=>'51'],['n'=>'冒险','v'=>'52'],['n'=>'悬疑','v'=>'53'],
                ['n'=>'动画','v'=>'54'],['n'=>'武侠','v'=>'55'],['n'=>'古装','v'=>'56'],
                ['n'=>'历史','v'=>'57'],['n'=>'传记','v'=>'58'],['n'=>'纪录片','v'=>'59'],
            ],
            '3' => [
                ['n'=>'全部','v'=>''],['n'=>'热血','v'=>'60'],['n'=>'恋爱','v'=>'61'],
                ['n'=>'校园','v'=>'62'],['n'=>'搞笑','v'=>'63'],['n'=>'机甲','v'=>'64'],
                ['n'=>'神魔','v'=>'65'],['n'=>'竞技','v'=>'66'],['n'=>'冒险','v'=>'67'],
                ['n'=>'治愈','v'=>'68'],['n'=>'百合','v'=>'69'],['n'=>'萝莉','v'=>'70'],
                ['n'=>'后宫','v'=>'71'],['n'=>'励志','v'=>'72'],['n'=>'泡面番','v'=>'73'],
                ['n'=>'国产动漫','v'=>'74'],['n'=>'日本动漫','v'=>'75'],['n'=>'欧美动漫','v'=>'76'],
            ],
            '4' => [
                ['n'=>'全部','v'=>''],['n'=>'选秀','v'=>'77'],['n'=>'情感','v'=>'78'],
                ['n'=>'访谈','v'=>'79'],['n'=>'播报','v'=>'80'],['n'=>'旅游','v'=>'81'],
                ['n'=>'音乐','v'=>'82'],['n'=>'美食','v'=>'83'],['n'=>'纪实','v'=>'84'],
                ['n'=>'曲艺','v'=>'85'],['n'=>'游戏','v'=>'86'],['n'=>'亲子','v'=>'87'],
                ['n'=>'职场','v'=>'88'],['n'=>'脱口秀','v'=>'89'],['n'=>'真人秀','v'=>'90'],
                ['n'=>'晚会','v'=>'91'],
            ],
            '5' => [
                ['n'=>'全部','v'=>''],
            ],
        ];

        $areaOptions = [
            ['n'=>'全部','v'=>''],['n'=>'大陆','v'=>'大陆'],['n'=>'香港','v'=>'香港'],
            ['n'=>'台湾','v'=>'台湾'],['n'=>'韩国','v'=>'韩国'],['n'=>'日本','v'=>'日本'],
            ['n'=>'美国','v'=>'美国'],['n'=>'泰国','v'=>'泰国'],['n'=>'法国','v'=>'法国'],
            ['n'=>'英国','v'=>'英国'],['n'=>'德国','v'=>'德国'],['n'=>'印度','v'=>'印度'],
            ['n'=>'其他','v'=>'其他'],
        ];

        $yearOptions = [
            ['n'=>'全部','v'=>''],['n'=>'2026','v'=>'2026'],['n'=>'2025','v'=>'2025'],
            ['n'=>'2024','v'=>'2024'],['n'=>'2023','v'=>'2023'],['n'=>'2022','v'=>'2022'],
            ['n'=>'2021','v'=>'2021'],['n'=>'2020','v'=>'2020'],['n'=>'2019','v'=>'2019'],
            ['n'=>'2018','v'=>'2018'],['n'=>'其他','v'=>'-1'],
        ];

        $sortOptions = [
            ['n'=>'热度排序','v'=>'hot'],
            ['n'=>'上映时间','v'=>'time'],
            ['n'=>'评分排序','v'=>'score'],
        ];

        $filters = [];
        foreach ($classes as $c) {
            $tid = $c['type_id'];
            $filters[$tid] = [
                ['key'=>'type','name'=>'类型','value'=>$typeMap[$tid] ?? [['n'=>'全部','v'=>'']]],
                ['key'=>'area','name'=>'地区','value'=>$areaOptions],
                ['key'=>'year','name'=>'年份','value'=>$yearOptions],
                ['key'=>'sort','name'=>'排序','value'=>$sortOptions],
            ];
        }

        return [
            'class'   => $classes,
            'filters' => (object)$filters,
        ];
    }

    public function homeVideoContent() {
        $html = $this->request($this->host);
        if (!$html) return ['list' => []];
        return ['list' => $this->parseListHtml($html)];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));

        // 频道映射
        $channelMap = [
            '1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5',
            'dianshiju'=>'1','dianying'=>'2','dongman'=>'3','zongyi'=>'4','duanju'=>'5',
        ];
        $channel = $channelMap[strval($tid)] ?? '1';

        if (is_string($extend)) {
            $extend = json_decode($extend, true) ?: [];
        }
        $extend = is_array($extend) ? $extend : [];

        $type = $extend['type'] ?? '';
        $area = $extend['area'] ?? '';
        $year = $extend['year'] ?? '';
        $sort = $extend['sort'] ?? 'hot';

        $url = $this->host . '/filter?channel=' . $channel;
        if ($type !== '') $url .= '&type=' . urlencode($type);
        if ($area !== '') $url .= '&area=' . urlencode($area);
        if ($year !== '') $url .= '&year=' . urlencode($year);
        $url .= '&sort=' . urlencode($sort);
        $url .= '&page=' . $page;

        $html = $this->request($url);
        if (!$html) {
            return $this->pageResult([], $page, 1, 0);
        }

        $list = $this->parseListHtml($html);

        // 解析总页数
        $pagecount = $page;
        if (preg_match('/data-totalpages="(\d+)"/i', $html, $pcm)) {
            $pagecount = intval($pcm[1]) ?: $page;
        } else {
            $maxPage = 0;
            if (preg_match_all('/\/filter\?[^"]*[?&]page=(\d+)/i', $html, $pms)) {
                foreach ($pms[1] as $p) {
                    $p = intval($p);
                    if ($p > $maxPage) $maxPage = $p;
                }
            }
            if ($maxPage > 0) {
                $pagecount = $maxPage;
            } elseif (count($list) >= 12) {
                $pagecount = $page + 1;
            }
        }

        $total = $pagecount * count($list);
        return $this->pageResult($list, $page, $pagecount, $total);
    }

    // ======================================================
    //  详情
    // ======================================================
    public function detailContent($ids) {
        $id = is_array($ids) ? ($ids[0] ?? '') : $ids;
        $url = (strpos($id, 'http') === 0) ? $id : ($this->host . $id);
        $html = $this->request($url);
        if (!$html) return ['list' => []];

        // 名称
        $vod_name = '';
        if (preg_match('/<h1[^>]*class="[^"]*detail-title[^"]*"[^>]*>([\s\S]*?)<\/h1>/i', $html, $m)) {
            $vod_name = trim(strip_tags($m[1]));
        }
        if ($vod_name === '' && preg_match('/<h1[^>]*>([\s\S]*?)<\/h1>/i', $html, $m)) {
            $vod_name = trim(strip_tags($m[1]));
        }

        // 封面
        $vod_pic = '';
        if (preg_match('/class="[^"]*detail-poster-wrapper[^"]*"[\s\S]*?<img[^>]+src="([^"]+)"/i', $html, $m)) {
            $vod_pic = $m[1];
        }
        if ($vod_pic === '' && preg_match('/<img[^>]+src="([^"]+)"[^>]*alt="[^"]*封面/', $html, $m)) {
            $vod_pic = $m[1];
        }
        if ($vod_pic !== '' && strpos($vod_pic, 'http') !== 0) {
            $vod_pic = $this->host . $vod_pic;
        }
        if (strpos($vod_pic, 'http://') === 0) {
            $vod_pic = str_replace('http://', 'https://', $vod_pic);
        }

        // 简介
        $vod_content = '';
        if (preg_match('/class="[^"]*synopsis-content[^"]*"[^>]*>([\s\S]*?)<\/div>/i', $html, $m)) {
            $vod_content = trim(strip_tags($m[1]));
        }

        // 元信息
        $type_name = ''; $vod_area = ''; $vod_year = '';
        $vod_director = ''; $vod_actor = ''; $vod_remarks = '';
        if (preg_match_all('/class="[^"]*meta-label[^"]*"[^>]*>([\s\S]*?)<\/span>[\s\S]*?class="[^"]*meta-value[^"]*"[^>]*>([\s\S]*?)<\/span>/i', $html, $mm, PREG_SET_ORDER)) {
            foreach ($mm as $row) {
                $label = trim(strip_tags($row[1]));
                $value = trim(strip_tags($row[2]));
                if (mb_strpos($label, '主演') !== false) $vod_actor = $value;
                if (mb_strpos($label, '导演') !== false) $vod_director = $value;
                if (mb_strpos($label, '地区') !== false) $vod_area = $value;
                if (mb_strpos($label, '年份') !== false) $vod_year = $value;
                if (mb_strpos($label, '备注') !== false) $vod_remarks = $value;
            }
        }

        // 标签
        $tags = [];
        if (preg_match_all('/class="[^"]*tag-pill[^"]*"[^>]*>([\s\S]*?)<\/span>/i', $html, $tm)) {
            foreach ($tm[1] as $t) {
                $tags[] = trim(strip_tags($t));
            }
        }
        $type_name = implode(',', $tags);

        // 播放源
        $sourceNames = [];
        $sourceUrls  = [];

        $tabs = [];
        if (preg_match_all('/class="[^"]*source-tab[^"]*"[^>]*data-target="([^"]+)"[^>]*>([\s\S]*?)<\/button>/i', $html, $tms, PREG_SET_ORDER)) {
            foreach ($tms as $t) {
                $tabs[] = [
                    'target' => $t[1],
                    'name'   => trim(strip_tags($t[2])),
                ];
            }
        }

        if (count($tabs) > 0) {
            foreach ($tabs as $tab) {
                $panelRe = '/id="' . preg_quote($tab['target'], '/') . '"[\s\S]*?<div class="episode-grid">([\s\S]*?)<\/div>/i';
                if (!preg_match($panelRe, $html, $pm)) continue;
                $panelHtml = $pm[1];

                $episodes = [];
                if (preg_match_all('/<a\s+href="([^"]*\/vodplay\/[^"]+\.html)"[^>]*class="[^"]*episode-btn[^"]*"[^>]*>([\s\S]*?)<\/a>/i', $panelHtml, $ems, PREG_SET_ORDER)) {
                    foreach ($ems as $em) {
                        $href = $em[1];
                        $text = trim(strip_tags($em[2]));
                        if ($text === '' || mb_strpos($text, '展开') !== false) continue;
                        $text = trim(str_replace(['$', '#'], ' ', $text));
                        $episodes[] = $text . '$' . (strpos($href, 'http') === 0 ? $href : ($this->host . $href));
                    }
                }
                if (count($episodes) > 0) {
                    $sourceNames[] = $tab['name'];
                    $sourceUrls[]  = implode('#', $episodes);
                }
            }
        }

        if (count($sourceNames) === 0) {
            $episodes = [];
            if (preg_match_all('/<a\s+href="([^"]*\/vodplay\/[^"]+\.html)"[^>]*class="[^"]*episode-btn[^"]*"[^>]*>([\s\S]*?)<\/a>/i', $html, $ems, PREG_SET_ORDER)) {
                foreach ($ems as $em) {
                    $href = $em[1];
                    $text = trim(strip_tags($em[2]));
                    if ($text === '' || mb_strpos($text, '展开') !== false) continue;
                    $text = trim(str_replace(['$', '#'], ' ', $text));
                    $episodes[] = $text . '$' . (strpos($href, 'http') === 0 ? $href : ($this->host . $href));
                }
            }
            if (count($episodes) > 0) {
                $sourceNames[] = '默认线路';
                $sourceUrls[]  = implode('#', $episodes);
            }
        }

        $info = [
            'vod_id'        => $id,
            'vod_name'      => $vod_name,
            'vod_pic'       => $vod_pic,
            'vod_content'   => $vod_content,
            'vod_play_from' => implode('$$$', $sourceNames),
            'vod_play_url'  => implode('$$$', $sourceUrls),
            'vod_director'  => $vod_director,
            'vod_actor'     => $vod_actor,
            'type_name'     => $type_name,
            'vod_area'      => $vod_area,
            'vod_year'      => $vod_year,
            'vod_remarks'   => $vod_remarks,
        ];

        return ['list' => [$info]];
    }

    // ======================================================
    //  搜索
    // ======================================================
    public function searchContent($key, $quick = false, $pg = 1) {
        $searchUrl = $this->host . '/search?keyword=' . urlencode($key);
        $page = intval($pg);
        if ($page > 1) {
            $searchUrl .= '&page=' . $page;
        }

        $html = $this->request($searchUrl);
        if (!$html) return ['list' => []];

        $list = $this->parseListHtml($html);
        if ($quick) $list = array_slice($list, 0, 1);

        return ['list' => $list];
    }

    // ======================================================
    //  播放解析
    // ======================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $header = (object)[
            'User-Agent' => $this->UA,
            'Referer'    => $this->host . '/',
        ];

        try {
            if (preg_match('/\.(m3u8|mp4)(\?|$)/i', $id)) {
                return ['parse' => 0, 'url' => $id, 'jx' => 0, 'header' => $header];
            }

            if (!preg_match('/\/vodplay\/(\d+)-(.+)-(\d+)\.html/', $id, $m)) {
                return ['parse' => 0, 'url' => $id, 'jx' => 0, 'header' => $header];
            }

            $vodId   = $m[1];
            $pf      = $m[2];
            $index   = $m[3];

            $playPageUrl = $this->host . '/vodplay/' . $vodId . '-' . $pf . '-' . $index . '.html';
            $api = $this->host . '/api/play-url?vodId=' . $vodId . '&playFrom=' . $pf . '&index=' . $index;

            $text = $this->request($api, [
                'Referer' => $playPageUrl,
                'Accept'  => 'application/json, text/plain, */*',
            ]);

            if (!$text || trim($text)[0] !== '{') {
                return ['parse' => 0, 'url' => $id, 'jx' => 0, 'header' => $header];
            }

            $data = json_decode($text, true);
            if (!is_array($data) || ($data['code'] ?? 0) !== 200 || empty($data['url'])) {
                return ['parse' => 0, 'url' => $id, 'jx' => 0, 'header' => $header];
            }

            $mode = $data['mode'] ?? 'native';
            $url  = strval($data['url']);
            $hdr  = (object)[
                'Referer'    => $playPageUrl,
                'User-Agent' => $this->UA,
            ];

            if ($mode === 'native') {
                return ['parse' => 0, 'url' => $url, 'jx' => 0, 'header' => $hdr];
            }
            if ($mode === 'iframe') {
                return ['parse' => 1, 'url' => $url, 'jx' => 1, 'header' => $hdr];
            }
        } catch (\Throwable $e) {
            // 忽略
        }

        return ['parse' => 0, 'url' => $id, 'jx' => 0, 'header' => $header];
    }
}

(new Spider())->run();