<?php
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    private $API_HOST = 'https://j.qulv8.com';

    private $HEADERS = [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: zh-CN,zh;q=0.9',
        'Referer: https://j.qulv8.com/'
    ];

    private $M3U8_HEADERS = [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer: https://j.qulv8.com/',
        'Accept: */*'
    ];

    // ============================================================
    // 工具 (全部改为使用框架自带的 $this->fetch)
    // ============================================================
    private function fetchHtml($url) {
        try {
            $res = $this->fetch($url, [], $this->HEADERS);
            return $res ?: '';
        } catch (Exception $e) {
            return '';
        }
    }

    private function fixUrl($url) {
        if (!$url) return '';
        if (strpos($url, '//') === 0) return 'https:' . $url;
        if (strpos($url, 'http') === 0) return $url;
        if (strpos($url, '/') === 0) return $this->API_HOST . $url;
        return $this->API_HOST . '/' . $url;
    }

    private function cleanUrl($url) {
        if (!$url) return '';
        $url = str_replace('\\/', '/', $url);
        $url = trim($url, '"\' ');
        if (strpos($url, '//') === 0) $url = 'https:' . $url;
        return $url;
    }

    private function cleanHtmlTags($text) {
        if (!$text) return '';
        $text = strip_tags($text);
        return trim(preg_replace('/\s+/u', ' ', $text));
    }

    // ============================================================
    // 列表解析
    // ============================================================
    private function extractList($html) {
        $list = [];
        if (!$html) return $list;

        preg_match_all('/<li class="stui-vodlist__item">([\s\S]*?)<\/li>/', $html, $matches);
        
        if (!empty($matches[1])) {
            foreach ($matches[1] as $item) {
                preg_match('/<a[^>]*href="([^"]+)"[^>]*>/', $item, $hrefMatch);
                if (empty($hrefMatch)) continue;

                preg_match('/<h4[^>]*>.*?<a[^>]*>([^<]+)<\/a>/', $item, $titleMatch);

                $pic = '';
                if (preg_match('/<a[^>]*data-original="([^"]+)"/', $item, $picMatch) ||
                    preg_match('/<img[^>]*data-original="([^"]+)"/', $item, $picMatch) ||
                    preg_match('/<img[^>]*src="([^"]+)"/', $item, $picMatch)) {
                    $pic = $picMatch[1];
                }
                if ($pic && strpos($pic, '/load') !== false) $pic = '';

                preg_match('/<span class="pic-text[^"]*"[^>]*>([^<]+)<\/span>/', $item, $remarkMatch);

                $list[] = [
                    'vod_id' => $hrefMatch[1],
                    'vod_name' => !empty($titleMatch) ? trim($titleMatch[1]) : '',
                    'vod_pic' => $pic ? $this->fixUrl($pic) : '',
                    'vod_remarks' => !empty($remarkMatch) ? trim($remarkMatch[1]) : ''
                ];
            }
        }
        return $list;
    }

    // ============================================================
    // 详情解析
    // ============================================================
    private function extractDetail($html) {
        $info = [
            'vod_id' => '', 'vod_name' => '', 'vod_pic' => '', 'vod_class' => '',
            'vod_area' => '', 'vod_year' => '', 'vod_actor' => '', 'vod_director' => '',
            'vod_content' => '', 'vod_play_from' => '', 'vod_play_url' => ''
        ];

        if (preg_match('/<h3 class="title">([^<]+)<\/h3>/', $html, $m)) $info['vod_name'] = trim($m[1]);
        if (preg_match('/<img[^>]*class="img-responsive[^"]*"[^>]*data-original="([^"]+)"/', $html, $m)) $info['vod_pic'] = $this->fixUrl($m[1]);
        if (preg_match('/<span class="text-muted hidden-xs">类型：<\/span><a[^>]*>([^<]+)<\/a>/', $html, $m)) $info['vod_class'] = trim($m[1]);
        if (preg_match('/<span class="text-muted hidden-xs">地区：<\/span>([^<]+)<span/', $html, $m)) $info['vod_area'] = trim($m[1]);
        if (preg_match('/<span class="text-muted hidden-xs">年份：<\/span>(\d{4})/', $html, $m)) $info['vod_year'] = $m[1];

        if (preg_match('/<span class="text-muted">主演：<\/span>([\s\S]*?)<\/p>/', $html, $m)) {
            if (preg_match_all('/<a[^>]*>([^<]+)<\/a>/', $m[1], $actors)) {
                $info['vod_actor'] = implode(' ', array_map('trim', $actors[1]));
            }
        }

        if (preg_match('/<span class="text-muted">导演：<\/span>([\s\S]*?)<\/p>/', $html, $m)) {
            if (preg_match_all('/<a[^>]*>([^<]+)<\/a>/', $m[1], $directors)) {
                $info['vod_director'] = implode(' ', array_map('trim', $directors[1]));
            }
        }

        if (preg_match('/<div class="stui-content__desc">([\s\S]*?)<\/div>/', $html, $m)) {
            $info['vod_content'] = trim(strip_tags($m[1]));
        }

        $playlist = $this->extractPlaylist($html);
        $info['vod_play_from'] = implode('$$$', $playlist['playFrom']);
        $info['vod_play_url'] = implode('$$$', $playlist['playUrl']);

        return $info;
    }

    // ============================================================
    // 播放列表解析
    // ============================================================
    private function extractPlaylist($html) {
        $playFrom = [];
        $playUrl = [];
        $foundNames = [];

        // 线路名提取
        preg_match_all('/<div[^>]*class="[^"]*card-item[^"]*"[^>]*>([^<]+)<\/div>/', $html, $matches);
        foreach ($matches[1] as $name) {
            $name = $this->cleanHtmlTags($name);
            if ($name && !in_array($name, $foundNames)) $foundNames[] = $name;
        }

        if (empty($foundNames)) {
            if (preg_match('/<div[^>]*class="[^"]*card-nav[^"]*"[^>]*>([\s\S]*?)<\/div>/', $html, $navMatch)) {
                preg_match_all('/<div[^>]*>([^<]+)<\/div>/', $navMatch[1], $divs);
                foreach ($divs[1] as $name) {
                    $name = $this->cleanHtmlTags($name);
                    if ($name && !in_array($name, $foundNames)) $foundNames[] = $name;
                }
            }
        }

        if (empty($foundNames)) {
            preg_match_all('/如果\[\s*([^\]]+)\s*\]播放源失败/', $html, $texts);
            foreach ($texts[1] as $name) {
                $name = $this->cleanHtmlTags($name);
                if ($name && !in_array($name, $foundNames)) $foundNames[] = $name;
            }
        }

        $uniqueNames = array_values(array_unique($foundNames));

        // 剧集列表提取
        preg_match_all('/<ul[^>]*class="[^"]*stui-content__playlist[^"]*"[^>]*>([\s\S]*?)<\/ul>/', $html, $ulMatches);
        $allPlaylists = [];
        foreach ($ulMatches[1] as $ulHtml) {
            $eps = [];
            preg_match_all('/<a[^>]*href="([^"]+)"[^>]*>([^<]+)<\/a>/', $ulHtml, $epMatches, PREG_SET_ORDER);
            foreach ($epMatches as $ep) {
                $eps[] = ['name' => trim($ep[2]), 'url' => $ep[1]];
            }
            if (!empty($eps)) $allPlaylists[] = $eps;
        }

        $nameCount = count($uniqueNames);
        $playlistCount = count($allPlaylists);

        for ($i = 0; $i < $playlistCount; $i++) {
            $eps = $allPlaylists[$i];
            $fromName = '';

            if ($i < $nameCount) {
                $fromName = $uniqueNames[$i];
            } else {
                $epsUrls = array_column($eps, 'url');
                $foundName = '';
                preg_match_all('/<div class="stui-pannel stui-pannel-bg clearfix" style="display: none;">([\s\S]*?)<\/div>/', $html, $panels);
                foreach ($panels[1] as $panel) {
                    $allFound = true;
                    foreach ($epsUrls as $url) {
                        if (strpos($panel, $url) === false) { $allFound = false; break; }
                    }
                    if ($allFound) {
                        if (preg_match('/<h3[^>]*class="[^"]*episode-tab[^"]*"[^>]*>([^<]+)<\/h3>/', $panel, $h3)) {
                            $foundName = $this->cleanHtmlTags($h3[1]); break;
                        }
                        if (preg_match('/<strong[^>]*>([^<]+)<\/strong>/', $panel, $strong)) {
                            $foundName = $this->cleanHtmlTags($strong[1]); break;
                        }
                    }
                }
                $fromName = $foundName ? $foundName : ('线路' . ($i + 1));
            }

            $epList = [];
            foreach ($eps as $ep) {
                $epList[] = $ep['name'] . '$' . $this->fixUrl($ep['url']);
            }
            $playFrom[] = $fromName;
            $playUrl[] = implode('#', $epList);
        }

        return ['playFrom' => $playFrom, 'playUrl' => $playUrl];
    }

    // ============================================================
    // 提取 m3u8
    // ============================================================
    private function extractM3u8($html) {
        if (!$html) return null;

        if (preg_match('/var\s+now\s*=\s*"([^"]+)"/', $html, $m) && strpos($m[1], '.m3u8') !== false) {
            return $this->cleanUrl($m[1]);
        }

        if (preg_match('/var\s+player_aaaa\s*=\s*({[^;]+})/', $html, $m)) {
            $objStr = $m[1];
            $objStr = preg_replace('/([{,])\s*([a-zA-Z0-9_]+)\s*:/', '$1"$2":', $objStr);
            $objStr = preg_replace('/:\s*\'([^\']*)\'/', ':"$1"', $objStr);
            $objStr = preg_replace('/,\s*}/', '}', $objStr);
            $data = json_decode($objStr, true);
            if (isset($data['url']) && strpos($data['url'], '.m3u8') !== false) {
                return $this->cleanUrl($data['url']);
            }
        }

        if (preg_match('/(https?:\/\/[^\s<>"\']+\.m3u8[^\s<>"\']*)/', $html, $m)) {
            return $this->cleanUrl($m[1]);
        }

        return null;
    }

    // ============================================================
    // TVBox 接口 (重写为 BaseSpider 标准方法)
    // ============================================================

    public function homeContent($filter) {
        $classes = [
            ['type_id' => '5922692431', 'type_name' => '电影'],
            ['type_id' => '5033975762', 'type_name' => '连续剧'],
            ['type_id' => '5046095573', 'type_name' => '综艺'],
            ['type_id' => '5057378904', 'type_name' => '动漫'],
            ['type_id' => '5218091400', 'type_name' => '短剧']
        ];

        $yearValues = [['v' => '', 'n' => '全部']];
        for ($y = 2026; $y >= 2010; $y--) $yearValues[] = ['v' => (string)$y, 'n' => (string)$y];

        $areaValues = [
            ['v' => '', 'n' => '全部'], ['v' => '大陆', 'n' => '大陆'], ['v' => '香港', 'n' => '香港'],
            ['v' => '台湾', 'n' => '台湾'], ['v' => '日本', 'n' => '日本'], ['v' => '韩国', 'n' => '韩国'],
            ['v' => '欧美', 'n' => '欧美'], ['v' => '泰国', 'n' => '泰国'], ['v' => '其他', 'n' => '其他']
        ];

        $byValues = [
            ['v' => '', 'n' => '默认'], ['v' => 'time', 'n' => '时间'],
            ['v' => 'hit', 'n' => '人气'], ['v' => 'commend', 'n' => '推荐']
        ];

        $langValues = [
            ['v' => '', 'n' => '全部'], ['v' => '国语', 'n' => '国语'], ['v' => '粤语', 'n' => '粤语'],
            ['v' => '英语', 'n' => '英语'], ['v' => '日语', 'n' => '日语'], ['v' => '韩语', 'n' => '韩语'],
            ['v' => '泰语', 'n' => '泰语'], ['v' => '法语', 'n' => '法语']
        ];

        $movieClass = [
            ['v' => '', 'n' => '全部'], ['v' => '5068662235', 'n' => '动作片'], ['v' => '5079945566', 'n' => '爱情片'],
            ['v' => '5082228897', 'n' => '科幻片'], ['v' => '5093512228', 'n' => '恐怖片'], ['v' => '5005632039', 'n' => '战争片'],
            ['v' => '5016915360', 'n' => '喜剧片'], ['v' => '5028198691', 'n' => '纪录片'], ['v' => '5139482022', 'n' => '剧情片'],
            ['v' => '5269838275', 'n' => '悬疑片'], ['v' => '6437164322', 'n' => '动画片'], ['v' => '5295524748', 'n' => '其他电影']
        ];

        $tvClass = [
            ['v' => '', 'n' => '全部'], ['v' => '5141765353', 'n' => '国产剧'], ['v' => '5153048684', 'n' => '港台剧'],
            ['v' => '5165168495', 'n' => '欧美剧'], ['v' => '5176451826', 'n' => '韩剧'], ['v' => '5229374731', 'n' => '日剧'],
            ['v' => '5272958086', 'n' => '泰剧'], ['v' => '5206808079', 'n' => '番剧'], ['v' => '5284241417', 'n' => '其他']
        ];

        $varietyClass = [
            ['v' => '', 'n' => '全部'], ['v' => '6332494542', 'n' => '国产综艺'], ['v' => '6343777873', 'n' => '港台综艺'],
            ['v' => '6355061204', 'n' => '日韩综艺'], ['v' => '6366344535', 'n' => '欧美综艺'], ['v' => '6377627866', 'n' => '其他综艺']
        ];

        $animeClass = [
            ['v' => '', 'n' => '全部'], ['v' => '6389747677', 'n' => '国产动漫'], ['v' => '6392031008', 'n' => '日韩动漫'],
            ['v' => '6303314339', 'n' => '欧美动漫'], ['v' => '6314597660', 'n' => '港台动漫'], ['v' => '6325880991', 'n' => '其他动漫']
        ];

        $filters = [
            '5922692431' => [
                ['key' => 'class', 'name' => '按分类', 'value' => $movieClass],
                ['key' => 'area', 'name' => '按地区', 'value' => $areaValues],
                ['key' => 'year', 'name' => '按年份', 'value' => $yearValues],
                ['key' => 'by', 'name' => '按排序', 'value' => $byValues],
                ['key' => 'lang', 'name' => '按语言', 'value' => $langValues]
            ],
            '5033975762' => [
                ['key' => 'class', 'name' => '按分类', 'value' => $tvClass],
                ['key' => 'area', 'name' => '按地区', 'value' => $areaValues],
                ['key' => 'year', 'name' => '按年份', 'value' => $yearValues],
                ['key' => 'by', 'name' => '按排序', 'value' => $byValues],
                ['key' => 'lang', 'name' => '按语言', 'value' => $langValues]
            ],
            '5046095573' => [
                ['key' => 'class', 'name' => '按分类', 'value' => $varietyClass],
                ['key' => 'area', 'name' => '按地区', 'value' => $areaValues],
                ['key' => 'year', 'name' => '按年份', 'value' => $yearValues],
                ['key' => 'by', 'name' => '按排序', 'value' => $byValues]
            ],
            '5057378904' => [
                ['key' => 'class', 'name' => '按分类', 'value' => $animeClass],
                ['key' => 'area', 'name' => '按地区', 'value' => $areaValues],
                ['key' => 'year', 'name' => '按年份', 'value' => $yearValues],
                ['key' => 'by', 'name' => '按排序', 'value' => $byValues]
            ],
            '5218091400' => [
                ['key' => 'area', 'name' => '按地区', 'value' => $areaValues],
                ['key' => 'year', 'name' => '按年份', 'value' => $yearValues],
                ['key' => 'by', 'name' => '按排序', 'value' => $byValues]
            ]
        ];

        // 首页推荐
        $list = [];
        try {
            $html = $this->fetchHtml($this->API_HOST . '/');
            $list = array_slice($this->extractList($html), 0, 12);
        } catch (Exception $e) {}

        return ['class' => $classes, 'filters' => $filters, 'list' => $list];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        $area = $extend['area'] ?? '';
        $year = $extend['year'] ?? '';
        $cls  = $extend['class'] ?? '';
        $by   = $extend['by'] ?? '';
        $lang = $extend['lang'] ?? '';

        if (in_array($area, ['全部', '不限'])) $area = '';
        if (in_array($year, ['全部', '不限'])) $year = '';
        if (in_array($cls, ['全部', '不限'])) $cls = '';
        if (in_array($by, ['全部', '不限'])) $by = '';
        if (in_array($lang, ['全部', '不限'])) $lang = '';

        if ($cls) {
            $url = "{$this->API_HOST}/filter_sort/vod_list_{$cls}";
            if ($page > 1) $url .= "-{$page}";
            $url .= ".html";
        } else {
            $url = "{$this->API_HOST}/library";
            if ($lang) $url .= '-yuyan-' . urlencode($lang);
            if ($year) $url .= "-year-{$year}";
            $url .= "-tid-{$tid}";
            $url .= "-searchtype-5";
            if ($page > 1) $url .= "-page-{$page}";
            if ($by) $url .= "-order-{$by}";
            if ($area) $url .= '-area-' . urlencode($area);
            $url .= ".html";
        }

        $html = $this->fetchHtml($url);
        $list = $this->extractList($html);

        $pagecount = 1;
        if (preg_match('/href="[^"]*-page-(\d+)-[^"]*">尾页</', $html, $m)) {
            $pagecount = intval($m[1]);
        } else {
            preg_match_all('/-page-(\d+)-/', $html, $m);
            if (!empty($m[1])) {
                $pagecount = max($m[1]);
            }
        }

        return $this->pageResult($list, $page, ($pagecount ?: 1) * 24, 24);
    }

    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $url = strpos($id, 'http') === 0 ? $id : $this->API_HOST . $id;
        $html = $this->fetchHtml($url);
        if (!$html) return ['list' => []];

        $info = $this->extractDetail($html);
        $info['vod_id'] = $id;

        return ['list' => [$info]];
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $url = "{$this->API_HOST}/search.php?searchword=" . urlencode($key);
        $html = $this->fetchHtml($url);
        $list = $this->extractList($html);
        
        return $this->pageResult($list, $page, 24, 24);
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        if (preg_match('/\.(m3u8|mp4|flv|mkv|webm|ts)/i', $id)) {
            return ['parse' => 0, 'url' => $id, 'header' => $this->M3U8_HEADERS];
        }

        $html = $this->fetchHtml($id);
        if (!$html) {
            return ['parse' => 1, 'url' => $id, 'header' => $this->HEADERS];
        }

        $videoUrl = $this->extractM3u8($html);
        if ($videoUrl) {
            return ['parse' => 0, 'url' => $videoUrl, 'header' => $this->M3U8_HEADERS];
        }

        if (preg_match('/<iframe[^>]*src="([^"]+)"[^>]*>/', $html, $m)) {
            $src = $m[1];
            if (strpos($src, '//') === 0) $src = 'https:' . $src;
            if (strpos($src, '/') === 0) $src = $this->API_HOST . $src;
            return ['parse' => 1, 'url' => $src, 'header' => $this->HEADERS];
        }

        return ['parse' => 1, 'url' => $id, 'header' => $this->HEADERS];
    }
}

(new Spider())->run();