<?php
/**
 * 神马影院 - 影视仓 PHP 完美合规版
 * 严格遵循道长规范，完美提取线路名并保留 [集数] 格式
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    protected const HOST = 'https://www.smyyok.com';
    
    protected $headers = [
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language' => 'zh-CN,zh;q=0.9',
        'Referer' => 'https://www.smyyok.com/'
    ];

    public function init($extend = '') {}

    protected function cleanUrl($url) {
        if (!$url) return '';
        $url = str_replace('\\/', '/', $url);
        $url = trim($url, '"\'');
        if (strpos($url, '//') === 0) $url = 'https:' . $url;
        return $url;
    }

    // ============================================================
    // 列表解析
    // ============================================================
    protected function extractList($html) {
        $list = [];
        if (!$html) return $list;

        $items = $this->pdfa($html, '.public-list-box');
        foreach ($items as $item) {
            $vod_id = $this->pdfh($item, 'a.public-list-exp&&href');
            $title  = $this->pdfh($item, 'a.time-title&&title');
            if (!$title) $title = $this->pdfh($item, 'a.time-title&&Text');
            
            $pic    = $this->pd($item, 'img&&data-src');
            $remark = $this->pdfh($item, '.public-list-prb&&Text');

            if ($title && $vod_id) {
                $list[] = [
                    'vod_id' => $vod_id,
                    'vod_name' => trim($title),
                    'vod_pic' => $pic,
                    'vod_remarks' => trim($remark)
                ];
            }
        }
        return $list;
    }

    // ============================================================
    // 首页
    // ============================================================
    public function homeContent($filter) {
        $classes = [
            ["type_name" => "电影", "type_id" => "1"],
            ["type_name" => "电视剧", "type_id" => "2"],
            ["type_name" => "综艺", "type_id" => "3"],
            ["type_name" => "动漫", "type_id" => "4"],
            ["type_name" => "短剧", "type_id" => "5"]
        ];

        $filters = [];
        if ($filter) {
            $areaValues = [
                ["v" => "", "n" => "全部"], ["v" => "大陆", "n" => "大陆"], ["v" => "香港", "n" => "香港"], ["v" => "台湾", "n" => "台湾"],
                ["v" => "美国", "n" => "美国"], ["v" => "日本", "n" => "日本"], ["v" => "韩国", "n" => "韩国"],
                ["v" => "英国", "n" => "英国"], ["v" => "法国", "n" => "法国"], ["v" => "德国", "n" => "德国"],
                ["v" => "意大利", "n" => "意大利"], ["v" => "西班牙", "n" => "西班牙"], ["v" => "俄罗斯", "n" => "俄罗斯"],
                ["v" => "加拿大", "n" => "加拿大"], ["v" => "印度", "n" => "印度"], ["v" => "泰国", "n" => "泰国"],
                ["v" => "其它", "n" => "其它"], ["v" => "新加坡", "n" => "新加坡"], ["v" => "菲律宾", "n" => "菲律宾"]
            ];
            
            $yearValues = [["v" => "", "n" => "全部"]];
            for ($y = 2026; $y >= 2000; $y--) $yearValues[] = ["v" => (string)$y, "n" => (string)$y];
            
            $sortValues = [["v" => "time", "n" => "按最新"], ["v" => "hits", "n" => "按最热"], ["v" => "score", "n" => "按评分"]];

            $classValues1 = [
                ["v" => "", "n" => "全部"], ["v" => "动作片", "n" => "动作片"], ["v" => "喜剧片", "n" => "喜剧片"], ["v" => "科幻片", "n" => "科幻片"],
                ["v" => "恐怖片", "n" => "恐怖片"], ["v" => "爱情片", "n" => "爱情片"], ["v" => "剧情片", "n" => "剧情片"], ["v" => "战争片", "n" => "战争片"],
                ["v" => "记录片", "n" => "记录片"], ["v" => "动画片", "n" => "动画片"], ["v" => "惊悚", "n" => "惊悚"], ["v" => "犯罪", "n" => "犯罪"],
                ["v" => "悬疑", "n" => "悬疑"], ["v" => "冒险", "n" => "冒险"], ["v" => "奇幻", "n" => "奇幻"], ["v" => "家庭", "n" => "家庭"],
                ["v" => "历史", "n" => "历史"], ["v" => "传记", "n" => "传记"], ["v" => "古装", "n" => "古装"], ["v" => "音乐", "n" => "音乐"]
            ];

            $classValues2 = [
                ["v" => "", "n" => "全部"], ["v" => "国产剧", "n" => "国产剧"], ["v" => "欧美剧", "n" => "欧美剧"], ["v" => "香港剧", "n" => "香港剧"],
                ["v" => "韩国剧", "n" => "韩国剧"], ["v" => "台湾剧", "n" => "台湾剧"], ["v" => "日本剧", "n" => "日本剧"], ["v" => "海外剧", "n" => "海外剧"],
                ["v" => "泰国剧", "n" => "泰国剧"], ["v" => "剧情", "n" => "剧情"], ["v" => "爱情", "n" => "爱情"], ["v" => "喜剧", "n" => "喜剧"]
            ];

            $classValues3 = [
                ["v" => "", "n" => "全部"], ["v" => "大陆综艺", "n" => "大陆综艺"], ["v" => "港台综艺", "n" => "港台综艺"], ["v" => "日韩综艺", "n" => "日韩综艺"],
                ["v" => "欧美综艺", "n" => "欧美综艺"], ["v" => "真人秀", "n" => "真人秀"], ["v" => "纪录片", "n" => "纪录片"], ["v" => "脱口秀", "n" => "脱口秀"]
            ];

            $classValues4 = [
                ["v" => "", "n" => "全部"], ["v" => "国产动漫", "n" => "国产动漫"], ["v" => "日韩动漫", "n" => "日韩动漫"], ["v" => "欧美动漫", "n" => "欧美动漫"],
                ["v" => "港台动漫", "n" => "港台动漫"], ["v" => "海外动漫", "n" => "海外动漫"], ["v" => "动画", "n" => "动画"], ["v" => "喜剧", "n" => "喜剧"]
            ];

            $classValues5 = [
                ["v" => "", "n" => "全部"], ["v" => "女频恋爱", "n" => "女频恋爱"], ["v" => "反转爽剧", "n" => "反转爽剧"], ["v" => "古装仙侠", "n" => "古装仙侠"],
                ["v" => "年代穿越", "n" => "年代穿越"], ["v" => "脑洞悬疑", "n" => "脑洞悬疑"], ["v" => "现代都市", "n" => "现代都市"]
            ];

            $filters = [
                "1" => [["key"=>"class","name"=>"类型","value"=>$classValues1], ["key"=>"area","name"=>"地区","value"=>$areaValues], ["key"=>"year","name"=>"年份","value"=>$yearValues], ["key"=>"sort","name"=>"排序","value"=>$sortValues]],
                "2" => [["key"=>"class","name"=>"类型","value"=>$classValues2], ["key"=>"area","name"=>"地区","value"=>$areaValues], ["key"=>"year","name"=>"年份","value"=>$yearValues], ["key"=>"sort","name"=>"排序","value"=>$sortValues]],
                "3" => [["key"=>"class","name"=>"类型","value"=>$classValues3], ["key"=>"area","name"=>"地区","value"=>$areaValues], ["key"=>"year","name"=>"年份","value"=>$yearValues], ["key"=>"sort","name"=>"排序","value"=>$sortValues]],
                "4" => [["key"=>"class","name"=>"类型","value"=>$classValues4], ["key"=>"area","name"=>"地区","value"=>$areaValues], ["key"=>"year","name"=>"年份","value"=>$yearValues], ["key"=>"sort","name"=>"排序","value"=>$sortValues]],
                "5" => [["key"=>"class","name"=>"类型","value"=>$classValues5], ["key"=>"area","name"=>"地区","value"=>$areaValues], ["key"=>"year","name"=>"年份","value"=>$yearValues], ["key"=>"sort","name"=>"排序","value"=>$sortValues]]
            ];
        }

        $html = $this->fetch(self::HOST, [], $this->headers);
        $list = array_slice($this->extractList($html), 0, 12);

        return [
            'class' => $classes,
            'filters' => $filter ? (object)$filters : (object)[],
            'list' => $list
        ];
    }

    public function homeVideoContent() {
        $html = $this->fetch(self::HOST, [], $this->headers);
        $list = array_slice($this->extractList($html), 0, 12);
        return ['list' => $list];
    }

    // ============================================================
    // 分类
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        if (is_string($extend)) $extend = json_decode($extend, true) ?: [];

        $cls    = $extend['class'] ?? '';
        $area   = $extend['area']  ?? '';
        $year   = $extend['year']  ?? '';
        $sort   = $extend['sort']  ?? '';

        $parts = array_fill(0, 12, '');
        $parts[1] = $area;
        $parts[2] = $sort;
        $parts[3] = $cls;
        $parts[8] = ($page > 1) ? $page : '';
        
        $path = "/vodshow/{$tid}" . implode('-', $parts) . "{$year}.html";
        $url = self::HOST . $path;

        $html = $this->fetch($url, [], $this->headers);
        $list = $this->extractList($html);
        
        $pagecount = 1;
        if (preg_match('/共(\d+)条数据,当前(\d+)\/(\d+)页/u', $html, $m)) {
            $pagecount = intval($m[3]) ?: 1;
        }

        return $this->pageResult($list, $page, $pagecount, 24);
    }

    // ============================================================
    // 详情（完美提取线路名并保留 [集数] 格式）
    // ============================================================
    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $url = (strpos($id, 'http') === 0) ? $id : self::HOST . $id;
        $html = $this->fetch($url, [], $this->headers);
        if (!$html) return ['list' => []];

        $info = ['vod_id' => $id];

        // 提取信息参数
        $paramBox = $this->pdfh($html, '.info-parameter&&Html');
        if ($paramBox) {
            $lis = $this->pdfa($paramBox, 'li');
            foreach ($lis as $li) {
                $key = str_replace(['：', ':'], '', $this->pdfh($li, '.cor4&&Text'));
                $content = '';
                $aMatches = $this->pdfa($li, 'a');
                if (!empty($aMatches)) {
                    $texts = [];
                    foreach ($aMatches as $a) $texts[] = $this->pdfh($a, 'a&&Text');
                    $content = implode(' ', $texts);
                } else {
                    $content = str_replace($this->pdfh($li, '.cor4&&Text'), '', $this->pdfh($li, 'li&&Text'));
                }
                $content = trim(preg_replace('/\s+/', ' ', $content));

                if ($key === '片名') $info['vod_name'] = $content;
                elseif ($key === '主演') $info['vod_actor'] = $content;
                elseif ($key === '导演') $info['vod_director'] = $content;
                elseif ($key === '年份') $info['vod_year'] = $content;
                elseif ($key === '地区') $info['vod_area'] = $content;
                elseif ($key === '类型') $info['type_name'] = $content;
            }
        }

        // 简介
        $desc = $this->pdfh($html, '#height_limit&&Text');
        if ($desc) $info['vod_content'] = '神马影院提醒你注意广告防止被骗！' . trim($desc);

        // 封面
        $info['vod_pic'] = $this->pd($html, '.lazy.lazy1.mask-1&&data-src');

        // 🎯 线路名提取：完美拼接 [集数]
        $names = [];
        $tabs = $this->pdfa($html, '.anthology-tab .swiper-slide');
        foreach ($tabs as $tab) {
            $text = $this->pdfh($tab, 'a&&Text');
            $text = trim(html_entity_decode($text));
            
            // 匹配出名字（非数字）和集数（数字）
            if (preg_match('/^([^\d]+)(\d+)?$/u', $text, $m)) {
                $name = trim($m[1]);
                $epCount = isset($m[2]) ? $m[2] : '';
                
                if ($epCount) {
                    $name .= "[{$epCount}]"; // 把数字包进 []
                }
            } else {
                $name = $text; // 实在匹配不到，按原样保留
            }
            
            if ($name && !in_array($name, $names)) {
                $names[] = $name;
            }
        }

        // 剧集列表
        $playFrom = [];
        $playUrl = [];
        $uls = $this->pdfa($html, 'ul.anthology-list-play');
        
        foreach ($uls as $i => $ul) {
            $eps = [];
            $links = $this->pdfa($ul, 'a.hide');
            foreach ($links as $a) {
                $epName = $this->pdfh($a, 'a&&Text');
                $epHref = $this->pd($a, 'a&&href');
                if ($epName && $epHref) $eps[] = $epName . '$' . $epHref;
            }
            if (!empty($eps)) {
                $fromName = $names[$i] ?? ('线路' . ($i + 1));
                $playFrom[] = '【神马影院】' . $fromName;
                $playUrl[] = implode('#', $eps);
            }
        }

        $info['vod_play_from'] = implode('$$$', $playFrom);
        $info['vod_play_url']  = implode('$$$', $playUrl);

        return ['list' => [$info]];
    }

    // ============================================================
    // 搜索
    // ============================================================
    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $encoded = urlencode($key);
        $url = self::HOST . "/vodsearch/{$encoded}-------------.html";
        $html = $this->fetch($url, [], $this->headers);
        $list = $this->extractList($html);
        return $this->pageResult($list, $page, 1, 24);
    }

    // ============================================================
    // 播放
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        if (preg_match('/\.(m3u8|mp4|flv|mkv|webm|ts)/i', $id)) {
            return ['parse' => 0, 'url' => $id, 'header' => (object)$this->headers];
        }

        $url = (strpos($id, 'http') === 0) ? $id : self::HOST . $id;
        $html = $this->fetch($url, [], $this->headers);
        if (!$html) return ['parse' => 1, 'url' => $url, 'header' => (object)$this->headers];

        if (preg_match('/var\s+player_aaaa\s*=\s*({[^;]+})/is', $html, $m)) {
            $jsonStr = $m[1];
            $jsonStr = preg_replace('/([{,])\s*([a-zA-Z0-9_]+)\s*:/', '$1"$2":', $jsonStr);
            $jsonStr = preg_replace('/:\s*\'([^\']*)\'/', ':"$1"', $jsonStr);
            $jsonStr = preg_replace('/,\s*}/', '}', $jsonStr);
            
            $data = json_decode($jsonStr, true);
            if (!empty($data['url'])) {
                return ['parse' => 0, 'url' => $this->cleanUrl($data['url']), 'header' => (object)$this->headers];
            }
        }

        if (preg_match('/(https?:\/\/[^\s<>"^\']+\.m3u8[^\s<>"^\']*)/is', $html, $m3u8Match)) {
            return ['parse' => 0, 'url' => $this->cleanUrl($m3u8Match[1]), 'header' => (object)$this->headers];
        }

        return ['parse' => 1, 'url' => $url, 'header' => (object)$this->headers];
    }

    public function localProxy($param) {
        return null;
    }
}

(new Spider())->run();