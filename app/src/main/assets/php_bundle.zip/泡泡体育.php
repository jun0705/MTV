<?php
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    private const HOST = 'https://www.popozhibo.tv';
    private const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';

    // 完美匹配父类签名的 CURL 抓取（关闭 SSL 校验）
    protected function fetch($url, $options = [], $headers = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        // 教程 5.3 要求的重点：关闭 SSL 校验
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        $httpHeaders = ['User-Agent: ' . self::UA, 'Referer: ' . self::HOST . '/'];
        if (!empty($headers)) {
            $httpHeaders = array_merge($httpHeaders, $headers);
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $httpHeaders);

        $html = curl_exec($ch);
        curl_close($ch);
        return $html;
    }

    public function getName() {
        return '泡泡直播';
    }

    // ==================== 首页数据 ====================
    public function homeContent($filter = []) {
        $classes = [
            ['type_id' => 'all', 'type_name' => '全部直播'],
            ['type_id' => '1', 'type_name' => 'NBA'],
            ['type_id' => '2', 'type_name' => 'CBA'],
            ['type_id' => '8', 'type_name' => '英超'],
            ['type_id' => '9', 'type_name' => '西甲'],
            ['type_id' => '12', 'type_name' => '欧冠']
        ];

        // 影视仓兼容：直接抓取首页比赛放入 list
        $html = $this->fetch(self::HOST . '/');
        $list = [];
        if (!empty($html)) {
            $list = $this->parseList($html);
        }

        return [
            'class' => $classes, 
            'list' => $list,
            'page' => 1,
            'pagecount' => 1,
            'limit' => 30,
            'total' => count($list)
        ];
    }

    public function homeVideoContent() {
        $html = $this->fetch(self::HOST . '/');
        $list = !empty($html) ? $this->parseList($html) : [];
        return ['list' => $list];
    }

    // ==================== 分类列表 ====================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $url = ($tid === 'all' || $tid === '') ? self::HOST . '/' : self::HOST . '/match/' . $tid;
        $html = $this->fetch($url);
        
        $list = !empty($html) ? $this->parseList($html) : [];

        return $this->pageResult($list, $pg, 1, count($list));
    }

    // ==================== 详情页（完美抓取标题+简介+线路） ====================
    public function detailContent($ids) {
        $vid = $ids[0];
        $play_page_url = self::HOST . '/live/' . $vid . '/play';
        
        // 1. 抓取播放页的标题和简介
        $playHtml = $this->fetch($play_page_url);
        $vod_name = '泡泡赛事直播';
        $vod_content = '泡泡直播为您提供的高清赛事直播。';
        
        if (!empty($playHtml)) {
            // 提取 title
            if (preg_match('#<title>(.*?)</title>#is', $playHtml, $titleMatch)) {
                $vod_name = trim($titleMatch[1]);
                $vod_name = str_replace(['_泡泡直播', '直播_泡泡直播', ' - 泡泡直播'], '', $vod_name);
            }
            // 提取 meta description (真实简介)
            if (preg_match('#<meta\s+name="description"\s+content="([^"]+)"#is', $playHtml, $descMatch)) {
                $vod_content = trim($descMatch[1]);
            } else {
                $vod_content = "正在为您直播：" . $vod_name;
            }
        }

        // 2. 抓取 source 接口解密播放线路
        $sourceUrl = self::HOST . '/live/' . $vid . '/source';
        $sourceHtml = $this->fetch($sourceUrl);
        $episodes = [];

        if (!empty($sourceHtml)) {
            $json = json_decode($sourceHtml, true);
            $data = $json['data'] ?? '';

            if (strlen($data) > 8) {
                $b64 = substr($data, 6, -2);
                $pad = strlen($b64) % 4;
                if ($pad > 0) $b64 .= str_repeat('=', 4 - $pad);
                
                $decodedArr = json_decode(base64_decode($b64), true);
                $links = $decodedArr['links'] ?? [];

                foreach ($links as $link) {
                    $name = $link['name'] ?? '未知线路';
                    $rawUrl = str_replace('***', '#', $link['url'] ?? '');
                    
                    $realUrl = '';
                    if (strpos($rawUrl, 'url=') !== false) {
                        parse_str(parse_url($rawUrl, PHP_URL_QUERY), $query);
                        $realUrl = urldecode($query['url'] ?? '');
                    }
                    if (empty($realUrl)) $realUrl = $rawUrl;
                    if (!empty($realUrl)) $episodes[] = "{$name}$" . $realUrl;
                }
            }
        }
        
        if (empty($episodes)) $episodes[] = "暂无信号$";

        // 3. 返回组装好的数据
        return ['list' => [[
            'vod_id' => $vid,
            'vod_name' => $vod_name,
            'vod_pic' => '',
            'vod_content' => $vod_content,
            'vod_play_from' => '直播线路',
            'vod_play_url' => implode('#', $episodes)
        ]]];
    }

    // ==================== 播放解析 ====================
    public function playerContent($flag, $id, $vipFlags = []) {
        // 如果本身是 m3u8/flv 直链，直接播放
        if (strpos($id, '.m3u8') !== false || strpos($id, '.flv') !== false) {
            return [
                'parse' => 0, 
                'playUrl' => '', 
                'url' => $id, 
                'header' => json_encode(['User-Agent' => self::UA, 'Referer' => self::HOST])
            ];
        }
        
        // 如果是外部网页（sportsteam 等），带 Referer 丢给嗅探
        return [
            'parse' => 1, 
            'playUrl' => '', 
            'url' => $id, 
            'header' => json_encode(['User-Agent' => self::UA, 'Referer' => 'http://play.sportsteam368.com/'])
        ];
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        return $this->pageResult([], 1, 1, 0);
    }

    // ==================== 共用列表解析函数 ====================
    private function parseList($html) {
        $list = [];
        // 使用 # 作为分隔符，防止 / 报错
        preg_match_all('#<li[^>]*>(.*?)</li>#is', $html, $matches);
        $blocks = $matches[1] ?? [];
        $seen = [];

        foreach ($blocks as $block) {
            if (strpos($block, 'left-team-name') === false) continue;
            if (!preg_match('#/live/(\d+)/play#is', $block, $idMatch)) continue;
            
            $vid = $idMatch[1];
            if (isset($seen[$vid])) continue;
            $seen[$vid] = true;

            preg_match('#class="[^"]*left-team-name[^"]*"[^>]*>(.*?)</div>#is', $block, $hMatch);
            preg_match('#class="[^"]*right-team-name[^"]*"[^>]*>(.*?)</div>#is', $block, $aMatch);
            preg_match('#class="[^"]*game-time[^"]*"[^>]*>(.*?)</div>#is', $block, $tMatch);
            preg_match('#class="[^"]*game-status[^"]*"[^>]*>(.*?)</span>#is', $block, $sMatch);
            preg_match('#<img[^>]+(?:data-src|src)="([^"]+)"#is', $block, $imgMatch);

            $home = strip_tags(trim($hMatch[1] ?? ''));
            $away = strip_tags(trim($aMatch[1] ?? ''));
            $time = strip_tags(trim($tMatch[1] ?? ''));
            $status = strip_tags(trim($sMatch[1] ?? ''));
            $logo = $imgMatch[1] ?? '';

            if (!empty($logo) && strpos($logo, 'http') !== 0) {
                $logo = self::HOST . $logo;
            }

            $list[] = [
                'vod_id' => $vid,
                'vod_name' => "{$home} VS {$away}",
                'vod_pic' => $logo,
                'vod_remarks' => trim("{$time} {$status}")
            ];
        }

        return $list;
    }
}

// ==================== 启动执行 ====================
(new Spider())->run();