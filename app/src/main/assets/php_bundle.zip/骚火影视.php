<?php
/**
 * 骚火 (SaoHuo) - 影视仓 PHP 完美版
 * 列表已修复，播放完全对齐 Java 逻辑
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    
    protected $host = 'https://shdy2.com';
    protected $cookie = '';
    protected $UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
    protected $YOUKU_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

    public function init($extend = '') {
        if (!empty($extend) && is_string($extend)) {
            $this->host = rtrim(trim($extend), '/');
        }
    }

    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    protected function request($url, $headers = [], $referer = null, $method = 'GET', $body = null) {
        $ch = curl_init();
        $reqHeaders = [
            'User-Agent: ' . $this->UA,
            'accept-language: zh-CN,zh;q=0.9'
        ];

        if ($referer) {
            $reqHeaders[] = 'Referer: ' . $referer;
        }

        if (!empty($headers)) {
            foreach ($headers as $k => $v) {
                $reqHeaders[] = "{$k}: {$v}";
            }
        }

        if ($this->cookie) {
            $reqHeaders[] = 'Cookie: ' . $this->cookie;
        }

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => $reqHeaders,
            CURLOPT_HEADER => true,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if (is_array($body)) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            }
        }

        $response = curl_exec($ch);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $resHeaders = substr($response, 0, $headerSize);
        $content    = substr($response, $headerSize);
        curl_close($ch);

        if (preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $resHeaders, $matches)) {
            $cookies = [];
            foreach ($matches[1] as $c) {
                $cookies[] = trim($c);
            }
            if ($cookies) {
                $this->cookie = implode('; ', $cookies);
            }
        }

        return $content ?: '';
    }

    // ============================================================
    // 核心：播放解析 (严格对齐 Java)
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        // 1. 处理基础 URL
        $playPageUrl = (strpos($id, 'http') === 0) ? $id : $this->host . $id;

        // 2. 请求播放页，尝试提取直链
        $html = $this->request($playPageUrl);
        if ($html) {
            $direct = $this->extractVideoUrl($html);
            if ($direct) {
                $this->outputJson(['parse' => 0, 'url' => $direct, 'jx' => 0]);
            }
        }

        // 3. 提取 hhplayer URL
        $hhUrl = $this->extractHhUrl($html);
        if (!$hhUrl) {
            $this->outputJson(['parse' => 0, 'url' => $playPageUrl, 'jx' => 0]);
        }

        // 4. 请求 hhplayer，尝试提取直链
        $hhHtml = $this->request($hhUrl, [], $playPageUrl);
        if ($hhHtml) {
            $direct = $this->extractVideoUrl($hhHtml);
            if ($direct) {
                $this->outputJson(['parse' => 0, 'url' => $direct, 'jx' => 0]);
            }
        }

        // 5. 提取 __HHJX_BOOTSTRAP__
        $boot = $this->extractBootstrap($hhHtml);
        if (!$boot || empty($boot['url']) || empty($boot['key'])) {
            $this->outputJson(['parse' => 0, 'url' => $hhUrl, 'jx' => 0]);
        }

        // 6. 构造 API 并 POST 请求
        preg_match('/^https?:\/\/([^\/]+)/is', $hhUrl, $m);
        $hhDomain = $m[1] ?? '';
        $apiUrl = 'https://' . $hhDomain . '/api/parse';

        $reqBody = [
            'url' => $boot['url'],
            't' => $boot['t'] ?? '',
            'key' => $boot['key'],
            'client_fallback' => false
        ];
        
        $respText = $this->request($apiUrl, ['Content-Type' => 'application/json'], $hhUrl, 'POST', $reqBody);
        if (!$respText) {
            $this->outputJson(['parse' => 0, 'url' => $hhUrl, 'jx' => 0]);
        }

        // 7. 解析 JSON 响应
        $resp = json_decode($respText, true);
        if (!$resp) {
            // 如果不是 JSON，再尝试正则抓一次直链
            $fb = $this->extractVideoUrl($respText);
            if ($fb) $this->outputJson(['parse' => 0, 'url' => $fb, 'jx' => 0]);
            $this->outputJson(['parse' => 0, 'url' => $hhUrl, 'jx' => 0]);
        }

        if (!isset($resp['code']) || $resp['code'] != 200 || empty($resp['url'])) {
            $this->outputJson(['parse' => 0, 'url' => $hhUrl, 'jx' => 0]);
        }

        // 处理返回的 URL
        $url = str_replace(['\\u0026', '\\/'], ['&', '/'], $resp['url']);
        $ext = strtolower($resp['ext'] ?? '');

        // 分支 1：优酷分支 (ext = youku，或者 url 没 http 且 ext 为空)
        if ($ext === 'youku' || (strpos($url, 'http') !== 0 && $ext === '')) {
            $m3u8 = $this->youkuResolve($url, $hhUrl);
            if ($m3u8) {
                $this->outputJson([
                    'parse' => 0, 
                    'url' => $m3u8, 
                    'jx' => 0,
                    'headers' => ['Referer' => $hhUrl, 'User-Agent' => $this->YOUKU_UA]
                ]);
            }
            $this->outputJson(['parse' => 0, 'url' => $hhUrl, 'jx' => 0]);
        }

        // 分支 2：其它非空 ext
        if ($ext !== '') {
            $this->outputJson(['parse' => 0, 'url' => $hhUrl, 'jx' => 0]);
        }

        // 分支 3：普通直链
        $this->outputJson([
            'parse' => 0, 
            'url' => $url, 
            'jx' => 0,
            'headers' => ['Referer' => $hhUrl, 'User-Agent' => $this->UA]
        ]);
    }

    // ============================================================
    // 优酷核心解析 (完全对齐 Java)
    // ============================================================
    protected function youkuResolve($vid, $hhUrl) {
        try {
            $referer = $hhUrl ?: 'https://hhjx.hhplayer.com/';
            
            // 1. 拿 CNA
            $egUrl = 'https://log.mmstat.com/eg.js?_=' . round(microtime(true) * 1000);
            $egText = $this->request($egUrl, ['User-Agent' => $this->YOUKU_UA, 'accept-language' => 'zh-CN,zh;q=0.9'], $referer);
            if (!preg_match('/Etag\s*=\s*["\']([^"\']+)["\']/is', $egText, $m)) return "";
            $cna = $m[1];

            // 2. 请求优酷 UPS 接口
            $params = 'vid=' . urlencode($vid) . '&ccode=0564&client_ip=192.168.1.1&utid=' . urlencode($cna) . '&client_ts=' . time();
            $upsUrl = 'https://ups.youku.com/ups/get.json?' . $params;

            $text = $this->request($upsUrl, ['User-Agent' => $this->YOUKU_UA, 'Origin' => 'https://hhjx.hhplayer.com', 'accept-language' => 'zh-CN,zh;q=0.9'], $referer);
            if (!$text) return "";
            
            // 剥离 callback
            if (preg_match('/^[^(]+\((.*)\)\s*;?\s*$/s', trim($text), $cbM)) $text = $cbM[1];
            
            $resp = json_decode($text, true);
            if (!$resp || empty($resp['data']) || !empty($resp['data']['error'])) return "";
            
            $streams = $resp['data']['stream'] ?? [];
            if (empty($streams)) return "";

            // 3. 宽高打分，挑最高清
            $best = null;
            $bestScore = -1;
            foreach ($streams as $st) {
                $m3u8 = $st['m3u8_url'] ?? '';
                if (!$m3u8) continue;
                $score = intval($st['width'] ?? 0) * intval($st['height'] ?? 0);
                if ($score > $bestScore) {
                    $bestScore = $score;
                    $best = $m3u8;
                }
            }
            
            if ($best) {
                // 强制 https
                return (strpos($best, 'http://') === 0) ? 'https://' . substr($best, 7) : $best;
            }
        } catch (Exception $e) {
            return "";
        }
        return "";
    }

    // ============================================================
    // 辅助提取方法
    // ============================================================
    protected function extractVideoUrl($text) {
        if (!$text) return "";
        $patterns = [
            '/"url"\s*:\s*"(https?:[^"]+?\.(?:m3u8|mp4|flv)[^"]*)"/is',
            '/"m3u8_url"\s*:\s*"(https?:[^"]+?\.m3u8[^"]*)"/is',
            '/"playUrl"\s*:\s*"(https?:[^"]+?\.(?:m3u8|mp4)[^"]*)"/is',
            '/(https?:[^"\'\s\\\\<>]+?\.(?:m3u8|mp4|flv)[^"\'\s\\\\<>]*)/is'
        ];
        foreach ($patterns as $p) {
            if (preg_match($p, $text, $m)) {
                return str_replace(['\\u0026', '\\/', '&amp;'], ['&', '/', '&'], $m[1]);
            }
        }
        return "";
    }

    protected function extractHhUrl($html) {
        if (!$html) return "";
        if (preg_match('/<iframe[^>]+src=["\'](https?:\/\/[^"\']+[?&]url=[A-Za-z0-9]+)["\']/is', $html, $m)) {
            return str_replace('&amp;', '&', $m[1]);
        }
        if (preg_match('/(https?:\/\/[^"\'\s<>]+[?&]url=[A-Za-z0-9]+)/is', $html, $m)) {
            return str_replace('&amp;', '&', $m[1]);
        }
        return "";
    }

    protected function extractBootstrap($html) {
        if (preg_match('/__HHJX_BOOTSTRAP__\s*=\s*(\{[^}]+\})/is', $html, $m)) {
            return json_decode($m[1], true);
        }
        return null;
    }

    // ============================================================
    // 已有列表与详情逻辑保持不变
    // ============================================================
    public function homeContent($filter) {
        $classes = [
            ["type_id" => "1", "type_name" => "电影"],
            ["type_id" => "2", "type_name" => "电视剧"],
            ["type_id" => "4", "type_name" => "动漫"]
        ];
        $filters = [
            "1" => [["key"=>"cateId", "name"=>"类型", "value"=>[
                ["n"=>"全部","v"=>"1"], ["n"=>"喜剧","v"=>"6"], ["n"=>"爱情","v"=>"7"], ["n"=>"恐怖","v"=>"8"],
                ["n"=>"动作","v"=>"9"], ["n"=>"科幻","v"=>"10"], ["n"=>"战争","v"=>"11"], ["n"=>"犯罪","v"=>"12"],
                ["n"=>"动画","v"=>"13"], ["n"=>"奇幻","v"=>"14"], ["n"=>"剧情","v"=>"15"], ["n"=>"冒险","v"=>"16"],
                ["n"=>"悬疑","v"=>"17"], ["n"=>"惊悚","v"=>"18"], ["n"=>"其他","v"=>"20"]
            ]]],
            "2" => [["key"=>"cateId", "name"=>"类型", "value"=>[
                ["n"=>"全部","v"=>"2"], ["n"=>"国产剧","v"=>"20"], ["n"=>"TVB","v"=>"21"], ["n"=>"韩剧","v"=>"22"],
                ["n"=>"美剧","v"=>"23"], ["n"=>"日剧","v"=>"24"], ["n"=>"英剧","v"=>"25"], ["n"=>"台剧","v"=>"26"], ["n"=>"其他","v"=>"27"]
            ]]],
            "4" => [["key"=>"cateId", "name"=>"类型", "value"=>[
                ["n"=>"全部","v"=>"4"], ["n"=>"搞笑","v"=>"38"], ["n"=>"恋爱","v"=>"39"], ["n"=>"热血","v"=>"40"],
                ["n"=>"格斗","v"=>"41"], ["n"=>"美少女","v"=>"42"], ["n"=>"魔法","v"=>"43"], ["n"=>"机战","v"=>"44"],
                ["n"=>"校园","v"=>"45"], ["n"=>"亲子","v"=>"46"], ["n"=>"童话","v"=>"47"], ["n"=>"冒险","v"=>"48"],
                ["n"=>"真人","v"=>"49"], ["n"=>"LOLI","v"=>"50"], ["n"=>"其他","v"=>"51"]
            ]]]
        ];
        $html = $this->request($this->host);
        $this->outputJson(['class' => $classes, 'filters' => $filters, 'list' => $this->extractList($html, 6)]);
    }

    public function homeVideoContent() {
        $html = $this->request($this->host);
        $this->outputJson(['list' => $this->extractList($html, 6)]);
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        $cateId = !empty($extend['cateId']) ? $extend['cateId'] : $tid;
        $url = "{$this->host}/list/{$cateId}";
        if ($page > 1) $url .= "-{$page}";
        $url .= ".html";
        $html = $this->request($url);
        $list = $this->extractList($html, 0);
        $pagecount = $this->extractPageCount($html, $page, count($list));
        $this->outputJson(['list' => $list, 'page' => $page, 'pagecount' => $pagecount, 'limit' => count($list), 'total' => $pagecount * count($list)]);
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $url = "{$this->host}/s----------.html?wd=" . urlencode($key);
        $html = $this->request($url);
        $this->outputJson(['list' => $this->extractList($html, 0)]);
    }

    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $url = (strpos($id, 'http') === 0) ? $id : $this->host . $id;
        $html = $this->request($url);
        if (!$html) $this->outputJson(['list' => []]);
        $info = ['vod_id' => $id];
        $name = $this->group('/<h1[^>]*class="v_title"[^>]*>[\s\S]*?<a[^>]*>([^<]+)<\/a>/is', $html, 1);
        if (!$name) $name = $this->group('/<h1[^>]*class="title"[^>]*>([^<]+)<\/h1>/is', $html, 1);
        $info['vod_name'] = trim($name);
        $pic = $this->group('/class="m_background"[^>]*style="background-image:url\(([^)]+)\)/is', $html, 1);
        $pic = trim(str_replace(["'", '"'], '', $pic));
        if (!$pic) $pic = $this->group('/<img[^>]*class="lazyload"[^>]*data-original="([^"]+)"/is', $html, 1);
        if (!$pic) $pic = $this->group('/<img[^>]*class="lazyload"[^>]*src="([^"]+)"/is', $html, 1);
        $info['vod_pic'] = (strpos($pic, 'http') !== 0 && $pic) ? $this->host . $pic : $pic;
        $infoLine = $this->group('/<h1[^>]*class="v_title"[^>]*>[\s\S]*?<\/h1>\s*<p>([\s\S]*?)<a/is', $html, 1);
        if (!$infoLine) $infoLine = $this->group('/<h1[^>]*class="v_title"[^>]*>[\s\S]*?<\/h1>\s*<p>([\s\S]*?)<\/p>/is', $html, 1);
        $infoLine = strip_tags($infoLine);
        $segs = array_map('trim', explode('/', $infoLine));
        $vodArea = $segs[0] ?? ''; $vodYear = $segs[1] ?? ''; $typeName = $segs[2] ?? '';
        $vodDirector = ''; $vodActor = '';
        for ($i = 3; $i < count($segs); $i++) {
            $seg = $segs[$i];
            if (strpos($seg, '导演:') === 0) $vodDirector = trim(mb_substr($seg, 3));
            elseif (strpos($seg, '主演:') === 0) {
                $vodActor = trim(mb_substr($seg, 3));
                $vodActor = preg_replace('/剧情介绍.*$/u', '', $vodActor);
            }
        }
        $info['vod_director'] = $vodDirector; $info['vod_actor'] = $vodActor;
        $info['vod_area'] = $vodArea; $info['vod_year'] = $vodYear; $info['type_name'] = $typeName;
        $content = $this->group('/<p[^>]*class="p_txt[^"]*"[^>]*>([\s\S]*?)<\/p>/is', $html, 1);
        if (!$content) $content = $this->group('/<[^>]*class="intro"[^>]*>([\s\S]*?)</is', $html, 1);
        if (!$content) $content = $this->group('/<[^>]*class="des"[^>]*>([\s\S]*?)</is', $html, 1);
        $content = strip_tags($content);
        $content = preg_replace('/^(剧情)?简介[:：]\s*/u', '', $content);
        $info['vod_content'] = trim($content);
        list($info['vod_play_from'], $info['vod_play_url']) = $this->extractPlaylist($html);
        $this->outputJson(['list' => [$info]]);
    }

    protected function extractList($html, $limit = 0) {
        $list = [];
        if (!$html) return $list;
        $pattern = '/<a[^>]*href="([^"]+)"[^>]*title="([^"]*)"[^>]*>[\s\S]*?<img[^>]*(?:data-original|src)="([^"]+)"[^>]*>[\s\S]*?<\/a>/is';
        if (preg_match_all($pattern, $html, $matches, PREG_SET_ORDER)) {
            $seen = [];
            $count = 0;
            foreach ($matches as $m) {
                if ($limit > 0 && $count >= $limit) break;
                $href = $m[1]; $title = trim($m[2]); $pic = $m[3];
                if (!$title || !$href || isset($seen[$href])) continue;
                $seen[$href] = true;
                $list[] = [
                    'vod_id' => (strpos($href, 'http') === 0) ? $href : $this->host . $href,
                    'vod_name' => $title,
                    'vod_pic' => (strpos($pic, 'http') === 0) ? $pic : $this->host . $pic,
                    'vod_remarks' => ''
                ];
                $count++;
            }
        }
        return $list;
    }

    protected function extractPageCount($html, $page, $listSize) {
        $pagecount = $page;
        if (preg_match_all('/<a[^>]*href="[^"]*[-_](\d+)\.html"[^>]*>/is', $html, $m)) {
            $maxPage = 0;
            foreach ($m[1] as $p) if (intval($p) > $maxPage) $maxPage = intval($p);
            if ($maxPage > 0) $pagecount = $maxPage;
            elseif ($listSize >= 10) $pagecount = $page + 1;
        }
        return $pagecount;
    }

    protected function extractPlaylist($html) {
        $sourceNames = []; $sourceUrls = [];
        $tmpNames = [];
        if (preg_match_all('/<[^>]*class="[^"]*from_list[^"]*"[^>]*>([\s\S]*?)<\/ul>/is', $html, $fromM)) {
            foreach ($fromM[1] as $block) {
                if (preg_match_all('/<li[^>]*>([\s\S]*?)<\/li>/is', $block, $liM)) {
                    foreach ($liM[1] as $li) {
                        $nm = trim(strip_tags($li));
                        if ($nm) $tmpNames[] = $nm;
                    }
                }
            }
        }
        $linkBlocks = [];
        if (preg_match_all('/<ul[^>]*id="play_link"[^>]*>([\s\S]*?)<\/ul>/is', $html, $linkM)) {
            $linkBlocks = $linkM[1];
        }
        if (!empty($linkBlocks)) {
            $inner = $linkBlocks[0];
            if (preg_match_all('/<li[^>]*>([\s\S]*?)<\/li>/is', $inner, $liM)) {
                $idx = 0;
                foreach ($liM[1] as $block) {
                    $eps = $this->extractEpisodes($block);
                    if (!empty($eps)) {
                        $sourceNames[] = $tmpNames[$idx] ?? "线路" . ($idx + 1);
                        $sourceUrls[] = implode('#', $eps);
                    }
                    $idx++;
                }
            }
        }
        if (empty($sourceNames)) {
            if (preg_match_all('/<li[^>]*>([\s\S]*?)<\/li>/is', $html, $liM)) {
                $idx = 0;
                foreach ($liM[1] as $block) {
                    if (strpos($block, 'play_link') === false && strpos($block, '<a') === false) continue;
                    $eps = $this->extractEpisodes($block);
                    if (!empty($eps)) {
                        $sourceNames[] = "线路" . ($idx + 1);
                        $sourceUrls[] = implode('#', $eps);
                        $idx++;
                    }
                }
            }
        }
        return [implode('$$$', $sourceNames), implode('$$$', $sourceUrls)];
    }

    protected function extractEpisodes($block) {
        $eps = [];
        if (preg_match_all('/<a[^>]*href="([^"]+)"[^>]*>([^<]+)<\/a>/is', $block, $aM, PREG_SET_ORDER)) {
            foreach ($aM as $m) {
                $href = $m[1]; $text = trim($m[2]);
                $numStr = preg_replace('/[^0-9]/', '', $text);
                $num = $numStr !== '' ? intval($numStr) : 9999;
                $eps[] = ['text'=>$text, 'href'=>$href, 'num'=>$num];
            }
        }
        usort($eps, function($a, $b) { return $a['num'] - $b['num']; });
        $res = [];
        foreach ($eps as $ep) $res[] = "{$ep['text']}\${$ep['href']}";
        return $res;
    }

    protected function group($regex, $text, $groupIndex = 1) {
        if (!$text) return "";
        if (preg_match($regex, $text, $matches)) {
            return isset($matches[$groupIndex]) ? trim($matches[$groupIndex]) : "";
        }
        return "";
    }

    public function localProxy($param) {
        return null;
    }
}

(new Spider())->run();