<?php
/**
 * 开心影院 - kxyy1.cc
 * 由 开心影院.js 转换
 * @header({
 *   searchable: 1,
 *   filterable: 1,
 *   quickSearch: 0,
 *   title: '开心影院',
 *   lang: 'php'
 * })
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    private $API_HOST = 'https://www.kxyy1.cc';

    private $UA = 'Mozilla/5.0 (Linux; Android 14; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

    // ============================================================
    //  Header
    // ============================================================
    private function headers() {
        return [
            'User-Agent'      => $this->UA,
            'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language' => 'zh-CN,zh;q=0.9',
            'Referer'         => $this->API_HOST . '/',
            'Connection'      => 'keep-alive',
        ];
    }

    private function m3u8Headers() {
        return (object)[
            'User-Agent' => $this->UA,
            'Referer'    => $this->API_HOST . '/',
            'Accept'     => '*/*',
            'Connection' => 'keep-alive',
        ];
    }

    // ============================================================
    //  工具
    // ============================================================
    private function fetchHtml($url) {
        $res = $this->fetch($url, [], $this->headers());
        return $res ?: '';
    }

    private function fixUrl($url) {
        $u = trim((string)$url);
        if ($u === '') return '';
        if (strpos($u, '//') === 0) return 'https:' . $u;
        if (strpos($u, 'http') === 0) return $u;
        if (strpos($u, '/') === 0) return $this->API_HOST . $u;
        return $this->API_HOST . '/' . $u;
    }

    private function cleanUrl($url) {
        $u = trim((string)$url);
        if ($u === '') return '';
        $u = str_replace(['\\/', '\\"', '\\\\'], ['/', '"', '\\'], $u);
        $u = trim($u, "\"'");
        if (strpos($u, '//') === 0) $u = 'https:' . $u;
        return $u;
    }

    // ============================================================
    //  m3u8 暴力提取（6 种策略）
    // ============================================================
    private function extractM3u8($html) {
        if (!$html) return null;

        // 策略1
        if (preg_match('/["\']url["\']\s*:\s*["\']([^"\']+\.m3u8[^"\']*)["\']/i', $html, $m)) {
            return $this->cleanUrl($m[1]);
        }
        // 策略2
        if (preg_match('/["\']url["\']\s*:\s*["\']([^"\']+)["\']/i', $html, $m)) {
            $u = $this->cleanUrl($m[1]);
            if ($u !== '' && strpos($u, '.m3u8') !== false) return $u;
        }
        // 策略3
        if (preg_match('/var\s+player_data\s*=\s*(\{[^}]*\})/', $html, $m)) {
            if (preg_match('/["\']url["\']\s*:\s*["\']([^"\']+)["\']/', $m[1], $um)) {
                $u = $this->cleanUrl($um[1]);
                if ($u !== '' && strpos($u, '.m3u8') !== false) return $u;
            }
        }
        // 策略4
        if (preg_match('/var\s+now\s*=\s*["\']([^"\']+\.m3u8[^"\']*)["\']/', $html, $m)) {
            return $this->cleanUrl($m[1]);
        }
        // 策略5
        if (preg_match_all('/["\'](https?:\/\/[^"\'\s<>]+\.m3u8[^"\'\s<>]*)["\']/i', $html, $ms)) {
            $u = $this->cleanUrl($ms[1][0]);
            if ($u !== '') return $u;
        }
        // 策略6
        if (preg_match('/(https?:\/\/[^\s<>"\']+\.m3u8[^\s<>"\']*)/i', $html, $m)) {
            return $this->cleanUrl($m[1]);
        }
        return null;
    }

    // ============================================================
    //  列表解析
    // ============================================================
    private function extractList($html) {
        $list = [];
        if (!$html) return $list;

        $items = [];
        if (preg_match_all('/<div class="card card-sm card-link">[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/i', $html, $ms)) {
            $items = $ms[0];
        }
        if (!$items) return $list;

        foreach ($items as $item) {
            if (!preg_match('/href="(\/voddetail\/\d+\.html)"/', $item, $href)) continue;

            $title = '';
            if (preg_match('/<h[34][^>]*class="[^"]*card-title[^"]*"[^>]*>([^<]+)<\/h[34]>/i', $item, $t)) {
                $title = trim($t[1]);
            }

            $pic = '';
            if (preg_match('/<img[^>]*src="(https?:\/\/[^"]+)"/i', $item, $p)) {
                $pic = $p[1];
            } elseif (preg_match('/data-src="([^"]+)"/i', $item, $p)) {
                $pic = $p[1];
            } elseif (preg_match('/data-original="([^"]+)"/i', $item, $p)) {
                $pic = $p[1];
            }

            $remark = '';
            if (preg_match('/<span class="badge[^"]*">([^<]+)<\/span>/i', $item, $b)) {
                $remark = trim($b[1]);
            } elseif (preg_match('/<strong class="ribbon[^"]*">([^<]+)<\/strong>/i', $item, $s)) {
                $remark = trim($s[1]);
            } elseif (preg_match('/<p class="text-muted">([^<]+)<\/p>/i', $item, $d)) {
                $remark = trim($d[1]);
            }

            $list[] = [
                'vod_id'      => $this->fixUrl($href[1]),
                'vod_name'    => $title,
                'vod_pic'     => $pic ? $this->fixUrl($pic) : '',
                'vod_remarks' => $remark,
            ];
        }
        return $list;
    }

    // ============================================================
    //  播放列表解析
    // ============================================================
    private function extractPlaylist($html) {
        $playFrom = [];
        $playUrlList = [];

        if (preg_match_all('/<a[^>]*href="#tabs-home-\d+"[^>]*>([\s\S]*?)<\/a>/i', $html, $tabs)) {
            foreach ($tabs[0] as $tab) {
                if (!preg_match('/href="#(tabs-home-\d+)"/', $tab, $tid)) continue;
                if (!preg_match('/>([^<]+)</', $tab, $nm)) continue;

                $tabId = $tid[1];
                $name = trim(str_replace('&nbsp;', '', $nm[1]));
                $name = trim(preg_replace('/\s+/', ' ', $name));
                if ($name === '') continue;

                $paneRe = '/<div class="tab-pane[^"]*" id="' . preg_quote($tabId, '/') . '">([\s\S]*?)<\/div>/i';
                if (!preg_match($paneRe, $html, $pm)) continue;

                $eps = [];
                if (preg_match_all('/<a[^>]*href="(\/vodplay\/[^"]+\.html)"[^>]*>([^<]+)<\/a>/i', $pm[1], $ems, PREG_SET_ORDER)) {
                    foreach ($ems as $em) {
                        $eps[] = trim($em[2]) . '$' . $this->fixUrl($em[1]);
                    }
                }
                if ($eps) {
                    $playFrom[] = $name;
                    $playUrlList[] = implode('#', $eps);
                }
            }
        }

        if (!$playFrom) {
            $eps = [];
            if (preg_match_all('/<a[^>]*href="(\/vodplay\/[^"]+\.html)"[^>]*>([^<]+)<\/a>/i', $html, $ems, PREG_SET_ORDER)) {
                foreach ($ems as $em) {
                    $eps[] = trim($em[2]) . '$' . $this->fixUrl($em[1]);
                }
            }
            if ($eps) {
                $playFrom[] = '开心影院';
                $playUrlList[] = implode('#', $eps);
            }
        }

        return [$playFrom, $playUrlList];
    }

    // ============================================================
    //  Spider 入口
    // ============================================================
    public function init($extend = '') { return true; }

    public function homeContent($filter) {
        $yearValues = [
            ['v'=>'','n'=>'全部'],
            ['v'=>'2026','n'=>'2026'],['v'=>'2025','n'=>'2025'],['v'=>'2024','n'=>'2024'],
            ['v'=>'2023','n'=>'2023'],['v'=>'2022','n'=>'2022'],['v'=>'2021','n'=>'2021'],
            ['v'=>'2020','n'=>'2020'],['v'=>'2019','n'=>'2019'],['v'=>'2018','n'=>'2018'],
            ['v'=>'2017','n'=>'2017'],['v'=>'2016','n'=>'2016'],['v'=>'2015','n'=>'2015'],
            ['v'=>'2014','n'=>'2014'],['v'=>'2013','n'=>'2013'],['v'=>'2012','n'=>'2012'],
            ['v'=>'2011','n'=>'2011'],['v'=>'2010','n'=>'2010'],['v'=>'2009','n'=>'2009'],
            ['v'=>'2008','n'=>'2008'],['v'=>'2007','n'=>'2007'],['v'=>'2006','n'=>'2006'],
            ['v'=>'2005','n'=>'2005'],['v'=>'2004','n'=>'2004'],['v'=>'2003','n'=>'2003'],
            ['v'=>'2002','n'=>'2002'],['v'=>'2001','n'=>'2001'],['v'=>'2000','n'=>'2000'],
            ['v'=>'90年代','n'=>'90年代'],['v'=>'80年代','n'=>'80年代'],['v'=>'70年代','n'=>'70年代'],['v'=>'其他','n'=>'其他'],
        ];
        $areaValues = [
            ['v'=>'','n'=>'全部'],['v'=>'中国大陆','n'=>'中国大陆'],['v'=>'中国香港','n'=>'中国香港'],
            ['v'=>'中国台湾','n'=>'中国台湾'],['v'=>'美国','n'=>'美国'],['v'=>'日本','n'=>'日本'],
            ['v'=>'韩国','n'=>'韩国'],['v'=>'泰国','n'=>'泰国'],['v'=>'英国','n'=>'英国'],
            ['v'=>'法国','n'=>'法国'],['v'=>'德国','n'=>'德国'],['v'=>'意大利','n'=>'意大利'],['v'=>'其他','n'=>'其他'],
        ];
        $sortValues = [
            ['v'=>'','n'=>'默认'],['v'=>'time','n'=>'更新时间'],['v'=>'hits_week','n'=>'近期热门'],['v'=>'douban_score','n'=>'豆瓣评分'],
        ];
        $classValues = [
            ['v'=>'','n'=>'全部'],['v'=>'爱情','n'=>'爱情'],['v'=>'古装','n'=>'古装'],['v'=>'悬疑','n'=>'悬疑'],
            ['v'=>'都市','n'=>'都市'],['v'=>'喜剧','n'=>'喜剧'],['v'=>'战争','n'=>'战争'],['v'=>'剧情','n'=>'剧情'],
            ['v'=>'青春','n'=>'青春'],['v'=>'历史','n'=>'历史'],['v'=>'网剧','n'=>'网剧'],['v'=>'奇幻','n'=>'奇幻'],
            ['v'=>'冒险','n'=>'冒险'],['v'=>'励志','n'=>'励志'],['v'=>'犯罪','n'=>'犯罪'],['v'=>'商战','n'=>'商战'],
            ['v'=>'恐怖','n'=>'恐怖'],['v'=>'穿越','n'=>'穿越'],['v'=>'农村','n'=>'农村'],['v'=>'人物','n'=>'人物'],
            ['v'=>'商业','n'=>'商业'],['v'=>'生活','n'=>'生活'],['v'=>'其他','n'=>'其他'],
        ];
        $classValuesTv = [
            ['v'=>'','n'=>'全部'],['v'=>'古装','n'=>'古装'],['v'=>'战争','n'=>'战争'],['v'=>'青春偶像','n'=>'青春偶像'],
            ['v'=>'喜剧','n'=>'喜剧'],['v'=>'家庭','n'=>'家庭'],['v'=>'犯罪','n'=>'犯罪'],['v'=>'动作','n'=>'动作'],
            ['v'=>'奇幻','n'=>'奇幻'],['v'=>'剧情','n'=>'剧情'],['v'=>'历史','n'=>'历史'],['v'=>'经典','n'=>'经典'],
            ['v'=>'乡村','n'=>'乡村'],['v'=>'情景','n'=>'情景'],['v'=>'商战','n'=>'商战'],['v'=>'网剧','n'=>'网剧'],['v'=>'其他','n'=>'其他'],
        ];

        $filters = [
            '1' => [
                ['key'=>'area','name'=>'地区','value'=>$areaValues],
                ['key'=>'by','name'=>'排序','value'=>$sortValues],
                ['key'=>'class','name'=>'类型','value'=>$classValues],
                ['key'=>'year','name'=>'年份','value'=>$yearValues],
            ],
            '2' => [
                ['key'=>'area','name'=>'地区','value'=>$areaValues],
                ['key'=>'by','name'=>'排序','value'=>$sortValues],
                ['key'=>'class','name'=>'类型','value'=>$classValuesTv],
                ['key'=>'year','name'=>'年份','value'=>$yearValues],
            ],
            '3' => [
                ['key'=>'area','name'=>'地区','value'=>$areaValues],
                ['key'=>'by','name'=>'排序','value'=>$sortValues],
                ['key'=>'year','name'=>'年份','value'=>$yearValues],
            ],
            '4' => [
                ['key'=>'area','name'=>'地区','value'=>[
                    ['v'=>'','n'=>'全部'],['v'=>'中国大陆','n'=>'中国大陆'],['v'=>'日本','n'=>'日本'],['v'=>'欧美','n'=>'欧美'],['v'=>'其他','n'=>'其他'],
                ]],
                ['key'=>'by','name'=>'排序','value'=>$sortValues],
                ['key'=>'year','name'=>'年份','value'=>$yearValues],
            ],
            '26' => [
                ['key'=>'area','name'=>'地区','value'=>[
                    ['v'=>'','n'=>'全部'],['v'=>'中国大陆','n'=>'中国大陆'],['v'=>'中国香港','n'=>'中国香港'],['v'=>'中国台湾','n'=>'中国台湾'],
                ]],
                ['key'=>'by','name'=>'排序','value'=>$sortValues],
                ['key'=>'year','name'=>'年份','value'=>$yearValues],
            ],
            '24' => [
                ['key'=>'area','name'=>'地区','value'=>[
                    ['v'=>'','n'=>'全部'],['v'=>'中国大陆','n'=>'中国大陆'],['v'=>'美国','n'=>'美国'],['v'=>'英国','n'=>'英国'],
                ]],
                ['key'=>'by','name'=>'排序','value'=>$sortValues],
                ['key'=>'year','name'=>'年份','value'=>$yearValues],
            ],
        ];

        return [
            'class' => [
                ['type_id'=>'1','type_name'=>'电影'],
                ['type_id'=>'2','type_name'=>'电视剧'],
                ['type_id'=>'4','type_name'=>'动漫'],
                ['type_id'=>'3','type_name'=>'综艺'],
                ['type_id'=>'26','type_name'=>'短剧'],
                ['type_id'=>'24','type_name'=>'纪录片'],
            ],
            'filters' => (object)$filters,
        ];
    }

    public function homeVideoContent() {
        $html = $this->fetchHtml($this->API_HOST . '/');
        return ['list' => array_slice($this->extractList($html), 0, 12)];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        try {
            $page = max(1, intval($pg));
            if (is_string($extend)) $extend = json_decode($extend, true) ?: [];
            $extend = is_array($extend) ? $extend : [];

            $area = (string)($extend['area'] ?? '');
            $cls  = (string)($extend['class'] ?? '');
            $by   = (string)($extend['by'] ?? '');
            $year = (string)($extend['year'] ?? '');

            $url = "{$this->API_HOST}/vodshow/{$tid}";
            $url .= '-' . ($area !== '' ? urlencode($area) : '');
            $url .= '-' . ($by !== '' ? $by : '');
            $url .= '-' . ($cls !== '' ? urlencode($cls) : '');
            $url .= "-----{$page}---" . ($year !== '' ? $year : '') . '.html';

            $html = $this->fetchHtml($url);
            $videos = $this->extractList($html);

            $pagecount = 1;
            if (preg_match('/href="\/vodshow\/[^"]+-------(\d+)---\.html"[^>]*>尾页</', $html, $m)) {
                $pagecount = intval($m[1]);
            } else {
                if (preg_match_all('/href="\/vodshow\/[^"]+-------(\d+)---\.html"/', $html, $ms)) {
                    $nums = [];
                    foreach ($ms[1] as $n) {
                        $n = intval($n);
                        if ($n > 0) $nums[] = $n;
                    }
                    if ($nums) $pagecount = max($nums);
                }
            }

            return $this->pageResult($videos, $page, $pagecount, $pagecount * 24);
        } catch (\Throwable $e) {
            return $this->pageResult([], max(1, intval($pg)), 1, 0);
        }
    }

    public function detailContent($ids) {
        $id = is_array($ids) ? ($ids[0] ?? '') : $ids;
        $html = $this->fetchHtml($id);
        if (!$html) return ['list' => []];

        $info = ['vod_id' => $id];

        $vod_name = '';
        if (preg_match('/<h1[^>]*>([^<]+)<\/h1>/', $html, $t)) {
            $vod_name = trim($t[1]);
        }
        if ($vod_name === '' && preg_match('/<title>《([^》]+)》/', $html, $t2)) {
            $vod_name = trim($t2[1]);
        }
        $info['vod_name'] = $vod_name;

        $vod_pic = '';
        if (preg_match('/<img[^>]*src="(https?:\/\/[^"]+)"[^>]*referrerpolicy="no-referrer"[^>]*alt="/', $html, $p)) {
            $vod_pic = $this->fixUrl($p[1]);
        }
        $info['vod_pic'] = $vod_pic;

        $vod_director = '';
        if (preg_match('/<strong>导演：<\/strong>([\s\S]*?)<\/p>/', $html, $dir)) {
            if (preg_match_all('/>([^<]+)</', $dir[1], $links)) {
                $vod_director = implode(',', array_map('trim', $links[1]));
            }
        }
        $info['vod_director'] = $vod_director;

        $vod_actor = '';
        if (preg_match('/<strong>主演：<\/strong>([\s\S]*?)<\/p>/', $html, $actor)) {
            if (preg_match_all('/>([^<]+)</', $actor[1], $links)) {
                $vod_actor = implode(',', array_map('trim', $links[1]));
            }
        }
        $info['vod_actor'] = $vod_actor;

        $vod_class = '';
        if (preg_match('/<strong>类型：<\/strong>([\s\S]*?)<\/p>/', $html, $tm)) {
            $vod_class = trim(preg_replace('/\s+/', ' ', strip_tags($tm[1])));
        }
        $info['vod_class'] = $vod_class;

        $vod_area = '';
        if (preg_match('/<strong>制片国家\/地区：<\/strong>([^<]+)<\/p>/', $html, $am)) {
            $vod_area = trim(str_replace(['[',']'], '', $am[1]));
        }
        $info['vod_area'] = $vod_area;

        $vod_year = '';
        if (preg_match('/<strong>上映日期：<\/strong>(\d{4})/', $html, $ym)) {
            $vod_year = $ym[1];
        }
        $info['vod_year'] = $vod_year;

        $vod_content = '';
        if (preg_match('/<div class="accordion-collapse collapse" id="synopsis">[\s\S]*?<p>([\s\S]*?)<\/p>/', $html, $dm)) {
            $vod_content = trim(preg_replace('/\s+/', ' ', strip_tags($dm[1])));
        }
        $info['vod_content'] = $vod_content;

        list($playFrom, $playUrlList) = $this->extractPlaylist($html);
        $info['vod_play_from'] = $playFrom ? implode('$$$', $playFrom) : '开心影院';
        $info['vod_play_url']  = $playUrlList ? implode('$$$', $playUrlList) : '';

        return ['list' => [$info]];
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        try {
            $page = max(1, intval($pg));
            $url = "{$this->API_HOST}/vodsearch/" . urlencode($key) . '-------------.html';
            $html = $this->fetchHtml($url);
            $videos = $this->extractList($html);
            return ['list' => $videos, 'page' => $page, 'pagecount' => 999];
        } catch (\Throwable $e) {
            return ['list' => []];
        }
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        // 1. 已是视频地址
        if (preg_match('/\.(m3u8|mp4|flv|mkv|webm|ts)/i', $id)) {
            return ['parse'=>0, 'url'=>$id, 'header'=>$this->m3u8Headers()];
        }
        if (strpos($id, '.m3u8') !== false) {
            return ['parse'=>0, 'url'=>$id, 'header'=>$this->m3u8Headers()];
        }

        // 2. 请求播放页
        $html = $this->fetchHtml($id);
        if (!$html) {
            return ['parse'=>1, 'url'=>$id, 'header'=>$this->m3u8Headers()];
        }

        // 3. 暴力提取
        $videoUrl = $this->extractM3u8($html);

        // 4. iframe
        if (!$videoUrl) {
            if (preg_match('/<iframe[^>]*src=["\']([^"\']+)["\']/i', $html, $im)) {
                $src = $im[1];
                if (strpos($src, '//') === 0) $src = 'https:' . $src;
                if (strpos($src, '/') === 0)  $src = $this->API_HOST . $src;
                if (preg_match('/\.m3u8/i', $src)) {
                    return ['parse'=>0, 'url'=>$src, 'header'=>$this->m3u8Headers()];
                }
                return ['parse'=>1, 'url'=>$src, 'header'=>$this->m3u8Headers()];
            }
        }

        // 5. 返回 m3u8
        if ($videoUrl) {
            $videoUrl = $this->cleanUrl($videoUrl);
            if (strpos($videoUrl, '//') === 0) $videoUrl = 'https:' . $videoUrl;
            return ['parse'=>0, 'url'=>$videoUrl, 'header'=>$this->m3u8Headers()];
        }

        // 6. 兜底
        return ['parse'=>1, 'url'=>$id, 'header'=>$this->m3u8Headers()];
    }
}

(new Spider())->run();