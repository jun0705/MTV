<?php
/**
 * 极速直播 - 影视仓 PHP 完美一比一复刻版
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    
    protected $apiHost = 'https://2nhz2p44gxpwf9sptxb12.k8v4dh4.app';
    protected $referer = 'https://jszb11.app/';
    protected $UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';
    protected $OSS = 'https://img0.aiscore.com/';

    // 强制输出 JSON 字符串并终止进程
    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    protected function requestUrl($url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => [
                'User-Agent: ' . $this->UA,
                'Referer: ' . $this->referer,
                'Origin: ' . rtrim($this->referer, '/'),
                'Accept: application/json, text/plain, */*'
            ]
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function safeJson($text) {
        $text = trim($text);
        if (!$text) return [];
        if (strpos($text, '{') !== false && substr($text, 0, 1) !== '{') {
            $start = strpos($text, '{');
            $end = strrpos($text, '}');
            if ($start !== false && $end !== false) {
                $text = substr($text, $start, $end - $start + 1);
            }
        }
        $decoded = json_decode($text, true);
        return is_array($decoded) ? $decoded : [];
    }

    // ============================================================
    // 工具函数
    // ============================================================
    protected function formatHot($n) {
        $n = floatval($n);
        if ($n >= 100000000) return round($n / 100000000, 1) . '亿';
        if ($n >= 10000) return round($n / 10000, 1) . '万';
        return (string)$n;
    }

    protected function pickTime($obj) {
        if (!$obj) return 0;
        $keys = ['matchTime', 'startTime', 'beginTime', 'matchDate', 'liveTime', 'startAt', 'beginAt', 'time'];
        foreach ($keys as $k) {
            if (empty($obj[$k])) continue;
            $v = $obj[$k];
            if (is_numeric($v)) return (float)$v;
            $s = trim((string)$v);
            if (preg_match('/^\d+$/', $s)) return (float)$s;
            $ts = strtotime(str_replace('-', '/', $s));
            if ($ts !== false) return $ts * 1000;
        }
        return 0;
    }

    protected function timeText($obj) {
        $ts = $this->pickTime($obj);
        if (!$ts) return '';
        if ($ts < 1e10) $ts *= 1000;
        $sec = (int)($ts / 1000);
        $today = date('Y-m-d');
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        $target = date('Y-m-d', $sec);
        $hm = date('H:i', $sec);
        
        if ($target === $today) return '今天 ' . $hm;
        if ($target === $tomorrow) return '明天 ' . $hm;
        return date('m-d H:i', $sec);
    }

    protected function isFinishedByTime($obj) {
        $ts = $this->pickTime($obj);
        if (!$ts) return false;
        if ($ts < 1e10) $ts *= 1000;
        return $ts < (time() * 1000) - (2 * 3600 * 1000);
    }

    protected function normalize($url) {
        $url = trim((string)$url);
        if (!$url) return '';
        if (preg_match('/^(webrtc|javascript|about|data|blob|#)/i', $url)) return '';
        if (strpos($url, '//') === 0) $url = 'https:' . $url;
        if (strpos($url, '/') === 0) $url = $this->apiHost . $url;
        if (!preg_match('/^https?:\/\//i', $url) && strpos($url, 'm3u8') !== 0) return '';
        return $url;
    }

    protected function collectUrls($obj) {
        if (!$obj) return [];
        $cands = [
            $obj['playStreamAddress2'] ?? '', $obj['playStreamAddress'] ?? '', $obj['playUrl'] ?? '',
            $obj['streamUrl'] ?? '', $obj['liveUrl'] ?? '', $obj['m3u8'] ?? '', $obj['m3u8Url'] ?? '',
            $obj['videoUrl'] ?? '', $obj['flvUrl'] ?? '', $obj['rtmpUrl'] ?? ''
        ];
        $out = [];
        foreach ($cands as $u) {
            $n = $this->normalize($u);
            if ($n && !in_array($n, $out)) $out[] = $n;
        }
        return $out;
    }

    protected function hasPlayableUrl($anchor) {
        return count($this->collectUrls($anchor)) > 0;
    }

    protected function isValidAnchor($anchor) {
        return !empty($anchor['houseId']) && $this->hasPlayableUrl($anchor);
    }

    protected function firstPlayableUrl($anchor) {
        $urls = $this->collectUrls($anchor);
        return $urls[0] ?? '';
    }

    protected function matchIdOf($obj) {
        if (!$obj) return '';
        return (string)($obj['matchId'] ?? ($obj['match_id'] ?? ($obj['id'] ?? '')));
    }

    protected function matchName($match) {
        $league = $match['competition']['name'] ?? ($match['competition']['competitionName'] ?? '');
        $home = $match['homeTeam']['name'] ?? ($match['homeTeam']['teamName'] ?? '');
        $away = $match['awayTeam']['name'] ?? ($match['awayTeam']['teamName'] ?? '');
        return trim("$league $home VS $away");
    }

    protected function matchPic($match) {
        $logo = $match['homeTeam']['logo'] ?? '';
        if (!$logo) return '';
        return strpos($logo, 'http') === 0 ? $logo : $this->OSS . $logo;
    }

    // ============================================================
    // 壳子标准接口
    // ============================================================

    public function init($extend = '') {
        // 可以根据 ext 动态覆盖 apiHost / referer
    }

    public function homeContent($filter) {
        $this->outputJson([
            'class' => [
                ['type_id' => 'recommend', 'type_name' => '🔥 推荐'],
                ['type_id' => 'football', 'type_name' => '⚽ 足球直播'],
                ['type_id' => 'basketball', 'type_name' => '🏀 篮球直播'],
                ['type_id' => 'official', 'type_name' => '🏆 官方直播'],
                ['type_id' => 'schedule', 'type_name' => '📅 未开播']
            ],
            'filters' => (object)[]
        ]);
    }

    public function homeVideoContent() {
        $res = json_decode($this->categoryContent('recommend', 1, [], []), true);
        $this->outputJson(['list' => $res['list'] ?? []]);
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $tid = $tid ?: 'recommend';
        $list = [];
        $seen = [];

        $url = "{$this->apiHost}/api/c5/business/livehouse/index";
        $json = $this->safeJson($this->requestUrl($url));
        $data = $json['data'] ?? [];

        $anchors = array_merge($data['ongoingLivestreams'] ?? [], $data['anchorLivestreams'] ?? []);
        $anchors = array_filter($anchors, [$this, 'isValidAnchor']);
        
        $matchList = $data['matchLivestreams'] ?? [];

        // 1. 🏆 官方直播
        if ($tid === 'official') {
            foreach ($matchList as $it) {
                $match = $it['result']['match'] ?? $it;
                $mid = $this->matchIdOf($match);
                if (!$mid) continue;
                $sportId = (int)($match['sportId'] ?? 0);
                if ($sportId !== 1 && $sportId !== 2) continue;
                
                $officialUrl = $this->normalize($match['videoUrl'] ?? '');
                if (!$officialUrl) continue;

                $vid = 'match$' . $mid . '$' . urlencode($officialUrl);
                if (isset($seen[$vid])) continue;
                $seen[$vid] = true;

                $time = $this->timeText($match);
                $list[] = [
                    'vod_id' => $vid,
                    'vod_name' => $this->matchName($match),
                    'vod_pic' => $this->matchPic($match),
                    'vod_remarks' => ($time ? $time . ' · ' : '') . '🏆 直播中 · 官方'
                ];
            }
            $this->outputJson(['page' => 1, 'pagecount' => 1, 'limit' => 100, 'total' => count($list), 'list' => $list]);
        }

        // 2. 📅 未开播
        if ($tid === 'schedule') {
            $anchorMatchIds = [];
            foreach ($anchors as $a) {
                $mid = $this->matchIdOf($a);
                if ($mid) $anchorMatchIds[$mid] = true;
            }
            
            foreach ($matchList as $it) {
                $match = $it['result']['match'] ?? $it;
                $mid = $this->matchIdOf($match);
                if (!$mid) continue;
                $sportId = (int)($match['sportId'] ?? 0);
                if ($sportId !== 1 && $sportId !== 2) continue;
                
                if (isset($anchorMatchIds[$mid])) continue;
                if ($this->normalize($match['videoUrl'] ?? '')) continue;

                $vid = 'match$' . $mid . '$';
                if (isset($seen[$vid])) continue;
                $seen[$vid] = true;

                $time = $this->timeText($match);
                $list[] = [
                    'vod_id' => $vid,
                    'vod_name' => $this->matchName($match),
                    'vod_pic' => $this->matchPic($match),
                    'vod_remarks' => ($time ? $time . ' · ' : '') . ($this->isFinishedByTime($match) ? '✅ 已结束' : '⏰ 未开播')
                ];
            }
            $this->outputJson(['page' => 1, 'pagecount' => 1, 'limit' => 100, 'total' => count($list), 'list' => $list]);
        }

        // 3. 🔥 推荐 / ⚽ 足球 / 🏀 篮球
        foreach ($anchors as $a) {
            if (empty($a['houseId'])) continue;
            if ((int)($a['liveStatus'] ?? 0) !== 2) continue;
            if (!$this->hasPlayableUrl($a)) continue;

            $rt = (int)($a['raceTypeId'] ?? 0);
            if ($tid === 'football' && $rt !== 1) continue;
            if ($tid === 'basketball' && $rt !== 2) continue;
            if ($tid === 'recommend' && $rt !== 1 && $rt !== 2) continue;

            $addr = $this->firstPlayableUrl($a);
            $vid = 'a$' . $a['houseId'] . '$' . urlencode($addr);
            if (isset($seen[$vid])) continue;
            $seen[$vid] = true;

            $name = $a['houseName'] ?? ($a['nickName'] ?? '直播间');
            $time = $this->timeText($a);
            $hot = $this->formatHot($a['visitHistory'] ?? 0);
            $list[] = [
                'vod_id' => $vid,
                'vod_name' => $name,
                'vod_pic' => $a['houseImage'] ?? ($a['userImage'] ?? ''),
                'vod_remarks' => ($time ? $time . ' · ' : '') . '🔴 直播中 · ' . ($a['nickName'] ?? '主播') . ' (' . $hot . ')'
            ];
        }

        $this->outputJson(['page' => 1, 'pagecount' => 1, 'limit' => 100, 'total' => count($list), 'list' => $list]);
    }

    public function detailContent($ids) {
        $vid = trim((string)(is_array($ids) ? $ids[0] : $ids));

        // a$houseId$addr
        if (strpos($vid, 'a$') === 0) {
            $parts = explode('$', $vid);
            $houseId = $parts[1] ?? '';
            $addr = !empty($parts[2]) ? urldecode($parts[2]) : '';

            $name = '直播间 ' . $houseId;
            $pic = '';
            $liveStatus = 0;
            $urls = [];

            $url = "{$this->apiHost}/api/c3/business/livehouse/detail?houseId=" . urlencode($houseId);
            $json = $this->safeJson($this->requestUrl($url));
            $ad = $json['data']['anchorDetail'] ?? [];
            
            if (!empty($ad['houseName']) || !empty($ad['nickName'])) $name = $ad['houseName'] ?? $ad['nickName'];
            if (!empty($ad['houseImage']) || !empty($ad['userImage'])) $pic = $ad['houseImage'] ?? $ad['userImage'];
            $liveStatus = (int)($ad['liveStatus'] ?? 0);

            $urls = $this->collectUrls($ad);
            if ($addr && !in_array($addr, $urls)) array_unshift($urls, $addr);

            if (!empty($urls)) {
                $playUrls = [];
                foreach ($urls as $i => $u) {
                    $playUrls[] = ($i === 0 ? '高清线路$' : '备用线路$') . $u;
                }
                $this->outputJson(['list' => [[
                    'vod_id' => $vid, 'vod_name' => $name, 'vod_pic' => $pic,
                    'vod_remarks' => $liveStatus === 2 ? '直播中' : '未开播',
                    'vod_content' => '⚠️ 极速体育提醒您：注意防诈骗，禁止传播低俗消息。',
                    'vod_play_from' => '主播解说',
                    'vod_play_url' => implode('#', $playUrls)
                ]]]);
            }
            
            if ($addr) {
                $this->outputJson(['list' => [[
                    'vod_id' => $vid, 'vod_name' => $name, 'vod_pic' => $pic,
                    'vod_remarks' => '直播中',
                    'vod_content' => '⚠️ 极速体育提醒您：注意防诈骗，禁止传播低俗消息。',
                    'vod_play_from' => '主播解说',
                    'vod_play_url' => '高清线路$' . $addr
                ]]]);
            }
            $this->outputJson(['list' => []]);
        }

        // match$matchId$url
        if (strpos($vid, 'match$') === 0) {
            $parts = explode('$', $vid);
            $videoUrl = !empty($parts[2]) ? urldecode($parts[2]) : '';
            $nUrl = $this->normalize($videoUrl);
            
            if ($nUrl) {
                $this->outputJson(['list' => [[
                    'vod_id' => $vid, 'vod_name' => '官方赛事直播', 'vod_pic' => '',
                    'vod_content' => '⚠️ 极速体育提醒您：注意防诈骗，禁止传播低俗消息。',
                    'vod_play_from' => '官方线路',
                    'vod_play_url' => '高清线路$' . $nUrl
                ]]]);
            }
            $this->outputJson(['list' => [[
                'vod_id' => $vid, 'vod_name' => '赛事未开播/已结束', 'vod_pic' => '',
                'vod_content' => '该比赛尚未开始或已结束，暂无可用直播线路。',
                'vod_play_from' => '官方线路',
                'vod_play_url' => '暂无$javascript:void(0);'
            ]]]);
        }

        // 裸 houseId
        $url = "{$this->apiHost}/api/c3/business/livehouse/detail?houseId=" . urlencode($vid);
        $json = $this->safeJson($this->requestUrl($url));
        $ad = $json['data']['anchorDetail'] ?? [];
        $urls = $this->collectUrls($ad);
        
        if (empty($urls)) $this->outputJson(['list' => []]);

        $playUrls = [];
        foreach ($urls as $i => $u) {
            $playUrls[] = ($i === 0 ? '高清线路$' : '备用线路$') . $u;
        }
        
        $this->outputJson(['list' => [[
            'vod_id' => $vid,
            'vod_name' => $ad['houseName'] ?? ($ad['nickName'] ?? ('直播间 ' . $vid)),
            'vod_pic' => $ad['houseImage'] ?? ($ad['userImage'] ?? ''),
            'vod_remarks' => (int)($ad['liveStatus'] ?? 0) === 2 ? '直播中' : '未开播',
            'vod_content' => '⚠️ 极速体育提醒您：注意防诈骗，禁止传播低俗消息。',
            'vod_play_from' => '主播解说',
            'vod_play_url' => implode('#', $playUrls)
        ]]]);
    }

    public function searchContent($wd, $quick = false, $pg = 1) {
        if (!$wd) $this->outputJson(['page' => 1, 'list' => []]);

        $url = "{$this->apiHost}/api/c5/business/livehouse/index";
        $json = $this->safeJson($this->requestUrl($url));
        $data = $json['data'] ?? [];
        
        $anchors = array_merge($data['ongoingLivestreams'] ?? [], $data['anchorLivestreams'] ?? []);
        $anchors = array_filter($anchors, [$this, 'isValidAnchor']);

        $seen = [];
        $list = [];
        foreach ($anchors as $it) {
            if (empty($it['houseId'])) continue;
            if ((int)($it['liveStatus'] ?? 0) !== 2) continue;
            
            $n = (string)($it['houseName'] ?? ($it['nickName'] ?? ''));
            if (mb_strpos($n, $wd) === false) continue;
            if (isset($seen[$it['houseId']])) continue;
            $seen[$it['houseId']] = true;

            $addr = $this->firstPlayableUrl($it);
            $list[] = [
                'vod_id' => 'a$' . $it['houseId'] . '$' . urlencode($addr),
                'vod_name' => $n,
                'vod_pic' => $it['houseImage'] ?? ($it['userImage'] ?? ''),
                'vod_remarks' => '🔴 直播中 · ' . ($it['nickName'] ?? '主播')
            ];
        }
        $this->outputJson(['page' => 1, 'list' => $list]);
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        $url = (string)$id;
        $idx = strrpos($url, '$');
        if ($idx !== false) $url = substr($url, $idx + 1);
        
        $nUrl = $this->normalize($url);
        
        if (!$nUrl) {
            $this->outputJson(['parse' => 0, 'url' => '', 'header' => ['User-Agent' => $this->UA]]);
        }
        
        $this->outputJson([
            'parse' => 0,
            'url' => $nUrl,
            'header' => [
                'User-Agent' => $this->UA,
                'Referer' => $this->referer,
                'Origin' => rtrim($this->referer, '/'),
                'Accept' => 'application/json, text/plain, */*'
            ]
        ]);
    }
}

(new Spider())->run();