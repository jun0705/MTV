<?php
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    private $API_HOST = 'https://cjysw.cc';
    private $UA_MB = 'Mozilla/5.0 (Linux; Android 13; SM-G9910) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

    private $HEADERS = [];
    private $M3U8_HEADERS = [];

    public function __construct() {
        $this->HEADERS = [
            'User-Agent: ' . $this->UA_MB,
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: zh-CN,zh;q=0.9',
            'Referer: ' . $this->API_HOST . '/'
        ];
        // 播放专用 header（无 Referer）
        $this->M3U8_HEADERS = [
            'User-Agent' => $this->UA_MB,
            'Accept' => '*/*'
        ];
    }

    // ============================================================
    // 工具
    // ============================================================
    private function fetchHtml($url, $headers = null) {
        try {
            $h = $headers ?: $this->HEADERS;
            $res = $this->fetch($url, [], $h);
            return $res ?: '';
        } catch (Exception $e) {
            return '';
        }
    }

    private function fixUrl($url) {
        if (!$url) return '';
        if (strpos($url, '//') === 0) return 'https:' . $url;
        if (strpos($url, 'http') === 0) return $url;
        if (strpos($url, '/') === 0) return $this->API_HOST . $url;
        return $this->API_HOST . '/' . $url;
    }

    private function cleanText($t) {
        if (!$t) return '';
        $t = str_replace('&nbsp;', ' ', $t);
        $t = preg_replace('/<[^>]+>/', '', $t);
        return trim(preg_replace('/\s+/u', ' ', $t));
    }

    // ============================================================
    // 列表卡片解析
    // ============================================================
    private function parseCards($html) {
        $list = [];
        if (!$html) return $list;

        preg_match_all('/<a[^>]*href="([^"]+)"[^>]*class="[^"]*module-poster-item[^"]*"[^>]*>([\s\S]*?)<\/a>/', $html, $matches, PREG_SET_ORDER);

        foreach ($matches as $m) {
            $href = $m[1];
            $body = $m[2];

            $title = '';
            if (preg_match('/<div[^>]*class="[^"]*module-poster-item-title[^"]*"[^>]*>([^<]*)<\/div>/', $body, $tM)) {
                $title = trim($tM[1]);
            }

            $note = '';
            if (preg_match('/<div[^>]*class="[^"]*module-item-note[^"]*"[^>]*>([^<]*)<\/div>/', $body, $nM)) {
                $note = trim($nM[1]);
            }

            $pic = '';
            if (preg_match('/<img[^>]*data-original="([^"]+)"/', $body, $pM) || 
                preg_match('/<img[^>]*src="([^"]+)"/', $body, $pM)) {
                $pic = $pM[1];
            }

            if ($title) {
                $list[] = [
                    'vod_id'      => $this->fixUrl($href),
                    'vod_name'    => $title,
                    'vod_pic'     => $this->fixUrl($pic),
                    'vod_remarks' => $note
                ];
            }
        }
        return $list;
    }

    // ============================================================
    // 首页分类 + 筛选
    // ============================================================
    public function homeContent($filter) {
        $classes = [
            ['type_id' => '1',  'type_name' => '电影'],
            ['type_id' => '15', 'type_name' => '剧集'],
            ['type_id' => '30', 'type_name' => '动漫'],
            ['type_id' => '24', 'type_name' => '综艺'],
            ['type_id' => '63', 'type_name' => '纪录片'],
            ['type_id' => '47', 'type_name' => '短剧'],
            ['type_id' => '60', 'type_name' => 'Netflix']
        ];

        $MOVIE_CLASS = [
            ['v'=>'', 'n'=>'全部'], ['v'=>'动作', 'n'=>'动作'], ['v'=>'喜剧', 'n'=>'喜剧'], ['v'=>'爱情', 'n'=>'爱情'], ['v'=>'科幻', 'n'=>'科幻'],
            ['v'=>'恐怖', 'n'=>'恐怖'], ['v'=>'剧情', 'n'=>'剧情'], ['v'=>'战争', 'n'=>'战争'], ['v'=>'犯罪', 'n'=>'犯罪'], ['v'=>'动画', 'n'=>'动画'],
            ['v'=>'奇幻', 'n'=>'奇幻'], ['v'=>'冒险', 'n'=>'冒险'], ['v'=>'悬疑', 'n'=>'悬疑'], ['v'=>'惊悚', 'n'=>'惊悚'], ['v'=>'古装', 'n'=>'古装'], ['v'=>'历史', 'n'=>'历史']
        ];
        $TV_CLASS = [
            ['v'=>'', 'n'=>'全部'], ['v'=>'国产剧', 'n'=>'国产剧'], ['v'=>'港剧', 'n'=>'港剧'], ['v'=>'台剧', 'n'=>'台剧'], ['v'=>'日剧', 'n'=>'日剧'],
            ['v'=>'韩剧', 'n'=>'韩剧'], ['v'=>'美剧', 'n'=>'美剧'], ['v'=>'英剧', 'n'=>'英剧'], ['v'=>'泰剧', 'n'=>'泰剧']
        ];
        $AREA_LIST = [
            ['v'=>'', 'n'=>'全部'], ['v'=>'大陆', 'n'=>'大陆'], ['v'=>'香港', 'n'=>'香港'], ['v'=>'台湾', 'n'=>'台湾'], ['v'=>'美国', 'n'=>'美国'],
            ['v'=>'日本', 'n'=>'日本'], ['v'=>'韩国', 'n'=>'韩国'], ['v'=>'英国', 'n'=>'英国'], ['v'=>'法国', 'n'=>'法国'], ['v'=>'德国', 'n'=>'德国'],
            ['v'=>'泰国', 'n'=>'泰国'], ['v'=>'印度', 'n'=>'印度'], ['v'=>'其他', 'n'=>'其他']
        ];
        $YEAR_LIST = [
            ['v'=>'', 'n'=>'全部'], ['v'=>'2026', 'n'=>'2026'], ['v'=>'2025', 'n'=>'2025'], ['v'=>'2024', 'n'=>'2024'],
            ['v'=>'2023', 'n'=>'2023'], ['v'=>'2022', 'n'=>'2022'], ['v'=>'2021', 'n'=>'2021'], ['v'=>'2020', 'n'=>'2020']
        ];
        $S_YEAR_LIST = [
            ['v'=>'', 'n'=>'全部'], ['v'=>'2026', 'n'=>'2026'], ['v'=>'2025', 'n'=>'2025'], ['v'=>'2024', 'n'=>'2024']
        ];

        $filters = [
            '1' => [
                ['key'=>'class', 'name'=>'类型', 'value'=>$MOVIE_CLASS],
                ['key'=>'area', 'name'=>'地区', 'value'=>$AREA_LIST],
                ['key'=>'year', 'name'=>'年份', 'value'=>$YEAR_LIST]
            ],
            '15' => [
                ['key'=>'class', 'name'=>'类型', 'value'=>$TV_CLASS],
                ['key'=>'area', 'name'=>'地区', 'value'=>$AREA_LIST],
                ['key'=>'year', 'name'=>'年份', 'value'=>$YEAR_LIST]
            ],
            '30' => [
                ['key'=>'area', 'name'=>'地区', 'value'=>[
                    ['v'=>'', 'n'=>'全部'], ['v'=>'大陆', 'n'=>'大陆'], ['v'=>'日本', 'n'=>'日本'], ['v'=>'美国', 'n'=>'美国']
                ]],
                ['key'=>'year', 'name'=>'年份', 'value'=>$S_YEAR_LIST]
            ],
            '24' => [['key'=>'year', 'name'=>'年份', 'value'=>$S_YEAR_LIST]],
            '63' => [['key'=>'year', 'name'=>'年份', 'value'=>$S_YEAR_LIST]],
            '47' => [['key'=>'year', 'name'=>'年份', 'value'=>[
                ['v'=>'', 'n'=>'全部'], ['v'=>'2026', 'n'=>'2026'], ['v'=>'2025', 'n'=>'2025']
            ]]],
            '60' => [['key'=>'year', 'name'=>'年份', 'value'=>[
                ['v'=>'', 'n'=>'全部'], ['v'=>'2026', 'n'=>'2026'], ['v'=>'2025', 'n'=>'2025']
            ]]]
        ];

        $list = [];
        $html = $this->fetchHtml($this->API_HOST . '/');
        $list = array_slice($this->parseCards($html), 0, 30);

        return ['class' => $classes, 'filters' => $filters, 'list' => $list];
    }

    // ============================================================
    // 分类
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        $cls  = $extend['class'] ?? '';
        $area = $extend['area'] ?? '';
        $year = $extend['year'] ?? '';

        $path = "/index.php/vod/show/id/{$tid}";
        if ($cls)  $path .= "/class/" . urlencode($cls);
        if ($area) $path .= "/area/" . urlencode($area);
        if ($year) $path .= "/year/" . urlencode($year);
        if ($page > 1) $path .= "/page/{$page}";
        $path .= ".html";

        $html = $this->fetchHtml($this->API_HOST . $path);
        $list = $this->parseCards($html);

        $pagecount = $page + 1;
        preg_match_all('/<a[^>]*class="[^"]*page-link[^"]*"[^>]*>(\d+)<\/a>/', $html, $pMs);
        if (!empty($pMs[1])) {
            $pagecount = max(array_map('intval', $pMs[1]));
        }

        return $this->pageResult($list, $page, $pagecount, 90);
    }

    // ============================================================
    // 详情
    // ============================================================
    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $url = strpos($id, 'http') === 0 ? $id : $this->API_HOST . $id;
        $html = $this->fetchHtml($url);
        if (!$html) return ['list' => []];

        $info = [
            'vod_id'       => $id,
            'vod_name'     => '',
            'vod_pic'      => '',
            'vod_content'  => '',
            'vod_actor'    => '',
            'vod_director' => '',
            'vod_year'     => '',
            'vod_remarks'  => '',
            'vod_play_from'=> '',
            'vod_play_url' => ''
        ];

        if (preg_match('/<h1[^>]*>([^<]+)<\/h1>/', $html, $m)) $info['vod_name'] = trim($m[1]);

        if (preg_match('/<img[^>]*class="[^"]*lazy[^"]*"[^>]*data-original="([^"]+)"/', $html, $m) ||
            preg_match('/<img[^>]*class="[^"]*lazy[^"]*"[^>]*src="([^"]+)"/', $html, $m) ||
            preg_match('/<img[^>]*data-original="([^"]+)"/', $html, $m)) {
            $info['vod_pic'] = $this->fixUrl($m[1]);
        }

        if (preg_match('/<div[^>]*class="[^"]*module-info-introduction-content[^"]*"[^>]*>([\s\S]*?)<\/div>/', $html, $m)) {
            $info['vod_content'] = $this->cleanText($m[1]);
        }

        preg_match_all('/<div[^>]*class="[^"]*module-info-item[^"]*"[^>]*>[\s\S]*?<span[^>]*class="[^"]*module-info-item-title[^"]*"[^>]*>([^<]*)<\/span>[\s\S]*?<div[^>]*class="[^"]*module-info-item-content[^"]*"[^>]*>([\s\S]*?)<\/div>/', $html, $iMs, PREG_SET_ORDER);
        foreach ($iMs as $im) {
            $title = trim(str_replace(['：', ':'], '', $im[1]));
            $value = $this->cleanText($im[2]);
            if (strpos($title, '导演') !== false) $info['vod_director'] = $value;
            elseif (strpos($title, '主演') !== false) $info['vod_actor'] = $value;
            elseif (strpos($title, '年份') !== false) $info['vod_year'] = $value;
            elseif (strpos($title, '集数') !== false || strpos($title, '更新') !== false) $info['vod_remarks'] = $value;
        }

        $tabNames = [];
        preg_match_all('/<div[^>]*class="[^"]*module-tab-item[^"]*"[^>]*>[\s\S]*?<span>([^<]+)<\/span>/', $html, $tMs);
        if (!empty($tMs[1])) {
            foreach ($tMs[1] as $n) {
                $n = trim($n);
                if ($n && !in_array($n, $tabNames)) $tabNames[] = $n;
            }
        }

        $playFrom = [];
        $playUrl = [];
        preg_match_all('/<div[^>]*class="[^"]*module-play-list[^"]*"[^>]*>([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>/', $html, $bMs);
        $idx = 0;
        foreach ($bMs[1] as $body) {
            $eps = [];
            preg_match_all('/<a[^>]*class="[^"]*module-play-list-link[^"]*"[^>]*href="([^"]+)"[^>]*>[\s\S]*?<span>([^<]+)<\/span>/', $body, $aMs, PREG_SET_ORDER);
            foreach ($aMs as $am) {
                $epUrl = $am[1];
                $epName = $this->cleanText($am[2]);
                if ($epName) $eps[] = $epName . '$' . $this->fixUrl($epUrl);
            }
            if (!empty($eps)) {
                $playFrom[] = isset($tabNames[$idx]) ? $tabNames[$idx] : ('线路' . ($idx + 1));
                $playUrl[] = implode('#', $eps);
                $idx++;
            }
        }

        if (empty($playFrom)) {
            $eps = [];
            preg_match_all('/<a[^>]*class="[^"]*module-play-list-link[^"]*"[^>]*href="([^"]+)"[^>]*>[\s\S]*?<span>([^<]+)<\/span>/', $html, $aMs, PREG_SET_ORDER);
            foreach ($aMs as $am) {
                $epUrl = $am[1];
                $epName = $this->cleanText($am[2]);
                if ($epName) $eps[] = $epName . '$' . $this->fixUrl($epUrl);
            }
            if (!empty($eps)) {
                $playFrom[] = '默认';
                $playUrl[] = implode('#', $eps);
            }
        }

        $info['vod_play_from'] = implode('$$$', $playFrom);
        $info['vod_play_url']  = implode('$$$', $playUrl);

        return ['list' => [$info]];
    }

    // ============================================================
    // 搜索
    // ============================================================
    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $url = "{$this->API_HOST}/index.php/vod/search.html?wd=" . urlencode($key) . "&page={$page}";
        $html = $this->fetchHtml($url);

        $list = [];
        preg_match_all('/<div[^>]*class="[^"]*module-card-item[^"]*"[^>]*>([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>/', $html, $matches);
        foreach ($matches[1] as $body) {
            $href = ''; $title = ''; $note = ''; $pic = '';
            
            if (preg_match('/<a[^>]*href="([^"]+)"[^>]*class="[^"]*module-card-item-poster[^"]*"/', $body, $hM) ||
                preg_match('/<a[^>]*href="([^"]+)"[^>]*>/', $body, $hM)) {
                $href = $hM[1];
            }
            if (preg_match('/<strong>([^<]+)<\/strong>/', $body, $tM) ||
                preg_match('/module-card-item-title[^>]*>[\s\S]*?<a[^>]*>([^<]+)<\/a>/', $body, $tM)) {
                $title = trim($tM[1]);
            }
            if (preg_match('/<div[^>]*class="[^"]*module-item-note[^"]*"[^>]*>([^<]*)<\/div>/', $body, $nM)) {
                $note = trim($nM[1]);
            }
            if (preg_match('/<img[^>]*data-original="([^"]+)"/', $body, $pM) || preg_match('/<img[^>]*src="([^"]+)"/', $body, $pM)) {
                $pic = $pM[1];
            }

            if ($title) {
                $list[] = [
                    'vod_id' => $this->fixUrl($href),
                    'vod_name' => $title,
                    'vod_pic' => $this->fixUrl($pic),
                    'vod_remarks' => $note
                ];
            }
        }

        return $this->pageResult($list, $page, 9999, 15);
    }

    // ============================================================
    // 播放（完美还原 jxapi 动态解析）
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        // ① 入参直链
        if (preg_match('/\.(m3u8|mp4|flv|mkv|webm|ts)(\?|$)/i', $id)) {
            return ['parse' => 0, 'url' => $id, 'header' => $this->M3U8_HEADERS];
        }

        // ② 抓播放页
        $pageUrl = strpos($id, 'http') === 0 ? $id : $this->API_HOST . $id;
        $html = $this->fetchHtml($pageUrl);
        
        // 简单重试一次
        if (!$html || strpos($html, 'player_aaaa') === false) {
            sleep(1);
            $html = $this->fetchHtml($pageUrl);
        }
        if (!$html) {
            return ['parse' => 0, 'url' => '', 'header' => $this->M3U8_HEADERS];
        }

        // ③ 抠 player_aaaa
        $realUrl = '';
        if (preg_match('/var\s+player_aaaa\s*=\s*({[\s\S]*?})\s*<\/script>/', $html, $pm)) {
            $jsonStr = str_replace('\\/', '/', $pm[1]);
            // PHP 的 json_decode 对单引号、无引号键名支持不好，这里写个简单的兼容
            $jsonStr = preg_replace('/([{,])\s*([a-zA-Z0-9_]+)\s*:/', '$1"$2":', $jsonStr);
            $jsonStr = preg_replace("/:\s*'([^']*)'/", ':"$1"', $jsonStr);
            $p = json_decode($jsonStr, true);
            if ($p && !empty($p['url'])) {
                $realUrl = $p['url'];
                if (strpos($realUrl, '//') === 0) $realUrl = 'https:' . $realUrl;
            }
        }

        // ④ 是 m3u8/mp4 → 直连
        if ($realUrl && preg_match('/\.(m3u8|mp4|flv)(\?|$)/i', $realUrl)) {
            return ['parse' => 0, 'url' => $realUrl, 'header' => $this->M3U8_HEADERS];
        }

        // ⑤ 自营线 → 从 playerconfig.js 动态抠 jxapi 模板
        if ($realUrl) {
            $tpl = $this->getJxapiTemplate($html);
            if ($tpl) {
                $apiUrl = $tpl . urlencode($realUrl);
                $reqHeaders = [
                    'User-Agent: ' . $this->UA_MB,
                    'Accept: application/json,*/*',
                    'Referer: ' . $this->API_HOST . '/'
                ];
                $resp = $this->fetchHtml($apiUrl, $reqHeaders);
                if ($resp) {
                    $j = json_decode($resp, true);
                    if ($j && isset($j['code']) && $j['code'] == 200 && !empty($j['url'])) {
                        $videoUrl = str_replace('\\/', '/', $j['url']);
                        return ['parse' => 0, 'url' => $videoUrl, 'header' => $this->M3U8_HEADERS];
                    }
                }
            }
        }

        // ⑥ 全失败
        return ['parse' => 0, 'url' => '', 'header' => $this->M3U8_HEADERS];
    }

    // 提取 jxapi 模板
    private function getJxapiTemplate($html) {
        if (!preg_match('/src="([^"]*playerconfig\.js[^"]*)"/', $html, $cfgM)) return '';
        
        $cfgUrl = $cfgM[1];
        if (strpos($cfgUrl, '//') === 0) $cfgUrl = 'https:' . $cfgUrl;
        elseif (strpos($cfgUrl, '/') === 0) $cfgUrl = $this->API_HOST . $cfgUrl;

        $cfgJs = $this->fetchHtml($cfgUrl);
        if (!$cfgJs) return '';

        $tpl = '';
        if (preg_match('/"parse"\s*:\s*"([^"]*jxapi[^"]*)"/', $cfgJs, $m)) {
            $tpl = str_replace('\\/', '/', $m[1]);
        }
        if (!$tpl) return '';

        // 替换 &player → &from=player
        if (preg_match('/[?&]player(&|$)/', $tpl)) {
            $tpl = preg_replace('/([?&])player(&|$)/', '$1from=player$2', $tpl);
        } else {
            $sep = strpos($tpl, '?') !== false ? '&' : '?';
            $tpl .= $sep . 'from=player';
        }
        return $tpl;
    }
}

(new Spider())->run();