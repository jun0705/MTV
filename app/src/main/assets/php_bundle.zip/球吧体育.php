<?php
/**
 * 球吧直播 - 影视仓 PHP 版（由 球吧.js 转换）
 * @header({
 *   searchable: 1,
 *   filterable: 0,
 *   quickSearch: 0,
 *   title: '球吧直播',
 *   lang: 'php'
 * })
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    private $host = 'https://www.qiuba008.vip';

    private $UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';

    // 同一请求内缓存，避免 category/search 重复拉
    private static $cache = [];

    // ======================================================
    //  Header
    // ======================================================
    private function apiHeaders() {
        return [
            'User-Agent' => $this->UA,
            'Accept'     => 'application/json, text/plain, */*',
            'Referer'    => $this->host . '/',
            'Origin'     => $this->host,
        ];
    }

    // 流媒体头：绝对不能带 Referer（CDN 仅放行无 Referer 或同源）
    private function streamHeaders() {
        return (object)['User-Agent' => $this->UA];
    }

    // ======================================================
    //  工具
    // ======================================================
    private function fixUrl($path) {
        $v = trim((string)$path);
        if ($v === '') return '';
        if (strpos($v, 'http') === 0) return $v;
        if (strpos($v, '//') === 0) return 'https:' . $v;
        return $this->host . (strpos($v, '/') === 0 ? '' : '/') . $v;
    }

    private function safeText($v, $fb = '') {
        if ($v === null) return $fb;
        return trim((string)$v);
    }

    private function cleanName($name) {
        $s = trim(str_replace(['$', '#'], ' ', (string)$name));
        return $s !== '' ? $s : '播放';
    }

    private function cleanPlayUrl($url) {
        return str_replace('#', '%23', trim((string)$url));
    }

    private function getDataArray($data) {
        if (!$data) return [];
        if (is_array($data) && $this->isList($data)) return $data;
        foreach (['items','list','data','rows','records','matches'] as $k) {
            if (isset($data[$k]) && is_array($data[$k]) && $this->isList($data[$k])) {
                return $data[$k];
            }
        }
        if (isset($data['data']) && is_array($data['data'])) return $data['data'];
        return [];
    }

    // PHP 8.0 兼容
    private function isList($arr) {
        if (!is_array($arr)) return false;
        $i = 0;
        foreach ($arr as $k => $_) {
            if ($k !== $i++) return false;
        }
        return true;
    }

    // ======================================================
    //  请求
    // ======================================================
    private function getJson($url, $params = [], $referer = '') {
        $q = http_build_query($params);
        $final = $q ? $url . (strpos($url, '?') !== false ? '&' : '?') . $q : $url;

        $key = 'GET:' . $final;
        if (isset(self::$cache[$key])) return self::$cache[$key];

        $h = $this->apiHeaders();
        if ($referer) $h['Referer'] = $referer;
        $txt = $this->fetch($final, [], $h) ?: '';
        if (!$txt) return null;
        $j = json_decode($txt, true);
        $res = is_array($j) ? $j : null;
        self::$cache[$key] = $res;
        return $res;
    }

    // ★ 关键：POST JSON，cURL 实现
    private function postJson($url, $body, $referer = '') {
        $key = 'POST:' . $url . ':' . md5(json_encode($body));
        if (isset(self::$cache[$key])) return self::$cache[$key];

        $h = $this->apiHeaders();
        $h['Content-Type'] = 'application/json';
        if ($referer) $h['Referer'] = $referer;

        $headers = [];
        foreach ($h as $k => $v) $headers[] = "$k: $v";

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body),
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER     => $headers,
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        $out = $res ?: '';
        self::$cache[$key] = $out;
        return $out;
    }

    // ======================================================
    //  时间（UTC+8）
    // ======================================================
    private function formatTime($raw) {
        $s = trim((string)$raw);
        if ($s === '') return '';
        $ts = strtotime($s);
        if ($ts === false) {
            if (preg_match('/(\d{4})-(\d{2})-(\d{2})[T ]?(\d{2}):(\d{2})/', $s, $m)) {
                return "{$m[2]}-{$m[3]} {$m[4]}:{$m[5]}";
            }
            return '';
        }
        return gmdate('m-d H:i', $ts + 8 * 3600);
    }

    private function statusText($key) {
        $k = strtolower(trim((string)$key));
        if (in_array($k, ['live','in_progress','playing','1'], true)) return '进行中';
        if (in_array($k, ['finished','ended'], true)) return '已结束';
        if (in_array($k, ['upcoming','pending','not_started','notstarted','scheduled','0'], true)) return '未开始';
        return $k === 'undefined' ? '' : $k;
    }

    private function buildRemarks($status, $startTime) {
        $st = $this->statusText($status);
        $tm = $this->formatTime($startTime);
        if ($st && $tm) return "$st $tm";
        return $st ?: ($tm ?: '');
    }

    private function isLiveVod($v) {
        $r = (string)($v['vod_remarks'] ?? '');
        return strpos($r, '进行中') === 0;
    }

    private function isHotItem($item) {
        if (!is_array($item)) return false;
        if (($item['is_hot'] ?? 0) == 1) return true;
        $c = $item['competition'] ?? null;
        if (is_array($c) && ($c['is_hot'] ?? 0) == 1) return true;
        return false;
    }

    private function videoTypeText($key) {
        $k = strtolower(trim((string)$key));
        if ($k === 'full_match' || $k === 'full') return '全场回放';
        if ($k === 'highlight') return '集锦';
        return $k !== '' ? $k : '回放';
    }

    // ======================================================
    //  id 编解码
    // ======================================================
    private function encodeLiveId($obj) {
        return 'live|' . rawurlencode(json_encode($obj, JSON_UNESCAPED_UNICODE));
    }
    private function decodeLiveId($id) {
        $raw = trim((string)$id);
        if (strpos($raw, 'live|') !== 0) return null;
        $j = json_decode(rawurldecode(substr($raw, 5)), true);
        return is_array($j) ? $j : null;
    }
    private function encodeVideoId($obj) {
        return 'video|' . rawurlencode(json_encode($obj, JSON_UNESCAPED_UNICODE));
    }
    private function decodeVideoId($id) {
        $raw = trim((string)$id);
        if (strpos($raw, 'video|') !== 0) return null;
        $j = json_decode(rawurldecode(substr($raw, 6)), true);
        return is_array($j) ? $j : null;
    }

    // ======================================================
    //  比赛列表
    // ======================================================
    private function matchToVod($item) {
        $id = trim((string)($item['id'] ?? $item['match_id'] ?? $item['matchId'] ?? ''));
        if ($id === '') return null;

        $home = $item['home_team'] ?? [];
        $away = $item['away_team'] ?? [];
        $comp = $item['competition'] ?? [];
        $hn = trim((string)($home['name'] ?? ''));
        $an = trim((string)($away['name'] ?? ''));
        $cn = trim((string)($comp['name'] ?? ''));

        $hs = $item['home_score'] ?? null;
        $as = $item['away_score'] ?? null;
        $hasScore = $hs !== null && $as !== null;

        $score = $hasScore ? " {$hs}-{$as}" : '';
        $name = $cn ? "{$cn} {$hn} vs {$an}{$score}" : "{$hn} vs {$an}{$score}";

        $pic = trim((string)($home['logo'] ?? '')) ?: ($this->host . '/og-image.png');
        $st = trim((string)($item['start_time'] ?? $item['startTime'] ?? ''));

        return [
            'vod_id'      => $this->encodeLiveId([
                'id'=>$id,'h'=>$hn,'a'=>$an,'l'=>$cn,
                's'=>$item['status'] ?? '','hs'=>$hs,'as'=>$as,'t'=>$st,
            ]),
            'vod_name'    => $name,
            'vod_pic'     => $pic,
            'vod_remarks' => $this->buildRemarks($item['status'] ?? '', $st),
        ];
    }

    private function fetchMatches($status = '', $cat = '', $hotOnly = false) {
        $params = ['page'=>1,'per_page'=>60];
        if ($status !== '') $params['status'] = $status;
        if ($cat !== '')    $params['category_id'] = $cat;

        $data = $this->getJson($this->host . '/api/matches', $params, $this->host . '/');
        $arr = $this->getDataArray($data);

        $list = [];
        foreach ($arr as $item) {
            if ($hotOnly && !$this->isHotItem($item)) continue;
            $v = $this->matchToVod($item);
            if ($v) $list[] = $v;
        }
        return $list;
    }

    // ======================================================
    //  录像（全量 7.8MB，切片）
    // ======================================================
    private function fetchVideos($cat = '', $hotOnly = false, $max = 30) {
        $data = $this->getJson($this->host . '/api/videos', [], $this->host . '/videos');
        $arr = is_array($data) && $this->isList($data) ? $data : $this->getDataArray($data);
        if (!$arr) return [];

        usort($arr, function($a, $b) {
            $ta = (string)($a['updated_at'] ?? $a['updatedAt'] ?? '');
            $tb = (string)($b['updated_at'] ?? $b['updatedAt'] ?? '');
            if ($ta === '' || $tb === '') return 0;
            return strcmp($tb, $ta);
        });

        $list = [];
        foreach ($arr as $item) {
            if (count($list) >= $max) break;
            $m = $item['match'] ?? [];
            if ($cat !== '') {
                $cid = (string)($m['category_id'] ?? $m['categoryId'] ?? '');
                if ($cid !== '' && $cid !== $cat) continue;
            }
            if ($hotOnly && !$this->isHotItem($m) && !$this->isHotItem($item)) continue;
            $v = $this->videoToVod($item);
            if ($v) $list[] = $v;
        }
        return $list;
    }

    private function videoToVod($item) {
        if (!is_array($item)) return null;
        $srcs = is_array($item['sources'] ?? null) ? $item['sources'] : [];
        $usable = [];
        foreach ($srcs as $i => $s) {
            if (!is_array($s)) continue;
            $sid = trim((string)($s['source_id'] ?? $s['sourceId'] ?? $s['id'] ?? ''));
            if ($sid === '') continue;
            $stt = strtolower(trim((string)($s['status'] ?? '')));
            if ($stt === 'disabled' || $stt === 'hidden') continue;
            $name = trim((string)($s['quality'] ?? $s['display_name'] ?? $s['name'] ?? '')) ?: ('线路' . ($i + 1));
            $usable[] = ['sourceId' => $sid, 'name' => $name];
        }
        if (!$usable) return null;

        $vst = strtolower(trim((string)($item['status'] ?? '')));
        if ($vst !== '' && $vst !== 'playable') return null;

        $m = $item['match'] ?? [];
        $home = $m['home_team'] ?? [];
        $away = $m['away_team'] ?? [];
        $comp = $m['competition'] ?? [];
        $cn = trim((string)($comp['name'] ?? ''));
        $title = trim((string)($item['title'] ?? ''));
        $vt = $this->videoTypeText($item['type'] ?? '');

        $name = $title;
        if ($name === '') {
            $hn = trim((string)($home['name'] ?? ''));
            $an = trim((string)($away['name'] ?? ''));
            $name = $cn ? "{$cn} {$hn} vs {$an}" : "{$hn} vs {$an}";
        }
        if ($cn !== '' && strpos($name, $cn) !== 0) $name = "{$cn} {$name}";

        $thumb = trim((string)($item['thumbnail'] ?? $item['cover'] ?? $item['poster'] ?? ''));
        $pic = $thumb ?: (trim((string)($home['logo'] ?? '')) ?: ($this->host . '/og-image.png'));
        $st = $this->formatTime($m['start_time'] ?? $m['startTime'] ?? '');

        return [
            'vod_id'      => $this->encodeVideoId([
                'id'=>(string)($item['id'] ?? ''),'mid'=>(string)($m['id'] ?? ''),
                'title'=>$name,'pic'=>$pic,'l'=>$cn,'vt'=>$vt,'t'=>$st,'srcs'=>$usable,
            ]),
            'vod_name'    => $name,
            'vod_pic'     => $pic,
            'vod_remarks' => ($vt ? $vt . ' ' : '') . $st,
        ];
    }

    // ======================================================
    //  线路
    // ======================================================
    private function fetchSignals($matchId) {
        $data = $this->getJson(
            $this->host . '/api/matches/' . urlencode($matchId) . '/signals',
            [], "{$this->host}/match/{$matchId}"
        );
        $arr = is_array($data) && $this->isList($data) ? $data : $this->getDataArray($data);
        $lines = [];
        foreach ($arr as $i => $s) {
            if (!is_array($s)) continue;
            $sid = trim((string)($s['source_id'] ?? $s['sourceId'] ?? $s['id'] ?? ''));
            if ($sid === '') continue;
            $st = strtolower(trim((string)($s['status'] ?? '')));
            if ($st === 'disabled' || $st === 'hidden') continue;
            $dn = trim((string)($s['display_name'] ?? $s['displayName'] ?? $s['name'] ?? '')) ?: ('线路' . ($i + 1));
            $lines[] = ['name' => $dn, 'sourceId' => $sid];
        }
        return $lines;
    }

    // ======================================================
    //  m3u8 提取
    // ======================================================
    private function normalizeM3u8($u) {
        return str_replace(
            ['&amp;amp;', '&amp;', '\\u002F', '\\/'],
            ['&', '&', '/', '/'],
            trim((string)$u)
        );
    }

    private function pickUrl($resp) {
        if (!$resp) return '';
        $j = json_decode($resp, true);
        if (is_array($j)) {
            foreach (['url','play_url','playUrl','m3u8','hls','stream','live_url','liveUrl','src','source','file'] as $k) {
                $v = $j[$k] ?? '';
                if ($v && strpos((string)$v, 'm3u8') !== false) return trim((string)$v);
            }
            if (isset($j['data']) && is_array($j['data'])) {
                $r = $this->pickUrl(json_encode($j['data']));
                if ($r) return $r;
            }
        }
        if (preg_match('/(https?:[^"\'\s\\\\]*?\.m3u8[^"\'\s\\\\]*)/', (string)$resp, $m)) {
            return $m[1];
        }
        return '';
    }

    private function requestFromHtml($matchId) {
        if (!$matchId) return '';
        $html = $this->fetch(
            "{$this->host}/match/" . urlencode($matchId),
            [], array_merge($this->apiHeaders(), ['Referer' => "{$this->host}/match/{$matchId}"])
        ) ?: '';
        if (!$html) return '';

        if (preg_match('/<video[^>]+src=["\']([^"\']+\.m3u8[^"\']*)["\']/i', $html, $m)) {
            return $this->normalizeM3u8($m[1]);
        }
        if (preg_match('/liveUrl=([^"\'&]+)/i', $html, $m)) {
            $dec = urldecode($m[1]);
            if (strpos($dec, '.m3u8') !== false) return $this->normalizeM3u8($dec);
        }
        if (preg_match('/(https?:[^"\'\s\\\\]*?\.m3u8[^"\'\s\\\\]*)/', $html, $m)) {
            return $this->normalizeM3u8($m[1]);
        }
        return '';
    }

    private function requestSession($sourceId, $matchId) {
        $resp = $this->postJson(
            "{$this->host}/api/play/session",
            ['source_id' => $sourceId],
            "{$this->host}/match/{$matchId}"
        );
        $u = $this->pickUrl($resp);
        return $u ? $this->normalizeM3u8($u) : '';
    }

    private function requestReplaySession($videoSourceId) {
        $resp = $this->postJson(
            "{$this->host}/api/play/replay-session",
            ['video_source_id' => $videoSourceId],
            "{$this->host}/videos"
        );
        $u = $this->pickUrl($resp);
        return $u ? $this->normalizeM3u8($u) : '';
    }

    private function requestFailover($matchId, $currentSourceId) {
        $resp = $this->postJson(
            "{$this->host}/api/play/failover",
            ['match_id' => $matchId, 'current_source_id' => $currentSourceId],
            "{$this->host}/match/{$matchId}"
        );
        $u = $this->pickUrl($resp);
        return $u ? $this->normalizeM3u8($u) : '';
    }

    private function normalizeType($tid) {
        $t = trim((string)$tid);
        if ($t === 'live')       return ['status'=>'live','cat'=>'','hot'=>false,'video'=>false];
        if ($t === 'hot')        return ['status'=>'','cat'=>'','hot'=>true,'video'=>false];
        if ($t === 'video')      return ['status'=>'','cat'=>'','hot'=>false,'video'=>true];
        if ($t === 'basketball') return ['status'=>'','cat'=>'2','hot'=>false,'video'=>false];
        if ($t === 'football')   return ['status'=>'','cat'=>'1','hot'=>false,'video'=>false];
        return ['status'=>'','cat'=>'','hot'=>false,'video'=>false];
    }

    // ======================================================
    //  Spider 入口
    // ======================================================
    public function init($extend = '') { return true; }

    public function homeContent($filter) {
        return [
            'class' => [
                ['type_id'=>'live','type_name'=>'进行中'],
                ['type_id'=>'hot','type_name'=>'热门'],
                ['type_id'=>'all','type_name'=>'全部'],
                ['type_id'=>'basketball','type_name'=>'篮球'],
                ['type_id'=>'football','type_name'=>'足球'],
                ['type_id'=>'video','type_name'=>'录像'],
            ],
            'filters' => (object)[],
        ];
    }

    public function homeVideoContent() {
        return ['list' => $this->fetchMatches('live', '')];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        try {
            $t = $this->normalizeType($tid);
            if ($t['status'] === 'live') {
                $list = $this->fetchMatches('live', '');
            } elseif ($t['video']) {
                $list = $this->fetchVideos('', false, 30);
            } elseif ($t['hot']) {
                $bk = $this->fetchMatches('', '2', true);
                $fb = $this->fetchMatches('', '1', true);
                $liveB = array_values(array_filter($bk, fn($v)=>$this->isLiveVod($v)));
                $liveF = array_values(array_filter($fb, fn($v)=>$this->isLiveVod($v)));
                $list = array_merge($liveB, $liveF, $bk, $fb);
            } elseif ($t['cat'] !== '') {
                $bk = $this->fetchMatches('', $t['cat']);
                $live = array_values(array_filter($bk, fn($v)=>$this->isLiveVod($v)));
                $list = array_merge($live, $bk);
            } else {
                $bk = $this->fetchMatches('', '2');
                $fb = $this->fetchMatches('', '1');
                $liveB = array_values(array_filter($bk, fn($v)=>$this->isLiveVod($v)));
                $liveF = array_values(array_filter($fb, fn($v)=>$this->isLiveVod($v)));
                $list = array_merge($liveB, $liveF, $bk, $fb);
            }
            return $this->pageResult($list, max(1,intval($pg)), 1, count($list));
        } catch (\Throwable $e) {
            return $this->pageResult([], max(1,intval($pg)), 1, 0);
        }
    }

    public function detailContent($ids) {
        $id = is_array($ids) ? ($ids[0] ?? '') : $ids;
        try {
            // 录像分支
            $vinfo = $this->decodeVideoId($id);
            if ($vinfo) {
                $vTitle = (string)($vinfo['title'] ?? '');
                $vPic = (string)($vinfo['pic'] ?? '') ?: ($this->host . '/og-image.png');
                $vt = (string)($vinfo['vt'] ?? '');
                $vl = (string)($vinfo['l'] ?? '');
                $vtm = (string)($vinfo['t'] ?? '');
                $srcs = is_array($vinfo['srcs'] ?? null) ? $vinfo['srcs'] : [];
                $eps = [];
                foreach ($srcs as $i => $s) {
                    $playId = "{$id}|" . (string)($s['sourceId'] ?? '');
                    $eps[] = $this->cleanName($s['name'] ?? ('线路' . ($i + 1))) . '$' . $this->cleanPlayUrl($playId);
                }
                return ['list' => [[
                    'vod_id' => $id, 'vod_name' => $vTitle, 'vod_pic' => $vPic,
                    'type_name' => $vl ?: '录像',
                    'vod_year' => date('Y'), 'vod_area' => '国际',
                    'vod_actor' => $vt, 'vod_remarks' => $vt,
                    'vod_content' => "{$vl}\n{$vTitle}\n类型：{$vt}\n比赛时间：{$vtm}",
                    'vod_play_from' => '球吧录像',
                    'vod_play_url' => $eps ? implode('#', $eps) : '',
                ]]];
            }

            // 直播分支
            $info = $this->decodeLiveId($id) ?: [];
            $matchId = (string)($info['id'] ?? '');
            if ($matchId === '') return ['list' => []];

            $hn = (string)($info['h'] ?? '');
            $an = (string)($info['a'] ?? '');
            $cn = (string)($info['l'] ?? '');
            $st = $this->statusText($info['s'] ?? '');
            $hs = $info['hs'] ?? '';
            $as = $info['as'] ?? '';
            $tm = $this->formatTime($info['t'] ?? '');

            $vodName = $cn ? "{$cn} {$hn} vs {$an} {$hs}-{$as}" : "{$hn} vs {$an} {$hs}-{$as}";

            $lines = $this->fetchSignals($matchId);
            if (!$lines) $lines = [['name'=>'默认','sourceId'=>'']];

            $eps = [];
            foreach ($lines as $ln) {
                $playId = "{$matchId}|{$ln['sourceId']}";
                $eps[] = $this->cleanName($ln['name']) . '$' . $this->cleanPlayUrl($playId);
            }

            return ['list' => [[
                'vod_id' => $id, 'vod_name' => $vodName,
                'vod_pic' => $this->host . '/og-image.png',
                'type_name' => $cn ?: '体育直播',
                'vod_year' => date('Y'), 'vod_area' => '国际',
                'vod_actor' => "{$hn} / {$an}",
                'vod_remarks' => $st ? ($tm ? "$st $tm" : $st) : $tm,
                'vod_content' => "{$cn}\n{$hn} vs {$an}\n状态：{$st}\n开赛：{$tm}",
                'vod_play_from' => '球吧',
                'vod_play_url' => implode('#', $eps),
            ]]];
        } catch (\Throwable $e) {
            return ['list' => []];
        }
    }

    // 优化：search 只搜 matches，不再拉 7.8MB videos
    public function searchContent($key, $quick = false, $pg = 1) {
        $k = trim((string)$key);
        if ($k === '') return ['list' => []];
        try {
            $bk = $this->fetchMatches('', '2');
            $fb = $this->fetchMatches('', '1');
            $all = array_merge($bk, $fb);
            $list = array_values(array_filter($all, fn($v) => strpos((string)($v['vod_name'] ?? ''), $k) !== false));
            if ($quick) $list = array_slice($list, 0, 1);
            return ['list' => $list];
        } catch (\Throwable $e) {
            return ['list' => []];
        }
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        $raw = str_replace('***', '#', trim((string)$id));
        try {
            // 录像
            if (strpos($raw, 'video|') === 0) {
                $lastSep = strrpos($raw, '|');
                $vsid = $lastSep > 0 ? substr($raw, $lastSep + 1) : '';
                if ($vsid !== '') {
                    $u = $this->requestReplaySession($vsid);
                    if ($u) return ['parse'=>0, 'url'=>$u, 'header'=>$this->streamHeaders()];
                }
                $vinfo = $this->decodeVideoId(substr($raw, 0, $lastSep));
                $srcs = is_array($vinfo['srcs'] ?? null) ? $vinfo['srcs'] : [];
                foreach ($srcs as $s) {
                    $u2 = $this->requestReplaySession((string)($s['sourceId'] ?? ''));
                    if ($u2) return ['parse'=>0, 'url'=>$u2, 'header'=>$this->streamHeaders()];
                }
                return ['parse'=>0, 'url'=>''];
            }

            // 直播
            $matchId = $raw; $sourceId = '';
            $sep = strpos($raw, '|');
            if ($sep > 0) { $matchId = substr($raw, 0, $sep); $sourceId = substr($raw, $sep + 1); }

            $direct = $this->requestFromHtml($matchId);
            if ($direct) return ['parse'=>0, 'url'=>$direct, 'header'=>$this->streamHeaders()];

            if ($sourceId !== '') {
                $u = $this->requestSession($sourceId, $matchId);
                if ($u) return ['parse'=>0, 'url'=>$u, 'header'=>$this->streamHeaders()];
                $u = $this->requestFailover($matchId, $sourceId);
                if ($u) return ['parse'=>0, 'url'=>$u, 'header'=>$this->streamHeaders()];
            }

            $lines = $this->fetchSignals($matchId);
            foreach ($lines as $ln) {
                $u = $this->requestSession($ln['sourceId'], $matchId);
                if ($u) return ['parse'=>0, 'url'=>$u, 'header'=>$this->streamHeaders()];
            }

            return ['parse'=>1, 'url'=>"{$this->host}/match/{$matchId}", 'header'=>$this->streamHeaders()];
        } catch (\Throwable $e) {
            return ['parse'=>0, 'url'=>$raw];
        }
    }
}

(new Spider())->run();