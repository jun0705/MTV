<?php
/**
 * 专属全网聚合 - 影视仓 PHP 版 (注释精简版)
 * 基于 curl_multi 实现高并发多源聚合
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    protected $sources = [
        's1'  => ['name' => '🎬电影天堂', 'api' => 'http://caiji.dyttzyapi.com/api.php/provide/vod/from/dyttm3u8/at/json'],
        's2'  => ['name' => '💧无水印', 'api' => 'https://api.wsyzy.net/api.php/provide/vod'],
        's3'  => ['name' => '🧸量子', 'api' => 'https://cj.lziapi.com/api.php/provide/vod'],
        // 's4'  => ['name' => '📺1080资源', 'api' => 'https://api.1080zyku.com/inc/api_mac10.php'], // 已去掉
        // 's5'  => ['name' => '🔥155资源', 'api' => 'https://155api.com/api.php/provide/vod'], // 已去掉
        's6'  => ['name' => '📺天涯', 'api' => 'https://tyyszy.com/api.php/provide/vod'],
        's7'  => ['name' => '📺暴风', 'api' => 'https://bfzyapi.com/api.php/provide/vod'],
        's8'  => ['name' => '⚡索尼闪电', 'api' => 'https://xsd.sdzyapi.com/api.php/provide/vod'],
        's9'  => ['name' => '📺索尼', 'api' => 'https://suoniapi.com/api.php/provide/vod'],
        // 's10' => ['name' => '📺红牛', 'api' => 'https://www.hongniuzy2.com/api.php/provide/vod'], // 已去掉
        's11' => ['name' => '📺茅台', 'api' => 'https://caiji.maotaizy.cc/api.php/provide/vod'], // 保留
        's12' => ['name' => '🐯虎牙', 'api' => 'https://www.huyaapi.com/api.php/provide/vod'],
        // 's13' => ['name' => '📺豆瓣', 'api' => 'https://caiji.dbzy.tv/api.php/provide/vod'], // 已去掉
        // 's14' => ['name' => '📺豆瓣2', 'api' => 'https://dbzy.tv/api.php/provide/vod'], // 已去掉
        's15' => ['name' => '📺豪华', 'api' => 'https://hhzyapi.com/api.php/provide/vod'],
        // 's16' => ['name' => '📺CK资源', 'api' => 'https://ckzy.me/api.php/provide/vod'], // 已去掉
        // 's17' => ['name' => '📺U酷', 'api' => 'https://api.ukuapi.com/api.php/provide/vod'], // 已去掉
        // 's18' => ['name' => '📺ikun', 'api' => 'https://ikunzyapi.com/api.php/provide/vod'], // 已去掉
        's19' => ['name' => '📺无尽', 'api' => 'https://api.wujinapi.cc/api.php/provide/vod'],
        's20' => ['name' => '🌕光速', 'api' => 'https://api.guangsuapi.com/api.php/provide/vod'],
       // 's21' => ['name' => '📺卧龙', 'api' => 'https://collect.wolongzyw.com/api.php/provide/vod'],
        's22' => ['name' => '📺新浪', 'api' => 'https://api.xinlangapi.com/xinlangapi.php/provide/vod'],
        // 's23' => ['name' => '📺旺旺', 'api' => 'https://api.wwzy.tv/api.php/provide/vod'], // 已去掉
        's24' => ['name' => '📺最大', 'api' => 'https://api.zuidapi.com/api.php/provide/vod'],
        // 's25' => ['name' => '🌸樱花', 'api' => 'https://m3u8.apiyhzy.com/api.php/provide/vod'], // 已去掉
        's26' => ['name' => '🐮牛牛', 'api' => 'https://api.niuniuzy.me/api.php/provide/vod'],
        's27' => ['name' => '☁️百度云', 'api' => 'https://api.apibdzy.com/api.php/provide/vod'],
        's28' => ['name' => '🏎速播', 'api' => 'https://subocaiji.com/api.php/provide/vod'],
        // 's29' => ['name' => '🦅金鹰', 'api' => 'https://jinyingzy.com/api.php/provide/vod'], // 已去掉
        's30' => ['name' => '⚡闪电', 'api' => 'https://sdzyapi.com/api.php/provide/vod'],
        's31' => ['name' => '👑非凡', 'api' => 'https://cj.ffzyapi.com/api.php/provide/vod'],
        's32' => ['name' => '🍃飘零', 'api' => 'https://p2100.net/api.php/provide/vod'],
       // 's33' => ['name' => '🐾魔爪', 'api' => 'https://mozhuazy.com/api.php/provide/vod'],
        's34' => ['name' => '📺魔都', 'api' => 'https://www.mdzyapi.com/api.php/provide/vod']
    ];

    public function init($extend = '') {}

    // 并发请求辅助方法
    protected function multiGet($urls, $timeout = 8) {
        $mh = curl_multi_init();
        $handles = [];
        $results = [];

        foreach ($urls as $key => $url) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_ENCODING => 'gzip, deflate',
                CURLOPT_HTTPHEADER => [
                    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                ]
            ]);
            curl_multi_add_handle($mh, $ch);
            $handles[$key] = $ch;
        }

        $active = null;
        do {
            $mrc = curl_multi_exec($mh, $active);
        } while ($mrc == CURLM_CALL_MULTI_PERFORM);

        while ($active && $mrc == CURLM_OK) {
            if (curl_multi_select($mh) != -1) {
                do {
                    $mrc = curl_multi_exec($mh, $active);
                } while ($mrc == CURLM_CALL_MULTI_PERFORM);
            }
        }

        foreach ($handles as $key => $ch) {
            $results[$key] = curl_multi_getcontent($ch);
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
        }
        curl_multi_close($mh);

        return $results;
    }

    protected function getHtml($url, $timeout = 8) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => [
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            ]
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function cleanItem($item, $sourceKey, $sourceName, $isDetail = false) {
        if (!$isDetail) {
            $item['vod_id'] = "{$sourceKey}@@{$item['vod_id']}";
        }

        $remarks = $item['vod_remarks'] ?? '';
        $item['vod_remarks'] = "{$sourceName} | {$remarks}";

        if (!empty($item['vod_play_from'])) {
            $froms = explode('$$$', $item['vod_play_from']);
            $newFroms = [];
            foreach ($froms as $x) {
                $newFroms[] = "{$sourceName}-{$x}";
            }
            $item['vod_play_from'] = implode('$$$', $newFroms);
        }

        unset($item['vod_down_from']);
        unset($item['vod_down_url']);

        return $item;
    }

    public function homeContent($filter) {
        $classes = [];
        $filters = [];
        $urls = [];

        foreach ($this->sources as $key => $source) {
            $classes[] = [
                'type_id' => $key,
                'type_name' => $source['name']
            ];
            $urls[$key] = $source['api'] . '?ac=list';
        }

        $responses = $this->multiGet($urls, 4);

        foreach ($responses as $key => $html) {
            $vals = [['n' => '全部(最新)', 'v' => '']];
            $data = json_decode($html ?: '{}', true);
            if (!empty($data['class'])) {
                foreach ($data['class'] as $c) {
                    $vals[] = [
                        'n' => $c['type_name'] ?? '',
                        'v' => $c['type_id'] ?? ''
                    ];
                }
            }
            $filters[$key] = [
                [
                    'key' => 'cateId',
                    'name' => '分类',
                    'value' => $vals
                ]
            ];
        }

        $this->outputJson([
            'class' => $classes,
            'filters' => (object)$filters,
            'list' => []
        ]);
    }

    public function homeVideoContent() {
        $this->outputJson(['list' => []]);
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        if (!isset($this->sources[$tid])) {
            $this->outputJson(['list' => []]);
        }

        $source = $this->sources[$tid];
        $cateId = $extend['cateId'] ?? '';

        $url = "{$source['api']}?ac=detail&pg={$pg}";
        if ($cateId) $url .= "&t={$cateId}";

        $html = $this->getHtml($url);
        $data = json_decode($html ?: '{}', true);

        $result = [];
        if (!empty($data['list'])) {
            foreach ($data['list'] as $item) {
                $result[] = $this->cleanItem($item, $tid, $source['name'], false);
            }
        }

        $this->outputJson([
            'list' => $result,
            'page' => $data['page'] ?? intval($pg),
            'pagecount' => $data['pagecount'] ?? 1,
            'limit' => $data['limit'] ?? 20,
            'total' => $data['total'] ?? count($result)
        ]);
    }

    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        if (strpos($id, '@@') === false) {
            $this->outputJson(['list' => []]);
        }

        list($sourceKey, $realId) = explode('@@', $id, 2);
        if (!isset($this->sources[$sourceKey])) {
            $this->outputJson(['list' => []]);
        }

        $source = $this->sources[$sourceKey];
        $url = "{$source['api']}?ac=detail&ids={$realId}";
        
        $html = $this->getHtml($url);
        $data = json_decode($html ?: '{}', true);

        $result = [];
        if (!empty($data['list'])) {
            foreach ($data['list'] as $item) {
                $cleaned = $this->cleanItem($item, $sourceKey, $source['name'], true);
                $cleaned['vod_id'] = $id;
                $result[] = $cleaned;
            }
        }

        $this->outputJson(['list' => $result]);
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $urls = [];
        foreach ($this->sources as $sourceKey => $source) {
            $urls[$sourceKey] = "{$source['api']}?ac=detail&wd=" . urlencode($key) . "&pg={$pg}";
        }

        $responses = $this->multiGet($urls, 6);
        $result = [];
        $maxPage = 1;

        foreach ($responses as $sourceKey => $html) {
            $source = $this->sources[$sourceKey];
            $data = json_decode($html ?: '{}', true);

            if (!empty($data['list'])) {
                foreach ($data['list'] as $item) {
                    $result[] = $this->cleanItem($item, $sourceKey, $source['name'], false);
                }
            }
            if (!empty($data['pagecount']) && $data['pagecount'] > $maxPage) {
                $maxPage = $data['pagecount'];
            }
        }

        $this->outputJson([
            'list' => $result,
            'page' => intval($pg),
            'pagecount' => $maxPage,
            'limit' => 40,
            'total' => 9999
        ]);
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        $this->outputJson([
            'parse' => 0,
            'playUrl' => '',
            'url' => $id,
            'header' => (object)[
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            ]
        ]);
    }

    public function localProxy($param) {
        return [200, 'text/plain', 'ok'];
    }
    
    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }
}

(new Spider())->run();