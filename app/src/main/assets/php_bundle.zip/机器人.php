<?php
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    private $SITE = 'https://www1.ikanbot.com';
    private $UA   = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

    private $cateManual = [
        '电影' => 'movie',
        '剧集' => 'tv',
        '动漫' => '18',
        '综艺' => '19',
    ];

    public function __construct() {
        parent::__construct();
    }

    // ============================================================
    // 工具
    // ============================================================
    private function reqHeaders() {
        return [
            'User-Agent'      => $this->UA,
            'Referer'         => $this->SITE . '/',
            'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language' => 'zh-CN,zh;q=0.9',
        ];
    }

    private function fetchHtml($url, $headers = null) {
        try {
            $res = $this->fetch($url, [], $headers ?: $this->reqHeaders());
            return $res ?: '';
        } catch (Exception $e) {
            return '';
        }
    }

    private function getVid($url) {
        if (!$url) return '';
        if (preg_match('#/play/(\d+)#', $url, $m)) return $m[1];
        return '';
    }

    // ============================================================
    // 列表解析
    // ============================================================
    private function extractVodList($html) {
        $result = [];
        $seen   = [];
        if (!$html) return $result;

        // 方式1：<a class="...item..." href="/play/xxx">...<p>标题</p>...</a>
        preg_match_all('/<a\b([^>]*)>([\s\S]*?)<\/a>/i', $html, $anchors, PREG_SET_ORDER);
        foreach ($anchors as $a) {
            $attrs = $a[1];
            $inner = $a[2];

            if (!preg_match('/class="[^"]*\bitem\b[^"]*"/i', $attrs)) continue;
            if (!preg_match('/href="([^"]*\/play\/\d+[^"]*)"/i', $attrs, $hm)) continue;

            $vid = $this->getVid($hm[1]);
            if (!$vid || isset($seen[$vid])) continue;
            $seen[$vid] = true;

            $title = '';
            if (preg_match('/<p[^>]*>([^<]+)<\/p>/i', $inner, $tm)) {
                $title = trim($tm[1]);
            }
            if (!$title && preg_match('/class="[^"]*title[^"]*"[^>]*>([^<]+)</i', $inner, $tm)) {
                $title = trim($tm[1]);
            }
            if (!$title && preg_match('/<img[^>]*alt="([^"]*)"/i', $inner, $tm)) {
                $title = trim($tm[1]);
            }

            $pic = '';
            if (preg_match('/<img[^>]*data-(?:src|original)="([^"]+)"/i', $inner, $pm)) {
                $pic = $pm[1];
            } elseif (preg_match('/<img[^>]*\bsrc="(https?:\/\/[^"]+)"/i', $inner, $pm)) {
                $pic = $pm[1];
            }
            if (strpos($pic, 'data:image/svg') !== false) $pic = '';

            if ($title) $result[] = ['vid' => $vid, 'title' => $title, 'pic' => $pic];
        }

        // 方式2：搜索页 .media 卡片
        if (empty($result)) {
            preg_match_all('/<div[^>]*class="media"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/', $html, $medias);
            foreach ($medias[1] as $card) {
                if (!preg_match('/href="([^"]*\/play\/\d+[^"]*)"/', $card, $hm)) continue;
                $vid = $this->getVid($hm[1]);
                if (!$vid || isset($seen[$vid])) continue;
                $seen[$vid] = true;

                $title = '';
                if (preg_match('/class="media-body"[^>]*>[\s\S]*?<a[^>]*>([^<]+)<\/a>/', $card, $tm)) {
                    $title = trim($tm[1]);
                }
                $pic = '';
                if (preg_match('/data-original="([^"]+)"/', $card, $pm)) $pic = $pm[1];
                if (strpos($pic, 'data:image/svg') !== false) $pic = '';

                if ($title) $result[] = ['vid' => $vid, 'title' => $title, 'pic' => $pic];
            }
        }

        // 方式3：兜底
        if (empty($result)) {
            preg_match_all('/<a[^>]*href="([^"]*\/play\/(\d+)[^"]*)"[^>]*>([^<]+)<\/a>/', $html, $matches, PREG_SET_ORDER);
            foreach ($matches as $m) {
                $vid   = $m[2];
                $title = trim($m[3]);
                if (isset($seen[$vid]) || !$title || mb_strlen($title) > 50) continue;
                $seen[$vid] = true;
                $result[] = ['vid' => $vid, 'title' => $title, 'pic' => ''];
            }
        }

        return $result;
    }

    private function toVod($items) {
        $list = [];
        foreach ($items as $it) {
            $list[] = [
                'vod_id'      => $it['vid'],
                'vod_name'    => $it['title'],
                'vod_pic'     => $it['pic'],
                'vod_remarks' => ''
            ];
        }
        return $list;
    }

    // ============================================================
    // 首页
    // ============================================================
    public function homeContent($filter) {
        $classes = [];
        foreach ($this->cateManual as $k => $v) {
            $classes[] = ['type_id' => (string)$v, 'type_name' => $k];
        }
        return ['class' => $classes];
    }

    public function homeVideoContent() {
        $html = $this->fetchHtml($this->SITE);
        return ['list' => $this->toVod($this->extractVodList($html))];
    }

    // ============================================================
    // 分类
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        $hot  = '%E7%83%AD%E9%97%A8';

        if ($tid === 'movie' || $tid === 'tv') {
            $url = $page == 1
                ? "{$this->SITE}/hot/index-{$tid}-{$hot}.html"
                : "{$this->SITE}/hot/index-{$tid}-{$hot}-p-{$page}.html";
        } else {
            $url = $page == 1
                ? "{$this->SITE}/category/{$tid}"
                : "{$this->SITE}/category/{$tid}?p={$page}";
        }

        $list = $this->toVod($this->extractVodList($this->fetchHtml($url)));
        return $this->pageResult($list, $page, 0, 24);
    }

    // ============================================================
    // 详情：token + /api/getResN
    // ============================================================
    public function detailContent($ids) {
        $vid = is_array($ids) ? ($ids[0] ?? '') : $ids;
        if (!$vid) return ['list' => []];

        $html = $this->fetchHtml("{$this->SITE}/play/{$vid}");
        if (!$html) return ['list' => []];

        // ---------- 标题 ----------
        $title = '';
        if (preg_match('/<h1[^>]*id="video_title"[^>]*>([\s\S]*?)<\/h1>/i', $html, $m)) {
            $title = trim(strip_tags($m[1]));
        }
        if (!$title && preg_match('/<title>([^<]+)<\/title>/i', $html, $m)) {
            $title = preg_replace('/\s*[-–—].*$/u', '', trim($m[1]));
            $title = trim($title);
        }

        // ---------- 封面 ----------
        $pic = '';
        if (preg_match('/<img[^>]*id="' . preg_quote($vid, '/') . '"[^>]*data-src="([^"]+)"/i', $html, $m)) {
            $pic = $m[1];
        }
        if (!$pic && preg_match('/<img[^>]*id="' . preg_quote($vid, '/') . '"[^>]*src="([^"]+)"/i', $html, $m)) {
            $pic = $m[1];
        }
        if (!$pic && preg_match('/<img[^>]*class="[^"]*cover[^"]*"[^>]*data-src="([^"]+)"/i', $html, $m)) {
            $pic = $m[1];
        }
        if (!$pic && preg_match('/<meta[^>]*property="og:image"[^>]*content="([^"]+)"/i', $html, $m)) {
            $pic = $m[1];
        }
        if (strpos($pic, '//') === 0) $pic = 'https:' . $pic;

        // ---------- 元信息 ----------
        $year = $area = $actor = '';
        if (preg_match('/<div[^>]*class="[^"]*result-info[^"]*active[^"]*"[^>]*>([\s\S]*?)<div[^>]*class="[^"]*clearfix[^"]*"/i', $html, $im)) {
            preg_match_all('/<h3[^>]*class="meta"[^>]*>([\s\S]*?)<\/h3>/i', $im[1], $hm);
            if (!empty($hm[1]) && count($hm[1]) >= 4) {
                $year  = trim(strip_tags($hm[1][1]));
                $area  = trim(strip_tags($hm[1][2]));
                $actor = trim(strip_tags($hm[1][3]));
            }
        }

        // ---------- 简介 ----------
        $desc = '';
        if (preg_match('/<meta[^>]*name="description"[^>]*content="([^"]+)"/i', $html, $m)) {
            $desc = trim(html_entity_decode($m[1], ENT_QUOTES, 'UTF-8'));
        }

        // ---------- token ----------
        $curId  = '';
        $eToken = '';
        $mtype  = '1';
        if (preg_match('/id="current_id"[^>]*value="([^"]*)"/i', $html, $m)) $curId  = $m[1];
        if (preg_match('/id="e_token"[^>]*value="([^"]*)"/i', $html, $m))    $eToken = $m[1];
        if (preg_match('/id="mtype"[^>]*value="([^"]*)"/i', $html, $m))       $mtype  = $m[1];

        $token = '';
        if ($curId && $eToken) {
            $last4 = substr($curId, -4);
            $arr   = [];
            $et    = $eToken;
            foreach (str_split($last4) as $ch) {
                $n   = intval($ch);
                $off = $n % 3 + 1;
                $arr[] = substr($et, $off, 8);
                $et    = substr($et, $off + 8);
            }
            $token = implode('', $arr);
        }

        // ---------- 播放列表接口 ----------
        $playFrom = [];
        $playUrl  = [];

        $api = "{$this->SITE}/api/getResN?videoId={$vid}&mtype={$mtype}&token={$token}";
        $apiHeaders = [
            'User-Agent'       => $this->UA,
            'Referer'          => "{$this->SITE}/play/{$vid}",
            'Accept'           => 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With' => 'XMLHttpRequest',
        ];
        $resp = $this->fetchHtml($api, $apiHeaders);
        $json = json_decode($resp, true);

        if (!empty($json['state']) && $json['state'] == 1 && !empty($json['data']['list'])) {
            $seenFlag = [];
            foreach ($json['data']['list'] as $item) {
                if (empty($item['resData'])) continue;
                $flags = json_decode($item['resData'], true);
                if (!is_array($flags)) continue;

                foreach ($flags as $f) {
                    $flag = trim($f['flag'] ?? '');
                    $url  = trim($f['url'] ?? '');
                    if (!$flag || !$url) continue;
                    if (isset($seenFlag[$flag])) continue;
                    $seenFlag[$flag] = true;

                    $playFrom[] = $flag;
                    $playUrl[]  = $url;
                }
            }
        }

        $vod = [
            'vod_id'        => $vid,
            'vod_name'      => $title,
            'vod_pic'       => $pic,
            'type_name'     => '',
            'vod_year'      => $year,
            'vod_area'      => $area,
            'vod_remarks'   => '',
            'vod_actor'     => $actor,
            'vod_director'  => '',
            'vod_content'   => $desc,
            'vod_play_from' => implode('$$$', $playFrom),
            'vod_play_url'  => implode('$$$', $playUrl),
        ];

        return ['list' => [$vod]];
    }

    // ============================================================
    // 搜索
    // ============================================================
    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $url  = "{$this->SITE}/search?q=" . urlencode($key);
        if ($page > 1) $url .= "&page={$page}";

        $list = $this->toVod($this->extractVodList($this->fetchHtml($url)));
        return $this->pageResult($list, $page, 0, 15);
    }

    // ============================================================
    // 播放
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $playUrl = $id;
        if (strpos($playUrl, '$') !== false) {
            $parts   = explode('$', $playUrl);
            $playUrl = end($parts);
        }
        if (strpos($playUrl, '//') === 0) $playUrl = 'https:' . $playUrl;

        return [
            'parse'  => 0,
            'url'    => $playUrl,
            'jx'     => 0,
            'header' => [
                'User-Agent' => $this->UA,
                'Referer'    => $this->SITE . '/',
            ],
        ];
    }
}

(new Spider())->run();