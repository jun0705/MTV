<?php
/**
 * 茶杯狐 - 影视仓 PHP 完美最终版
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    
    protected $HOST = 'http://www.bnjxjd.com';
    protected $UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    protected function fetchHtml($url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => [
                'User-Agent: ' . $this->UA,
                'Referer: ' . $this->HOST
            ]
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function cleanText($text) {
        if (!$text) return '';
        $text = str_replace(['&nbsp;', "\n", "\r"], ' ', $text);
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    protected function fixUrl($url) {
        if (!$url) return '';
        if (strpos($url, 'http') === 0) return $url;
        if (strpos($url, '//') === 0) return 'http:' . $url;
        if (strpos($url, '/') === 0) return rtrim($this->HOST, '/') . $url;
        return rtrim($this->HOST, '/') . '/' . $url;
    }

    // ============================================================
    // 列表解析 (精准抓取标题、图片、集数)
    // ============================================================
    protected function parseVideoList($html) {
        $vlist = [];
        if (!$html) return $vlist;
        
        $pattern = '/<a[^>]*class="[^"]*stui-vodlist__thumb[^"]*"[^>]*href="([^"]*)"[^>]*title="([^"]*)"[^>]*data-original="([^"]*)"[^>]*>(.*?)<\/a>/is';
        
        if (preg_match_all($pattern, $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $href = $match[1];
                $name = $match[2];
                $pic = $match[3];
                $inner = $match[4];

                // 网页里有 pic-text1（类型）和 pic-text（集数），我们取最后一个
                $remark = '';
                if (preg_match_all('/<span[^>]*class="pic-text[^"]*"[^>]*>(.*?)<\/span>/is', $inner, $rm)) {
                    $remark = $this->cleanText(strip_tags(end($rm[1])));
                }

                if ($name && $href) {
                    $vlist[] = [
                        'vod_id' => $this->fixUrl($href),
                        'vod_name' => $this->cleanText($name),
                        'vod_pic' => $this->fixUrl($pic),
                        'vod_remarks' => $remark
                    ];
                }
            }
        }
        return $vlist;
    }

    // ============================================================
    // 首页分类+筛选
    // ============================================================
    public function homeContent($filter) {
        $classes = [
            ['type_name' => '电影', 'type_id' => '1'],
            ['type_name' => '电视剧', 'type_id' => '2'],
            ['type_name' => '综艺', 'type_id' => '3'],
            ['type_name' => '动漫', 'type_id' => '4']
        ];

        $areaList = [
            ["n" => "全部", "v" => ""], ["n" => "内地", "v" => "内地"], ["n" => "香港", "v" => "香港"],
            ["n" => "台湾", "v" => "台湾"], ["n" => "美国", "v" => "美国"], ["n" => "韩国", "v" => "韩国"],
            ["n" => "日本", "v" => "日本"], ["n" => "泰国", "v" => "泰国"], ["n" => "英国", "v" => "英国"]
        ];

        $yearList = [["n" => "全部", "v" => ""]];
        for ($i = 2026; $i >= 2010; $i--) {
            $yearList[] = ["n" => (string)$i, "v" => (string)$i];
        }
        $yearList[] = ["n" => "更早", "v" => "2009"];

        $langList = [
            ["n" => "全部", "v" => ""], ["n" => "国语", "v" => "国语"], ["n" => "英语", "v" => "英语"],
            ["n" => "粤语", "v" => "粤语"], ["n" => "闽南语", "v" => "闽南语"], ["n" => "韩语", "v" => "韩语"],
            ["n" => "日语", "v" => "日语"], ["n" => "其它", "v" => "其它"]
        ];

        $sortList = [
            ["n" => "时间", "v" => "time"], ["n" => "人气", "v" => "hits"], ["n" => "评分", "v" => "score"]
        ];

        $filters = [];
        foreach ($classes as $c) {
            $filters[$c['type_id']] = [
                ["key" => "area", "name" => "地区", "value" => $areaList],
                ["key" => "year", "name" => "年份", "value" => $yearList],
                ["key" => "lang", "name" => "语言", "value" => $langList],
                ["key" => "sort", "name" => "排序", "value" => $sortList]
            ];
        }

        $list = $this->parseVideoList($this->fetchHtml($this->HOST));
        $this->outputJson(['class' => $classes, 'filters' => $filters, 'list' => $list]);
    }

    public function homeVideoContent() {
        $list = $this->parseVideoList($this->fetchHtml($this->HOST));
        $this->outputJson(['list' => $list]);
    }

    // ============================================================
    // 分类 (支持筛选，第一页不带页码)
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        
        $map = ['1' => 'dianying', '2' => 'dianshiju', '3' => 'zongyi', '4' => 'dongman'];
        $realTid = $map[$tid] ?? $tid;

        $area = !empty($extend['area']) ? $extend['area'] : '';
        $year = !empty($extend['year']) ? $extend['year'] : '';
        $lang = !empty($extend['lang']) ? $extend['lang'] : '';
        $sort = !empty($extend['sort']) ? $extend['sort'] : 'time';

        $pathParts = [];
        if ($area) $pathParts[] = "area/" . urlencode($area);
        if ($sort && $sort !== 'time') $pathParts[] = "by/" . urlencode($sort);
        $pathParts[] = "id/{$realTid}";
        if ($lang) $pathParts[] = "lang/" . urlencode($lang);
        if ($year) $pathParts[] = "year/{$year}";

        $url = "{$this->HOST}/vodshow/" . implode('/', $pathParts);
        
        // 第一页不加页码
        if ($page > 1) {
            $url .= "/page/{$page}";
        }
        $url .= ".html";

        $html = $this->fetchHtml($url);
        $list = $this->parseVideoList($html);

        // 提取真实总页数 (从尾页或 2/963 格式提取)
        $pagecount = 9999; 
        if (preg_match('/page\/(\d+)\.html"\s*>尾页<\/a>/is', $html, $m)) {
            $pagecount = intval($m[1]);
        } elseif (preg_match('/<a[^>]*>(\d+)\/(\d+)<\/a>/is', $html, $m)) {
            $pagecount = intval($m[2]);
        }

        $this->outputJson([
            'list' => $list,
            'page' => $page,
            'pagecount' => $pagecount,
            'limit' => 90,
            'total' => 999999
        ]);
    }

    // ============================================================
    // 搜索
    // ============================================================
    public function searchContent($wd, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $key = urlencode($wd);
        $url = "{$this->HOST}/vodsearch/wd/{$key}.html";
        
        $html = $this->fetchHtml($url);
        $list = $this->parseVideoList($html);

        $this->outputJson([
            'list' => $list,
            'page' => $page,
            'pagecount' => 9999,
            'limit' => 90,
            'total' => 999999
        ]);
    }

    // ============================================================
    // 详情
    // ============================================================
    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $url = $this->fixUrl($id);
        $html = $this->fetchHtml($url);
        if (!$html) $this->outputJson(['list' => []]);

        $info = ['vod_id' => $id];
        
        if (preg_match('/<h1[^>]*class="title"[^>]*>(.*?)<\/h1>/is', $html, $m)) $info['vod_name'] = $this->cleanText(strip_tags($m[1]));
        elseif (preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $html, $m)) $info['vod_name'] = $this->cleanText(strip_tags($m[1]));

        if (preg_match('/<span[^>]*class="detail-content"[^>]*>(.*?)<\/span>/is', $html, $m)) $info['vod_content'] = $this->cleanText(strip_tags($m[1]));
        elseif (preg_match('/<p[^>]*class="col-pd"[^>]*>(.*?)<\/p>/is', $html, $m)) $info['vod_content'] = $this->cleanText(strip_tags($m[1]));

        if (preg_match('/<img[^>]*class="img-responsive"[^>]*src="([^"]+)"/is', $html, $m)) $info['vod_pic'] = $this->fixUrl($m[1]);

        $tabs = [];
        if (preg_match_all('/<li[^>]*>.*?<a[^>]*href="#playlist(\d+)"[^>]*>(.*?)<\/a>/is', $html, $tabMatches, PREG_SET_ORDER)) {
            foreach ($tabMatches as $tm) {
                $name = $this->cleanText(strip_tags($tm[2]));
                if ($name) $tabs[] = $name;
            }
        }

        $ktabs = [];
        $klists = [];
        if (preg_match_all('/<ul[^>]*class="stui-content__playlist[^"]*"[^>]*>(.*?)<\/ul>/is', $html, $ulMatches)) {
            foreach ($ulMatches[1] as $idx => $ulHtml) {
                $episodes = [];
                if (preg_match_all('/<a[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/is', $ulHtml, $liMatches, PREG_SET_ORDER)) {
                    foreach ($liMatches as $lm) {
                        $epName = $this->cleanText(strip_tags($lm[2]));
                        $epHref = $this->fixUrl($lm[1]);
                        if ($epName && $epHref) $episodes[] = "{$epName}\${$epHref}";
                    }
                }
                if (!empty($episodes)) {
                    $srcName = $tabs[$idx] ?? ("线路" . ($idx + 1));
                    $ktabs[] = $srcName;
                    $klists[] = implode('#', $episodes);
                }
            }
        }

        $info['vod_play_from'] = !empty($ktabs) ? implode('$$$', $ktabs) : '茶杯狐';
        $info['vod_play_url'] = !empty($klists) ? implode('$$$', $klists) : '';

        $this->outputJson(['list' => [$info]]);
    }

    // ============================================================
    // 播放
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $playUrl = $this->fixUrl($id);
        $html = $this->fetchHtml($playUrl);
        
        $realUrl = null;
        if (preg_match('/"url"\s*:\s*"([^"]+\.m3u8[^"]*)"/is', $html, $m)) {
            $realUrl = str_replace('\\/', '/', $m[1]);
        } elseif (preg_match('/https?:\/\/[^"\']+\.m3u8[^"\']*/is', $html, $m)) {
            $realUrl = $m[0];
        }

        if ($realUrl) {
            $this->outputJson([
                'parse' => 0,
                'url' => $realUrl,
                'header' => ['User-Agent' => $this->UA]
            ]);
        }

        $this->outputJson(['parse' => 1, 'url' => $playUrl, 'header' => ['User-Agent' => $this->UA]]);
    }
}

(new Spider())->run();