<?php
/**
 * 电影先生 - 影视仓 PHP 最终完美版
 * 修复了：导演/主演HTML标签残留、筛选缺失、分页URL、线路解析
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    
    protected $HOST = 'https://silidm.com';
    protected $UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    protected function fetchHtml($url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => [
                'User-Agent: ' . $this->UA,
                'Referer: ' . $this->HOST
            ]
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function cleanText($text) {
        if (!$text) return '';
        $text = str_replace(['&nbsp;', "\n", "\r", "\t"], ' ', $text);
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    protected function fixUrl($url) {
        if (!$url) return '';
        if (strpos($url, 'http') === 0) return $url;
        if (strpos($url, '//') === 0) return 'https:' . $url;
        if (strpos($url, '/') === 0) return rtrim($this->HOST, '/') . $url;
        return rtrim($this->HOST, '/') . '/' . $url;
    }

    // ============================================================
    // 列表解析
    // ============================================================
    protected function getList($html) {
        $vlist = [];
        if (!$html) return $vlist;

        $pattern = '/<div[^>]*class="[^"]*module-item[^"]*"[^>]*>(.*?)<\/div>\s*<\/div>\s*<\/div>\s*<\/div>/is';
        if (preg_match_all($pattern, $html, $matches)) {
            foreach ($matches[1] as $item) {
                $name = '';
                if (preg_match('/<a[^>]*class="[^"]*module-item-title[^"]*"[^>]*title="([^"]*)"/is', $item, $m)) {
                    $name = $m[1];
                } elseif (preg_match('/title="([^"]+)"/is', $item, $m)) {
                    $name = $m[1];
                }

                $pic = '';
                if (preg_match('/<img[^>]*data-src="([^"]+)"/is', $item, $m)) {
                    $pic = $this->fixUrl($m[1]);
                } elseif (preg_match('/<img[^>]*src="([^"]+)"/is', $item, $m)) {
                    if (strpos($m[1], 'loading') === false && strpos($m[1], 'nopic') === false) {
                        $pic = $this->fixUrl($m[1]);
                    }
                }

                $remark = '';
                if (preg_match('/<div[^>]*class="[^"]*module-item-text[^"]*"[^>]*>(.*?)<\/div>/is', $item, $m)) {
                    $remark = $this->cleanText(strip_tags($m[1]));
                }

                $href = '';
                if (preg_match('/<a[^>]*href="([^"]+)"/is', $item, $m)) {
                    $href = $this->fixUrl($m[1]);
                }

                if ($name && $href) {
                    $vlist[] = [
                        'vod_id' => $href,
                        'vod_name' => $this->cleanText($name),
                        'vod_pic' => $pic,
                        'vod_remarks' => $remark ?: '更新中'
                    ];
                }
            }
        }
        return $vlist;
    }

    protected function getFilterList($items) {
        $arr = [["n" => "全部", "v" => ""]];
        foreach ($items as $item) $arr[] = ["n" => $item, "v" => $item];
        return $arr;
    }

    protected function getYears($start, $end) {
        $arr = [];
        for ($i = $start; $i >= $end; $i--) $arr[] = (string)$i;
        return $arr;
    }

    // ============================================================
    // 首页与筛选配置
    // ============================================================
    public function init($extend = '') {}

    public function homeContent($filter) {
        $classes = [
            ['type_name' => '电影', 'type_id' => 'dy'],
            ['type_name' => '剧集', 'type_id' => 'juji'],
            ['type_name' => '动漫', 'type_id' => 'dongman'],
            ['type_name' => '综艺', 'type_id' => 'zongyi']
        ];

        // 完全严格遵照源码提供的数据
        $filters = [
            "juji" => [
                ["key" => "class",  "name" => "剧情", "value" => $this->getFilterList(["国产剧","美剧","韩国剧","港剧","台湾剧","日本剧","泰国剧"])],
                ["key" => "area",   "name" => "地区", "value" => $this->getFilterList(["大陆","日本","美国","香港","台湾","英国","法国","韩国","德国","泰国","印度","意大利","加拿大","西班牙","其他"])],
                ["key" => "lang",   "name" => "语言", "value" => $this->getFilterList(["国语","日语","粤语","英语","法语","德语","韩语","普通话","其他"])],
                ["key" => "year",   "name" => "时间", "value" => $this->getFilterList($this->getYears(2024, 2012))], // 源码最新到2024
                ["key" => "letter", "name" => "字母", "value" => $this->getFilterList(array_merge(range('A','Z'), ['0-9']))],
                ["key" => "sort",   "name" => "排序", "value" => [["n"=>"时间排序","v"=>"time"],["n"=>"人气排序","v"=>"hits"],["n"=>"评分排序","v"=>"score"]]]
            ],
            // 因你未提供电影/动漫/综艺源码，这里留空，不影响壳子基础加载
            "dy"      => [],
            "dongman" => [],
            "zongyi"  => []
        ];

        $html = $this->fetchHtml($this->HOST . '/show/juji--time---------.html');
        $list = array_slice($this->getList($html), 0, 30);

        $this->outputJson(['class' => $classes, 'filters' => $filters, 'list' => $list]);
    }

    public function homeVideoContent() {
        $list = array_slice($this->getList($this->fetchHtml($this->HOST . '/show/juji--time---------.html')), 0, 30);
        $this->outputJson(['list' => $list]);
    }

    // ============================================================
    // 分类页 - 根据真实 URL 严格拼接
    // 结构: /show/{tid}-{area}-{sort}-{class}-{lang}-{letter}---{page}---{year}.html
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        $f = is_array($extend) ? $extend : [];

        $area   = $f['area']   ?? '';
        $class  = $f['class']  ?? '';
        $lang   = $f['lang']   ?? '';
        $letter = $f['letter'] ?? '';
        $year   = $f['year']   ?? '';
        $sort   = $f['sort']   ?? '';
        if ($sort === 'time') $sort = ''; // 默认时间排序，源码为空

        $pageStr = ($page > 1) ? (string)$page : '';

        $path = "/show/{$tid}-{$area}-{$sort}-{$class}-{$lang}-{$letter}---{$pageStr}---{$year}.html";
        $url  = $this->HOST . $path;

        $html = $this->fetchHtml($url);
        $list = $this->getList($html);

        $this->outputJson([
            'list'      => $list,
            'page'      => $page,
            'pagecount' => 9999,
            'limit'     => 90,
            'total'     => 999999
        ]);
    }

    // ============================================================
    // 搜索
    // ============================================================
    public function searchContent($key, $quick = false, $pg = 1) {
        $page = max(1, intval($pg));
        $encoded_key = urlencode($key);
        $url = "{$this->HOST}/search/{$encoded_key}-------------.html";
        if ($page > 1) $url .= "?page={$page}";

        $html = $this->fetchHtml($url);
        $list = $this->getList($html);

        $this->outputJson([
            'list'      => $list,
            'page'      => $page,
            'pagecount' => 9999,
            'limit'     => 90,
            'total'     => 999999
        ]);
    }

    // ============================================================
    // 详情页 - 修复了 HTML 标签残留问题
    // ============================================================
    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $url = $this->fixUrl($id);
        $html = $this->fetchHtml($url);
        if (!$html) $this->outputJson(['list' => []]);

        $info = ['vod_id' => $id, 'vod_name' => '未知'];

        // 标题
        if (preg_match('/<h1[^>]*class="[^"]*page-title[^"]*"[^>]*>(.*?)<\/h1>/is', $html, $m)) {
            $info['vod_name'] = $this->cleanText(strip_tags($m[1]));
        }

        // 封面
        if (preg_match('/<img[^>]*class="[^"]*lazyload[^"]*"[^>]*data-src="([^"]+)"/is', $html, $m)) {
            $info['vod_pic'] = $this->fixUrl($m[1]);
        }

        // 剧情简介
        if (preg_match('/<div[^>]*class="[^"]*vod_content[^"]*"[^>]*>([\s\S]*?)<\/div>/is', $html, $m)) {
            $info['vod_content'] = $this->cleanText(strip_tags($m[1]));
        }

        // 导演 (先 strip_tags 剔除内部所有标签，再替换斜杠)
        if (preg_match('/导演：<\/span>.*?<div[^>]*class="[^"]*video-info-actor[^"]*"[^>]*>(.*?)<\/div>/is', $html, $m)) {
            $director = strip_tags($m[1]);
            $director = str_replace(['/', '&nbsp;'], ' ', $director);
            $info['vod_director'] = $this->cleanText($director);
        }

        // 主演 (同上)
        if (preg_match('/主演：<\/span>.*?<div[^>]*class="[^"]*video-info-actor[^"]*"[^>]*>(.*?)<\/div>/is', $html, $m)) {
            $actor = strip_tags($m[1]);
            $actor = str_replace(['/', '&nbsp;'], ' ', $actor);
            $info['vod_actor'] = $this->cleanText($actor);
        }

        // 上映年份
        if (preg_match('/上映：<\/span>.*?<div[^>]*class="[^"]*video-info-item[^"]*"[^>]*>(\d{4})<\/div>/is', $html, $m)) {
            $info['vod_year'] = $m[1];
        }

        // 备注
        if (preg_match('/备注：<\/span>.*?<div[^>]*class="[^"]*video-info-item[^"]*"[^>]*>(.*?)<\/div>/is', $html, $m)) {
            $info['vod_remarks'] = $this->cleanText($m[1]);
        }

        // ========================================================
        // 线路与播放列表
        // ========================================================
        $tabsList = [];
        $playLists = [];

        $sourceNames = [];
        if (preg_match_all('/<div[^>]*class="[^"]*play-source-tab[^"]*"[^>]*data-source="([^"]+)"[^>]*>(.*?)<\/div>/is', $html, $tm, PREG_SET_ORDER)) {
            foreach ($tm as $t) {
                $sourceNames[$t[1]] = $this->cleanText(strip_tags($t[2]));
            }
        }

        if (preg_match_all('/<div[^>]*id="source-([^"]+)"[^>]*>([\s\S]*?)(?=<div[^>]*class="[^"]*play-source-content|<div[^>]*class="[^"]*play-source-tab|<\/div>\s*<div[^>]*class="[^"]*play-list-container|$)/is', $html, $bm, PREG_SET_ORDER)) {
            foreach ($bm as $b) {
                $key  = $b[1];
                $body = $b[2];
                $name = $sourceNames[$key] ?? $key;

                $items = [];
                if (preg_match_all('/<a\b[^>]*>[\s\S]*?<\/a>/is', $body, $am)) {
                    foreach ($am[0] as $aHtml) {
                        if (preg_match('/href="([^"]+)"/i', $aHtml, $h)
                            && preg_match('/class="([^"]*)"/i', $aHtml, $c)
                            && strpos($c[1], 'btn-default') !== false) {
                            if (preg_match('/>([\s\S]*?)<\/a>/i', $aHtml, $txt)) {
                                $epName = $this->cleanText(strip_tags($txt[1]));
                                $epHref = $this->fixUrl($h[1]);
                                if ($epName && $epHref) $items[] = "{$epName}\${$epHref}";
                            }
                        }
                    }
                }

                if (!empty($items)) {
                    $tabsList[] = $name;
                    $playLists[] = implode('#', $items);
                }
            }
        }

        $info['vod_play_from'] = !empty($tabsList) ? implode('$$$', $tabsList) : '电影先生';
        $info['vod_play_url']  = !empty($playLists) ? implode('$$$', $playLists) : '';

        $this->outputJson(['list' => [$info]]);
    }

    // ============================================================
    // 播放解析
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $playUrl = $this->fixUrl($id);
        $html = $this->fetchHtml($playUrl);
        
        if (!$html) {
            $this->outputJson(['parse' => 1, 'url' => $playUrl, 'header' => ['User-Agent' => $this->UA]]);
        }

        $realUrl = $this->extractM3u8($html);
        if ($realUrl) {
            $this->outputJson([
                'parse' => 0,
                'url' => $realUrl,
                'header' => ['User-Agent' => $this->UA, 'Referer' => $this->HOST . '/']
            ]);
        }

        $this->outputJson(['parse' => 1, 'url' => $playUrl, 'header' => ['User-Agent' => $this->UA]]);
    }

    protected function extractM3u8($html) {
        if (!$html) return null;
        $patterns = [
            '/"url"\s*:\s*"([^"]+\.m3u8[^"]*)"/is',
            '/url\s*:\s*"([^"]+\.m3u8[^"]*)"/is',
            '/"url"\s*:\s*\'([^\']+\.m3u8[^\']*)\'/is',
        ];
        foreach ($patterns as $p) {
            if (preg_match($p, $html, $m)) {
                $url = str_replace('\\/', '/', $m[1]);
                if (strpos($url, '//') === 0) $url = 'https:' . $url;
                return $url;
            }
        }
        if (preg_match('/https?:\/\/[^"\']+\.m3u8[^"\']*/is', $html, $m)) {
            return $m[0];
        }
        if (preg_match('/<iframe[^>]*src=["\']([^"\']+)["\']/is', $html, $m)) {
            $src = $m[1];
            if (strpos($src, '//') === 0) $src = 'https:' . $src;
            elseif (strpos($src, '/') === 0) $src = $this->HOST . $src;
            return $this->extractM3u8($this->fetchHtml($src));
        }
        return null;
    }
}

(new Spider())->run();