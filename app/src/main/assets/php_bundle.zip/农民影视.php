<?php
/**
 * 农民影视 (Nm) - 影视仓 PHP 最终版
 * 修复了正则定界符导致的 Warning 报错
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {
    
    protected $host = "https://vip.wwgz.cn:5200";
    protected $UA   = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Snapchat/10.77.5.59 (like Safari/604.1)";

    public function init($extend = '') {
        if (!empty($extend) && is_string($extend)) {
            $extend = trim($extend);
            if (strpos($extend, 'http') === 0) {
                $this->host = rtrim($extend, '/');
            }
        }
    }

    protected function outputJson($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    protected function fetch($url, $referer = null, $postData = null) {
        $ch = curl_init();
        $headers = [
            'User-Agent: ' . $this->UA,
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language: zh-CN,zh;q=0.9',
            'cache-control: no-cache',
            'pragma: no-cache',
            'upgrade-insecure-requests: 1',
            'Referer: ' . ($referer ?: $this->host . '/'),
            'sec-fetch-site: ' . ($referer ? 'same-origin' : 'none')
        ];

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_COOKIEFILE => ''
        ]);

        if ($postData !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            if (is_array($postData)) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
            }
        }

        $res = curl_exec($ch);
        curl_close($ch);
        return $res ?: '';
    }

    protected function fixPic($url) {
        if (!$url) return "";
        if (strpos($url, '//') === 0) return 'http:' . $url;
        if (strpos($url, '/') === 0) return $this->host . $url;
        return $url;
    }

    // 修复了正则的定界符，使用 # 代替 /
    protected function group($regex, $text, $groupIndex = 1) {
        if (!$text) return "";
        if (preg_match($regex, $text, $matches)) {
            return isset($matches[$groupIndex]) ? trim($matches[$groupIndex]) : "";
        }
        return "";
    }

    // ============================================================
    // 列表解析 (全部改用 # 定界符)
    // ============================================================
    protected function parseList($html) {
        $list = [];
        if (!$html) return $list;

        if (preg_match_all('#<li[^>]*>([\s\S]*?)</li>#is', $html, $matches)) {
            $seen = [];
            foreach ($matches[1] as $block) {
                $href = $this->group('#<a[^>]*href="([^"]*vod-detail-id[^"]*)"#is', $block);
                if (!$href || in_array($href, $seen)) continue;
                $seen[] = $href;

                $title = $this->group('#<a[^>]*title="([^"]*)"#is', $block);
                if (!$title) {
                    $title = $this->group('#<[^>]*class="[^"]*sTit[^"]*"[^>]*>([^<]+)<#is', $block);
                }

                $pic = $this->group('#<img[^>]*data-echo="([^"]+)"#is', $block);
                if (!$pic) $pic = $this->group('#<img[^>]*src="([^"]+)"#is', $block);

                $remark = $this->group('#<[^>]*class="[^"]*sBottom[^"]*"[^>]*>[\s\S]*?<span[^>]*>([^<]*)<\/span>#is', $block);
                if (!$remark) {
                    $remark = $this->group('#<[^>]*class="[^"]*covericon[^"]*"[^>]*>([^<]*)<#is', $block);
                }
                $remark = strip_tags($remark);

                $list[] = [
                    'vod_id' => $href,
                    'vod_name' => trim($title),
                    'vod_pic' => $this->fixPic($pic),
                    'vod_remarks' => trim($remark)
                ];
            }
        }
        return $list;
    }

    // ============================================================
    // 首页与筛选
    // ============================================================
    public function homeContent($filter) {
        $classes = [
            ["type_id" => "1", "type_name" => "电影"],
            ["type_id" => "2", "type_name" => "连续剧"],
            ["type_id" => "3", "type_name" => "综艺"],
            ["type_id" => "4", "type_name" => "动漫"],
            ["type_id" => "26", "type_name" => "短剧"]
        ];

        $years = [["n" => "全部", "v" => ""]];
        for ($y = 2026; $y >= 1900; $y--) $years[] = ["n" => (string)$y, "v" => (string)$y];

        $areas = [
            ["n" => "全部", "v" => ""], ["n" => "大陆", "v" => "大陆"], ["n" => "香港", "v" => "香港"],
            ["n" => "台湾", "v" => "台湾"], ["n" => "美国", "v" => "美国"], ["n" => "韩国", "v" => "韩国"],
            ["n" => "日本", "v" => "日本"], ["n" => "泰国", "v" => "泰国"], ["n" => "新加坡", "v" => "新加坡"],
            ["n" => "马来西亚", "v" => "马来西亚"], ["n" => "印度", "v" => "印度"], ["n" => "英国", "v" => "英国"],
            ["n" => "法国", "v" => "法国"], ["n" => "加拿大", "v" => "加拿大"], ["n" => "西班牙", "v" => "西班牙"],
            ["n" => "俄罗斯", "v" => "俄罗斯"], ["n" => "其它", "v" => "其它"]
        ];

        $byArr = [
            ["n" => "全部", "v" => "time"], ["n" => "人气", "v" => "hits"], ["n" => "评分", "v" => "score"]
        ];

        $f1_types = [["n" => "全部", "v" => ""], ["n" => "动作片", "v" => "5"], ["n" => "喜剧片", "v" => "6"], ["n" => "爱情片", "v" => "7"], ["n" => "科幻片", "v" => "8"], ["n" => "恐怖片", "v" => "9"], ["n" => "剧情片", "v" => "10"], ["n" => "战争片", "v" => "11"], ["n" => "惊悚片", "v" => "16"], ["n" => "奇幻片", "v" => "17"]];
        $f2_types = [["n" => "全部", "v" => ""], ["n" => "国产剧", "v" => "12"], ["n" => "港台泰", "v" => "13"], ["n" => "日韩剧", "v" => "14"], ["n" => "欧美剧", "v" => "15"]];
        $f4_types = [["n" => "全部", "v" => ""], ["n" => "动漫剧", "v" => "18"]];

        $filters = [
            "1" => [
                ["key" => "id", "name" => "类型", "value" => $f1_types],
                ["key" => "area", "name" => "地区", "value" => $areas],
                ["key" => "year", "name" => "年份", "value" => $years],
                ["key" => "by", "name" => "排序", "value" => $byArr]
            ],
            "2" => [
                ["key" => "id", "name" => "类型", "value" => $f2_types],
                ["key" => "area", "name" => "地区", "value" => $areas],
                ["key" => "year", "name" => "年份", "value" => $years],
                ["key" => "by", "name" => "排序", "value" => $byArr]
            ],
            "3" => [
                ["key" => "id", "name" => "类型", "value" => [["n" => "全部", "v" => ""]]],
                ["key" => "area", "name" => "地区", "value" => $areas],
                ["key" => "year", "name" => "年份", "value" => $years],
                ["key" => "by", "name" => "排序", "value" => $byArr]
            ],
            "4" => [
                ["key" => "id", "name" => "类型", "value" => $f4_types],
                ["key" => "area", "name" => "地区", "value" => $areas],
                ["key" => "year", "name" => "年份", "value" => $years],
                ["key" => "by", "name" => "排序", "value" => $byArr]
            ],
            "26" => [
                ["key" => "id", "name" => "类型", "value" => [["n" => "全部", "v" => ""]]],
                ["key" => "area", "name" => "地区", "value" => $areas],
                ["key" => "year", "name" => "年份", "value" => $years],
                ["key" => "by", "name" => "排序", "value" => $byArr]
            ]
        ];

        $html = $this->fetch($this->host . "/", null);
        $list = $this->parseList($html);

        $this->outputJson(['class' => $classes, 'filters' => $filter ? $filters : new stdClass(), 'list' => $list]);
    }

    public function homeVideoContent() {
        $html = $this->fetch($this->host . "/", null);
        $this->outputJson(['list' => $this->parseList($html)]);
    }

    // ============================================================
    // 分类
    // ============================================================
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $page = max(1, intval($pg));
        
        if ($tid === 'home') {
            $html = $this->fetch($this->host . "/", null);
            $this->outputJson(['page' => 1, 'pagecount' => 1, 'list' => $this->parseList($html)]);
        }

        $id = $tid;
        if (!empty($extend['id'])) {
            $id = $extend['id'];
        }
        preg_match('#\d+#', $id, $m);
        $s = isset($m[0]) ? $m[0] : "1";

        $by     = $extend['by']     ?? 'time';
        if (empty($by)) $by = 'time';
        $cls    = $extend['class']  ?? '';
        $year   = $extend['year']   ?? '';
        $letter = $extend['letter'] ?? '';
        $area   = $extend['area']   ?? '';
        $lang   = $extend['lang']   ?? '';

        $url = "{$this->host}/index.php?m=vod-list-id-{$s}-pg-{$page}-order--by-{$by}-class-{$cls}-year-{$year}-letter-{$letter}-area-" . urlencode($area) . "-lang-" . urlencode($lang) . ".html";
        
        $html = $this->fetch($url, null);
        $list = $this->parseList($html);

        $this->outputJson([
            'page' => $page,
            'pagecount' => count($list) > 0 ? $page + 1 : 1,
            'list' => $list
        ]);
    }

    // ============================================================
    // 搜索
    // ============================================================
    public function searchContent($key, $quick = false, $pg = 1) {
        $url = "{$this->host}/index.php?m=vod-search";
        $resp = $this->fetch($url, "{$this->host}/vod-search", ['wd' => $key]);

        $list = [];
        if (preg_match_all('#<li[^>]*>([\s\S]*?)</li>#is', $resp, $matches)) {
            foreach ($matches[1] as $block) {
                if (strpos($block, 'vod-detail-id') === false) continue;

                $href = $this->group('#<a[^>]*href="([^"]*vod-detail-id[^"]*)"#is', $block);
                if (!$href) continue;

                $pic = $this->group('#<img[^>]*data-src="([^"]+)"#is', $block);
                if (!$pic) $pic = $this->group('#<img[^>]*src="([^"]+)"#is', $block);

                $title = $this->group('#<[^>]*class="[^"]*sTit[^"]*"[^>]*>([^<]+)<#is', $block);
                $style = $this->group('#<[^>]*class="[^"]*sStyle[^"]*"[^>]*>([^<]+)<#is', $block);

                $score = "";
                $actor = "";
                if (preg_match_all('#<[^>]*class="[^"]*sDes[^"]*"[^>]*>([^<]+)<#is', $block, $dM)) {
                    foreach ($dM[1] as $txt) {
                        if (strpos($txt, '评分') !== false) $score = trim(preg_replace('#^.*?评分[：:]?\s*#u', '', $txt));
                        if (strpos($txt, '主演') !== false) $actor = trim(preg_replace('#^.*?主演[：:]?\s*#u', '', $txt));
                    }
                }

                $parts = [];
                if ($style) $parts[] = $style;
                if ($score) $parts[] = $score . "分";
                if ($actor) $parts[] = $actor;
                $remark = implode(" | ", $parts);

                $list[] = [
                    'vod_id' => $href,
                    'vod_name' => trim($title),
                    'vod_pic' => $this->fixPic($pic),
                    'vod_remarks' => $remark
                ];
            }
        }

        $this->outputJson(['list' => $list]);
    }

    // ============================================================
    // 详情
    // ============================================================
    public function detailContent($ids) {
        $vid = is_array($ids) ? $ids[0] : $ids;
        $url = (strpos($vid, 'http') === 0) ? $vid : $this->host . $vid;
        $html = $this->fetch($url, null);

        $info = ['vod_id' => $vid];

        $name = $this->group('#<h1[^>]*class="title"[^>]*>[\s\S]*?<a[^>]*title="([^"]+)"#is', $html);
        if (!$name) $name = $this->group('#<title>\s*《([^》]+)》#is', $html);
        $info['vod_name'] = trim($name);

        $pic = $this->group('#<[^>]*class="page-hd"[^>]*>[\s\S]*?<img[^>]*src="([^"]+)"#is', $html);
        $info['vod_pic'] = $this->fixPic($pic);

        $remarks = $this->group('#<div[^>]*class="desc_item"[^>]*>[\s\S]*?状态[:：][\s\S]*?<font[^>]*>([^<]+)<\/font>#is', $html);
        $info['vod_remarks'] = trim($remarks);

        $year = $this->group('#<article[^>]*class="detail-con"[^>]*>[\s\S]*?年代[：:][\s\S]*?<em[^>]*>([^<]+)<\/em>#is', $html);
        if (!$year) $year = $this->group('#<div[^>]*class="desc_item"[^>]*>[\s\S]*?年代[:：][\s\S]*?<a[^>]*>([^<]+)<\/a>#is', $html);
        $info['vod_year'] = trim($year);

        $actorBlock = $this->group('#<div[^>]*class="desc_item"[^>]*>[\s\S]*?主演[:：]([\s\S]*?)<\/div>#is', $html);
        $actorList = [];
        if ($actorBlock && preg_match_all('#>([^<]+)</a>#is', $actorBlock, $aM)) {
            foreach ($aM[1] as $a) {
                $a = trim($a);
                if ($a && strpos($a, 'http') !== 0 && strpos($a, 'target') === false) $actorList[] = $a;
            }
        }
        $info['vod_actor'] = implode(" ", $actorList);

        $dirBlock = $this->group('#<div[^>]*class="desc_item"[^>]*>[\s\S]*?导演[:：]([\s\S]*?)<\/div>#is', $html);
        $dirList = [];
        if ($dirBlock && preg_match_all('#>([^<]+)</a>#is', $dirBlock, $dM)) {
            foreach ($dM[1] as $d) {
                $d = trim($d);
                if ($d && strpos($d, 'http') !== 0 && strpos($d, 'target') === false) $dirList[] = $d;
            }
        }
        $info['vod_director'] = implode(" ", $dirList);

        $content = $this->group('#<article[^>]*class="detail-con"[^>]*>[\s\S]*?<p>([\s\S]*?)</p>#is', $html);
        $content = preg_replace('#<[^>]+>#', '', $content);
        $content = preg_replace('#简[\s\S]*?介[：:]\s*#u', '', $content);
        $content = str_replace('&nbsp;', ' ', $content);
        $info['vod_content'] = trim(preg_replace('#\s+#', ' ', $content));

        $playBtn = $this->group('#<a[^>]*href="([^"]+)"[^>]*class="greenBtn"#is', $html);
        if (!$playBtn) $playBtn = $this->group('#<a[^>]*class="greenBtn"[^>]*href="([^"]+)"#is', $html);
        if (!$playBtn) $playBtn = $this->group('#href="(\/vod-play-id-[^"]+)"#is', $html);

        $info['vod_play_from'] = "";
        $info['vod_play_url'] = "";

        if ($playBtn) {
            $playUrl = (strpos($playBtn, 'http') === 0) ? $playBtn : $this->host . $playBtn;
            $playHtml = $this->fetch($playUrl, $url);

            $macFrom = $this->group("#mac_from='([^']+)'#is", $playHtml);
            $macUrl  = $this->group("#mac_url='([^']+)'#is", $playHtml);

            if ($macFrom && $macUrl) {
                $lineNames = [];
                $tabBox = $this->group('#<div[^>]*id="leftTabBox"[^>]*>[\s\S]*?<ul>([\s\S]*?)</ul>#is', $playHtml);
                if ($tabBox && preg_match_all('#<li[^>]*>[\s\S]*?</li>#is', $tabBox, $liM)) {
                    foreach ($liM[0] as $li) {
                        $nm = $this->group('#<a[^>]*>([^<]+)</a>#is', $li);
                        if ($nm) $lineNames[] = trim($nm);
                    }
                }
                if (empty($lineNames)) {
                    $lineNames = explode('$$$', $macFrom);
                }

                $urlLines = explode('$$$', $macUrl);
                $playFromList = [];
                $playUrlList = [];

                foreach ($urlLines as $j => $line) {
                    $nm = (!empty($lineNames[$j])) ? $lineNames[$j] : "线路" . ($j + 1);
                    $eps = explode('#', $line);
                    $epList = [];
                    foreach ($eps as $ep) {
                        $parts = explode('$', $ep);
                        if (count($parts) === 2) $epList[] = "{$parts[0]}\${$parts[1]}";
                        else $epList[] = $ep;
                    }
                    $playFromList[] = $nm;
                    $playUrlList[] = implode('#', $epList);
                }

                $info['vod_play_from'] = implode('$$$', $playFromList);
                $info['vod_play_url']  = implode('$$$', $playUrlList);
            }
        }

        $this->outputJson(['list' => [$info]]);
    }

    // ============================================================
    // 播放 (代理接口 api.wwgz.cn 保持不变)
    // ============================================================
    public function playerContent($flag, $id, $vipFlags = []) {
        $parse = 0;
        $realUrl = $this->decodeNmUrl($id);

        if (!$realUrl || strpos($realUrl, 'http') !== 0) {
            $nmUrl = "https://api.wwgz.cn:520/player/?url=";
            $v = $this->fetch($nmUrl . $id, null);
            $m = $this->group('#"url"\s*:\s*"([^"]+)"#is', $v);
            
            if ($m) {
                $realUrl = str_replace('\/', '/', $m);
            } else {
                $realUrl = $nmUrl . $id;
                $parse = 1;
            }
        }

        $this->outputJson([
            'parse' => $parse,
            'url' => $realUrl,
            'header' => [
                'User-Agent' => $this->UA
            ]
        ]);
    }

    // 解密算法
    protected function decodeNmUrl($s) {
        if (!$s) return "";
        $s = preg_replace('/#+$/', '', $s);
        if (strlen($s) < 66) return "";

        $first = substr($s, 0, 66);
        $rest  = substr($s, 66);

        $even = "";
        for ($i = 0; $i < strlen($first); $i += 2) {
            $even .= $first[$i];
        }

        $merged = $even . str_replace(['O0O0O', 'oo00o', 'o000o'], ['=', '/', '+'], $rest);
        $decoded = base64_decode($merged);
        
        return $decoded ?: "";
    }

    public function localProxy($param) {
        return null;
    }
}

(new Spider())->run();