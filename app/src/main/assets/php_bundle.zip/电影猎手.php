<?php
/**
 * 电影猎手
 * 由 [影]电影猎手.py 转换（含 curl_multi 并发优化）
 * RSA 加密 + HMAC-MD5 签名 + AES 解密
 * @header({
 *   searchable: 1,
 *   filterable: 1,
 *   quickSearch: 0,
 *   title: '电影猎手',
 *   lang: 'php'
 * })
 */
require_once __DIR__ . '/lib/spider.php';

class Spider extends BaseSpider {

    private $host = '';
    private $device = '';
    private $t = '';

    private $UA = 'okhttp/4.9.2';

    private $PUBLIC_KEY = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA02F/kPg5A2NX4qZ5JSns+bjhVMCC6JbTiTKpbgNgiXU+Kkorg6Dj76gS68gB8llhbUKCXjIdygnHPrxVHWfzmzisq9P9awmXBkCk74Skglx2LKHa/mNz9ivg6YzQ5pQFUEWS0DfomGBXVtqvBlOXMCRxp69oWaMsnfjnBV+0J7vHbXzUIkqBLdXSNfM9Ag5qdRDrJC3CqB65EJ3ARWVzZTTcXSdMW9i3qzEZPawPNPe5yPYbMZIoXLcrqvEZnRK1oak67/ihf7iwPJqdc+68ZYEmmdqwunOvRdjq89fQMVelmqcRD9RYe08v+xDxG9Co9z7hcXGTsUquMxkh29uNawIDAQAB';

    private $HMAC_KEY = '635a580fcb5dc6e60caa39c31a7bde48';

    private $AES_KEY = 'e6d5de5fcc51f53d';
    private $AES_IV  = '2f13eef7dfc6c613';

    // ============================================================
    //  初始化
    // ============================================================
    public function init($extend = '') {
        $this->device = $this->deviceId();
        $this->t = strval(time());
        $this->host = $this->getHost();
        return true;
    }

    private function deviceId() {
        $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $s = '';
        for ($i = 0; $i < 32; $i++) {
            $s .= $chars[random_int(0, strlen($chars) - 1)];
        }
        return $s;
    }

    private function getHost() {
        $headers = [
            'User-Agent' => $this->UA,
            'Connection' => 'Keep-Alive',
        ];
        $res = $this->fetch('https://app-site.ecoliving168.com/domain_v5.json', [], $headers);
        $json = json_decode($res ?: '{}', true);
        $api = $json['api_service'] ?? '';
        return str_replace('/api/', '', $api);
    }

    // ============================================================
    //  请求头
    // ============================================================
    private function header() {
        return [
            'User-Agent'       => 'Android',
            'Accept'           => 'application/prs.55App.v2+json',
            'timestamp'        => $this->t,
            'x-client-setting' => '{"pure-mode":1}',
            'x-client-uuid'    => '{"device_id":' . $this->device . '}, "type":1,"brand":"Redmi", "model":"M2012K10C", "system_version":30, "sdk_version":"3.1.0.7"}',
            'x-client-version' => '3096 ',
        ];
    }

    // ============================================================
    //  RSA + HMAC 签名
    // ============================================================
    private function url($id = null) {
        if (!is_array($id)) $id = [];
        $id['timestamp'] = $this->t;

        $encryptedText = json_encode($id, JSON_UNESCAPED_UNICODE);

        $pubKey = "-----BEGIN PUBLIC KEY-----\n" .
            chunk_split($this->PUBLIC_KEY, 64, "\n") .
            "-----END PUBLIC KEY-----\n";
        $keyRes = openssl_pkey_get_public($pubKey);
        openssl_public_encrypt($encryptedText, $encrypted, $keyRes, OPENSSL_PKCS1_PADDING);
        $base64 = base64_encode($encrypted);

        $result = str_replace(['+', '/', '='], ['-', '_', ''], $base64);

        $sign = hash_hmac('md5', $result, $this->HMAC_KEY);

        return [$result, $sign];
    }

    // ============================================================
    //  AES 解密
    // ============================================================
    private function aes($text) {
        $text = str_replace(['-', '_'], ['+', '/'], $text) . '==';
        $raw = base64_decode($text);
        if ($raw === false) return [];
        $decrypted = openssl_decrypt($raw, 'AES-128-CBC', $this->AES_KEY, OPENSSL_RAW_DATA, $this->AES_IV);
        if ($decrypted === false) return [];
        $json = json_decode($decrypted, true);
        return is_array($json) ? $json : [];
    }

    // ============================================================
    //  列表项转换
    // ============================================================
    private function voides($item) {
        $name = $item['name'] ?? $item['title'] ?? '';
        if (!$name) return null;
        return [
            'vod_id'      => $item['id'] ?? $item['click'] ?? '',
            'vod_name'    => $name,
            'vod_pic'     => $item['cover'] ?? $item['image'] ?? '',
            'vod_year'    => $item['year'] ?? $item['label'] ?? '',
            'vod_remarks' => $item['dynamic'] ?? $item['sub_title'] ?? '',
        ];
    }

    // ============================================================
    //  播放列表转换
    // ============================================================
    private function playeach($data) {
        $playUrls = [];
        if (!is_array($data)) return '';
        foreach ($data as $it) {
            $playUrl = $it['play_url'] ?? '';
            $epName  = $it['episode_name'] ?? '';
            if (preg_match('/mp4|m3u8/', $playUrl)) {
                $playUrls[] = $epName . '$' . $playUrl;
            } else {
                $playUrls[] = $epName . '$' . ($it['from_code'] ?? '') . '|||' . $playUrl . '|||' . ($it['episode_id'] ?? '');
            }
        }
        return implode('#', $playUrls);
    }

    private function playlist($body) {
        try {
            list($pack, $sign) = $this->url($body);
            $url = "{$this->host}/api/v1/movie_addr/list?pack={$pack}&signature={$sign}";
            $res = $this->fetch($url, [], $this->header());
            $json = json_decode($res ?: '{}', true);
            $data = $json['data'] ?? [];
            return $this->playeach($data);
        } catch (\Throwable $e) {
            return '';
        }
    }

    /**
     * 并发拉取多个线路的播放列表（curl_multi）
     */
    private function playlistMulti($tasks) {
        if (!$tasks) return [];

        $mh = curl_multi_init();
        $handles = [];
        $order = [];

        foreach ($tasks as $i => $body) {
            list($pack, $sign) = $this->url($body);
            $url = "{$this->host}/api/v1/movie_addr/list?pack={$pack}&signature={$sign}";

            $headers = [];
            foreach ($this->header() as $k => $v) {
                $headers[] = "$k: $v";
            }

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_HTTPHEADER     => $headers,
            ]);
            curl_multi_add_handle($mh, $ch);
            $handles[$i] = $ch;
            $order[] = $i;
        }

        $running = null;
        do {
            $status = curl_multi_exec($mh, $running);
            if ($running) {
                curl_multi_select($mh, 0.1);
            }
        } while ($running > 0 && $status === CURLM_OK);

        $results = [];
        foreach ($handles as $i => $ch) {
            $res = curl_multi_getcontent($ch);
            $json = json_decode($res ?: '{}', true);
            $data = $json['data'] ?? [];
            $results[$i] = is_array($data) ? $this->playeach($data) : '';
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
        }
        curl_multi_close($mh);

        $ordered = [];
        foreach ($order as $i) {
            $ordered[] = $results[$i] ?? '';
        }
        return $ordered;
    }

    // ============================================================
    //  Spider 入口
    // ============================================================
    public function homeContent($filter) {
        $classes = [];
        $filters = [];
        try {
            list($pack, $sign) = $this->url();
            $url = "{$this->host}/api/v1/app/config?pack={$pack}&signature={$sign}";
            $res = $this->fetch($url, [], $this->header());
            $data1 = $this->aes($res ?: '');

            $dy = ['class'=>'类型','area'=>'地区','lang'=>'语言','year'=>'年份','letter'=>'字母','by'=>'排序','sort'=>'排序'];

            $sorts = $data1['data']['movie_screen']['sort'] ?? [];
            if (is_array($sorts) && count($sorts) > 0) array_shift($sorts);
            $sortArr = [];
            foreach ($sorts as $item) {
                $sortArr[] = ['n' => $item['name'] ?? '', 'v' => $item['value'] ?? ''];
            }

            $screenFilters = $data1['data']['movie_screen']['filter'] ?? [];
            foreach ($screenFilters as $item) {
                $typeId = strval($item['id'] ?? '');
                $classes[] = ['type_name' => $item['name'] ?? '', 'type_id' => $typeId];

                $hasNonEmpty = false;
                foreach ($dy as $key => $_) {
                    if (!empty($item[$key])) { $hasNonEmpty = true; break; }
                }
                if (!$hasNonEmpty) continue;

                $filters[$typeId] = [];
                $filters[$typeId][] = ['key'=>'sort', 'name'=>'排序', 'value'=>$sortArr];

                foreach ($item as $dkey => $dval) {
                    if (isset($dy[$dkey]) && $dval && is_array($dval)) {
                        array_shift($dval);
                        $valueArray = [];
                        foreach ($dval as $value) {
                            $value = trim(strval($value));
                            if ($value !== '') {
                                $valueArray[] = ['n'=>$value, 'v'=>$value];
                            }
                        }
                        if ($valueArray) {
                            $filters[$typeId][] = ['key'=>$dkey, 'name'=>$dy[$dkey], 'value'=>$valueArray];
                        }
                    }
                }
            }
        } catch (\Throwable $e) {}

        return [
            'class'   => $classes,
            'filters' => (object)$filters,
        ];
    }

    public function homeVideoContent() {
        $videos = [];
        try {
            list($pack, $sign) = $this->url();
            $url = "{$this->host}/api/v1/movie/index_recommend?pack={$pack}&signature={$sign}";
            $res = $this->fetch($url, [], $this->header());
            $json = json_decode($res ?: '{}', true);
            $data = $json['data'] ?? [];
            if (is_array($data)) {
                foreach ($data as $item) {
                    if (empty($item['list']) || !is_array($item['list'])) continue;
                    foreach ($item['list'] as $it) {
                        $v = $this->voides($it);
                        if ($v) $videos[] = $v;
                    }
                }
            }
        } catch (\Throwable $e) {}
        return ['list' => $videos];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        if (is_string($extend)) $extend = json_decode($extend, true) ?: [];
        $extend = is_array($extend) ? $extend : [];

        $body = [
            'type_id'  => strval($tid),
            'sort'     => $extend['sort'] ?? 'by_default',
            'class'    => $extend['class'] ?? '类型',
            'area'     => $extend['area'] ?? '地区',
            'year'     => $extend['year'] ?? '年份',
            'page'     => strval($pg),
            'pageSize' => '21',
        ];

        $list = [];
        try {
            list($pack, $sign) = $this->url($body);
            $url = "{$this->host}/api/v1/movie/screen/list?pack={$pack}&signature={$sign}";
            $res = $this->fetch($url, [], $this->header());
            $json = json_decode($res ?: '{}', true);
            $data = $json['data']['list'] ?? [];
            if (is_array($data)) {
                foreach ($data as $item) {
                    $v = $this->voides($item);
                    if ($v) $list[] = $v;
                }
            }
        } catch (\Throwable $e) {}

        return $this->pageResult($list, intval($pg), 9999, 999999);
    }

    public function detailContent($ids) {
        $vid = is_array($ids) ? ($ids[0] ?? '') : $ids;
        $vid = strval($vid);
        if ($vid === '') return ['list' => []];

        try {
            list($pack, $sign) = $this->url(['id' => $vid]);
            $url = "{$this->host}/api/v1/movie/detail?pack={$pack}&signature={$sign}";
            $res = $this->fetch($url, [], $this->header());
            $json = json_decode($res ?: '{}', true);
            $data = $json['data'] ?? [];
            if (!$data) return ['list' => []];

            $video = [
                'vod_id'      => $vid,
                'vod_name'    => $data['name'] ?? '',
                'type_name'   => $data['type_name'] ?? '',
                'vod_year'    => $data['year'] ?? '',
                'vod_area'    => $data['area'] ?? '',
                'vod_remarks' => $data['dynami'] ?? '',
                'vod_content' => $data['content'] ?? '',
            ];

            $play = [];
            $names = [];
            $tasks = [];

            foreach ($data['play_from'] ?? [] as $itt) {
                $name = $itt['name'] ?? '';
                if (!empty($itt['list']) && is_array($itt['list'])) {
                    $names[] = $name;
                    $play[] = $this->playeach($itt['list']);
                } else {
                    $tasks[] = ['movie_id' => $vid, 'from_code' => $itt['code'] ?? ''];
                    $names[] = $name;
                }
            }

            // 并发拉取所有空线路
            if ($tasks) {
                $results = $this->playlistMulti($tasks);
                foreach ($results as $r) {
                    $play[] = $r ?: '';
                }
            }

            $video['vod_play_from'] = implode('$$$', $names);
            $video['vod_play_url']  = implode('$$$', $play);

            return ['list' => [$video]];
        } catch (\Throwable $e) {
            return ['list' => []];
        }
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $videos = [];
        try {
            $body = [
                'keyword'  => $key,
                'sort'     => '',
                'type_id'  => '0',
                'page'     => strval($pg),
                'pageSize' => '10',
                'res_type' => 'by_movie_name',
            ];
            list($pack, $sign) = $this->url($body);
            $url = "{$this->host}/api/v1/movie/search?pack={$pack}&signature={$sign}";
            $res = $this->fetch($url, [], $this->header());
            $json = json_decode($res ?: '{}', true);
            $data = $json['data']['list'] ?? [];
            if (is_array($data)) {
                foreach ($data as $it) {
                    $v = $this->voides($it);
                    if ($v) $videos[] = $v;
                }
            }
        } catch (\Throwable $e) {}

        return ['list' => $videos, 'page' => intval($pg)];
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        $url = strval($id);

        if (strpos($url, 'm3u8') === false && strpos($url, 'mp4') === false) {
            try {
                $add = explode('|||', $id);
                $data = [
                    'from_code'  => $add[0] ?? '',
                    'play_url'   => $add[1] ?? '',
                    'episode_id' => $add[2] ?? '',
                    'type'       => 'play',
                ];
                list($pack, $sign) = $this->url($data);
                $api = "{$this->host}/api/v1/movie_addr/parse_url?pack={$pack}&signature={$sign}";
                $res = $this->fetch($api, [], $this->header());
                $json = json_decode($res ?: '{}', true);
                $data2 = $json['data'] ?? [];
                $url = $data2['play_url'] ?? $data2['download_url'] ?? $url;

                try {
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_FOLLOWLOCATION => false,
                        CURLOPT_NOBODY         => true,
                        CURLOPT_TIMEOUT        => 8,
                        CURLOPT_SSL_VERIFYPEER => false,
                    ]);
                    curl_exec($ch);
                    $loc = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
                    curl_close($ch);
                    if ($loc && strpos($loc, 'http') !== false) $url = $loc;
                } catch (\Throwable $e) {}
            } catch (\Throwable $e) {}
        }

        if (preg_match('/\.(jpg|jpeg|png)/', $url)) {
            $url = '/proxy?url=' . base64_encode($url) . '&type=m3u8';
        }

        return [
            'parse'  => 0,
            'url'    => $url,
            'header' => (object)['user-agent' => 'okhttp/4.9.2'],
        ];
    }
}

(new Spider())->run();