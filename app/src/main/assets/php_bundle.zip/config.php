<?php
/**
 * 自动配置生成器 (优化版)
 */
header('Content-Type: application/json; charset=utf-8');

// ==================
// 1. 智能获取当前域名 + 端口 + 路径
// ==================
$isHttps = (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['HTTPS'] == 1))
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
$scheme = $isHttps ? 'https://' : 'http://';

// 获取 Host (通常包含 IP 或域名，可能带端口也可能不带)
$host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';

// ★ 核心修复：如果 HTTP_HOST 里没有端口，且当前非标准端口，则手动补上
if (strpos($host, ':') === false) {
    $port = $_SERVER['SERVER_PORT'] ?? '';
    if ($port && $port != '80' && $port != '443') {
        $host .= ':' . $port;
    }
}

// 处理子目录部署 (如 http://ip:端口/tvbox/)
$path = dirname($_SERVER['SCRIPT_NAME']);
if ($path === '/' || $path === '\\') {
    $path = '';
}
$path = str_replace('\\', '/', $path);

// 拼接最终基础 URL
$baseUrl = $scheme . $host . $path;

// ==================
// 2. 扫描目录自动生成 sites
// ==================
$dir  = __DIR__;
$self = basename(__FILE__);
$sites = [];
$doubanSites = [];   // 豆瓣站点单独收集，最后放到最前

// 获取当前目录下所有文件
foreach (scandir($dir) as $file) {
    // 只处理 php 文件
    if (pathinfo($file, PATHINFO_EXTENSION) !== 'php') continue;

    // 排除系统文件、框架文件、带下划线的文件、测试文件等
    if (in_array($file, ['index.php', 'spider.php', 'example_t4.php', 'test_runner.php']) ||
        $file === $self ||
        strpos($file, '_') === 0 ||
        fnmatch('config*.php', $file) ||
        stripos($file, 'test') !== false ||
        stripos($file, 'bridge') !== false) {
        continue;
    }

    $filename = pathinfo($file, PATHINFO_FILENAME);

    // 是否为豆瓣站点
    $isDouban = (strpos($filename, '豆瓣') !== false);

    // 构建 TVBox 标准的 site 节点
    $site = [
        "key"         => "php_" . $filename,
        "name"        => $filename . "(PHP)",
        "type"        => 4,
        "api"         => $baseUrl . "/" . $filename . ".php",
        "searchable"  => 1,
        "quickSearch" => 1,
        // 豆瓣保持 0，其他改为 1
        "changeable"  => $isDouban ? 0 : 1
    ];

    // 自动识别小说或漫画标识
    if (strpos($filename, '[书]') !== false) {
        $site['类型'] = '小说';
    } elseif (strpos($filename, '[画]') !== false) {
        $site['类型'] = '漫画';
    }

    if ($isDouban) {
        $doubanSites[] = $site;
    } else {
        $sites[] = $site;
    }
}

// 豆瓣放最前，其余按原顺序跟在后面
$sites = array_merge($doubanSites, $sites);

// ==================
// 3. 解析列表 (Parses)
// ==================
$parses = [
    ['name'=>'J1',     'url'=>'https://kalbim.xatut.top/kalbim2025/781718/play/video_player.php?url=', 'type'=>1, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'J2',     'url'=>'http://sspa8.top:8100/api/?key=1060089351&url=',                      'type'=>1, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'J芒果4k', 'url'=>'http://mg.itufm.top/mg.php?url=',                                   'type'=>1, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W花旗',   'url'=>'https://www.huaqi.live/?url=',                                      'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W冰豆',   'url'=>'https://bd.jx.cn/?url=',                                            'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W盘古',   'url'=>'https://www.playm3u8.cn/jiexi.php?url=',                            'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W1',     'url'=>'https://jx.xymp4.cc/?url=',                                          'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W3',     'url'=>'https://yparse.ik9.cc/index.php?url=',                               'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W4',     'url'=>'https://jiexi.site/?url=',                                           'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W5',     'url'=>'https://jx.m3u8.tv/jiexi/?url=',                                     'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W7',     'url'=>'https://www.pangujiexi.com/jiexi/?url=',                             'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W8',     'url'=>'https://www.pouyun.com/?url=',                                       'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'W9',     'url'=>'https://jx.xmflv.com/?url=',                                         'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'Wa',     'url'=>'https://jx.xmflv.cc/?url=',                                          'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'Wb',     'url'=>'https://jx.yparse.com/index.php?url=',                               'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'Wc',     'url'=>'https://www.8090g.cn/?url=',                                         'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
    ['name'=>'Wz',     'url'=>'https://www.ckplayer.vip/jiexi/?url=',                               'type'=>0, 'header'=>['User-Agent'=>'Mozilla/5.0']],
];

// ==================
// 4. 组装并输出 JSON
// ==================
$result = [
    "sites"  => $sites,
    "parses" => $parses,
    "lives"  => []
];

// 输出格式化后的 JSON (不转义中文和斜杠，方便调试)
echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);