<?php
// 本地 CGI/CLI 适配层：把环境变量还原为 $_GET / $_SERVER / $_POST，供站点脚本使用
if (!isset($_GET) || !is_array($_GET)) $_GET = array();
if (!isset($_POST) || !is_array($_POST)) $_POST = array();
if (!isset($_SERVER) || !is_array($_SERVER)) $_SERVER = array();

// 解析 QUERY_STRING -> $_GET
$qs = getenv('QUERY_STRING');
if ($qs !== false && $qs !== '') {
    parse_str($qs, $parsed);
    foreach ($parsed as $k => $v) $_GET[$k] = $v;
}

// 还原常用 $_SERVER 项（CLI SAPI 不会自动填充）
$map = array(
    'HTTP_HOST' => 'PHP_HTTP_HOST',
    'SERVER_NAME' => 'SERVER_NAME',
    'REQUEST_URI' => 'REQUEST_URI',
    'QUERY_STRING' => 'QUERY_STRING',
    'REQUEST_METHOD' => 'REQUEST_METHOD',
    'SCRIPT_NAME' => 'PHP_SCRIPT_NAME',
    'DOCUMENT_ROOT' => 'DOCUMENT_ROOT',
    'REMOTE_ADDR' => 'REMOTE_ADDR',
    'HTTP_USER_AGENT' => 'HTTP_USER_AGENT',
    'CONTENT_TYPE' => 'CONTENT_TYPE',
);
foreach ($map as $serverKey => $envKey) {
    $val = getenv($envKey);
    if ($val !== false) $_SERVER[$serverKey] = $val;
}
if (!isset($_SERVER['HTTP_HOST']) && isset($_SERVER['SERVER_NAME'])) {
    $_SERVER['HTTP_HOST'] = $_SERVER['SERVER_NAME'];
}
